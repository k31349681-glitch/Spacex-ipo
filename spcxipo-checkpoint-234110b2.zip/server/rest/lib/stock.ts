// @ts-nocheck
import { db, siteConfigTable } from "../../db";
import { eq } from "drizzle-orm";

/**
 * The persisted internal SPCX market data is shared by the public quote,
 * history, and trading endpoints so every calculation uses the same value.
 */
export const STOCK_BASE_PRICE = 147.62;
export const STOCK_BASE_MARKET_CAP = "$1.92T";

export async function getMarketConfig() {
  const [config] = await db
    .select()
    .from(siteConfigTable)
    .where(eq(siteConfigTable.id, 1))
    .limit(1);

  return {
    marketPrice: Number(config?.marketPrice ?? STOCK_BASE_PRICE),
    previousMarketPrice: Number(config?.previousMarketPrice ?? STOCK_BASE_PRICE),
    marketCap: config?.marketCap ?? STOCK_BASE_MARKET_CAP,
    activityTickerEnabled: config?.activityTickerEnabled ?? true,
  };
}

export function calculateLivePrice(basePrice: number, now = Date.now()): number {
  const seconds = now / 1000;
  const wave = Math.sin(seconds / 8) * 0.0035 + Math.sin(seconds / 3.7) * 0.0015;
  const microMove = Math.sin(Math.floor(seconds / 2) * 1.618) * 0.0007;
  return Math.max(0.01, Math.round(basePrice * (1 + wave + microMove) * 100) / 100);
}

export async function getCurrentStockPrice(): Promise<number> {
  const { marketPrice } = await getMarketConfig();
  return calculateLivePrice(marketPrice);
}
