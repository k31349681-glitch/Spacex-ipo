type Primitive = string | number | boolean;

type AnalyticsProperties = Record<string, Primitive>;

export function track(eventName: string, properties: AnalyticsProperties = {}) {
  if (typeof window === "undefined") return;

  const safeProperties = Object.fromEntries(
    Object.entries(properties).filter(([key]) =>
      /^(method|asset|source|status|feature|result|screen)$/.test(key),
    ),
  );

  void fetch("/api/analytics/events", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    keepalive: true,
    body: JSON.stringify({
      eventName,
      path: window.location.pathname,
      properties: safeProperties,
    }),
  }).catch(() => {
    // Analytics is best-effort and must never interrupt the product flow.
  });
}
