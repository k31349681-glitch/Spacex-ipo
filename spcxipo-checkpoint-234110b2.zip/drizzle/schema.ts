import {
  boolean,
  decimal,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const investorStatusEnum = mysqlEnum("status", ["pending", "approved", "rejected"]);
export const investorsTable = mysqlTable("investors", {
  id: int("id").autoincrement().primaryKey(),
  fullName: text("full_name").notNull(),
  phone: text("phone"),
  email: varchar("email", { length: 320 }).notNull().unique(),
  passwordHash: text("password_hash"),
  avatarUrl: text("avatar_url"),
  emailNotifications: boolean("email_notifications").notNull().default(true),
  tradeNotifications: boolean("trade_notifications").notNull().default(true),
  status: investorStatusEnum.notNull().default("pending"),
  withdrawalEnabled: boolean("withdrawal_enabled").notNull().default(false),
  withdrawalPermitExpiresAt: timestamp("withdrawal_permit_expires_at"),
  sellAccessExpiresAt: timestamp("sell_access_expires_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
export type Investor = typeof investorsTable.$inferSelect;
export type InsertInvestor = typeof investorsTable.$inferInsert;

export const depositMethodEnum = mysqlEnum("method", ["card", "crypto"]);
export const depositStatusEnum = mysqlEnum("status", ["pending", "completed", "failed"]);
export const depositsTable = mysqlTable("deposits", {
  id: int("id").autoincrement().primaryKey(),
  investorId: int("investor_id").notNull().references(() => investorsTable.id, { onDelete: "cascade" }),
  email: varchar("email", { length: 320 }).notNull(),
  amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
  purpose: varchar("purpose", { length: 40 }).notNull().default("general"),
  feePart: varchar("fee_part", { length: 12 }).notNull().default("full"),
  method: depositMethodEnum.notNull(),
  coin: varchar("coin", { length: 12 }),
  status: depositStatusEnum.notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
export type Deposit = typeof depositsTable.$inferSelect;

export const holdingsTable = mysqlTable("holdings", {
  investorId: int("investor_id").primaryKey().references(() => investorsTable.id, { onDelete: "cascade" }),
  shares: decimal("shares", { precision: 18, scale: 4 }).notNull().default("0"),
  avgCost: decimal("avg_cost", { precision: 18, scale: 4 }).notNull().default("0"),
  cashBalance: decimal("cash_balance", { precision: 18, scale: 2 }).notNull().default("0"),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});
export type Holding = typeof holdingsTable.$inferSelect;

export const depositAddressesTable = mysqlTable("deposit_addresses", {
  coin: varchar("coin", { length: 12 }).primaryKey(),
  address: text("address").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});
export type DepositAddress = typeof depositAddressesTable.$inferSelect;

export const siteConfigTable = mysqlTable("site_config", {
  id: int("id").primaryKey().default(1),
  sellingEnabled: boolean("selling_enabled").notNull().default(false),
  activityTickerEnabled: boolean("activity_ticker_enabled").notNull().default(true),
  marketPrice: decimal("market_price", { precision: 18, scale: 4 }).notNull().default("147.62"),
  previousMarketPrice: decimal("previous_market_price", { precision: 18, scale: 4 }).notNull().default("147.62"),
  marketCap: varchar("market_cap", { length: 64 }).notNull().default("$1.92T"),
  btcPayoutMultiplier: decimal("btc_payout_multiplier", { precision: 5, scale: 2 }).notNull().default("1.90"),
  btcContractMinutes: int("btc_contract_minutes").notNull().default(5),
  btcMaxStake: decimal("btc_max_stake", { precision: 18, scale: 2 }).notNull().default("100.00"),
  btcDailyLimit: decimal("btc_daily_limit", { precision: 18, scale: 2 }).notNull().default("500.00"),
  sellMinimumShares: decimal("sell_minimum_shares", { precision: 18, scale: 4 }).notNull().default("1000"),
  instantBuyShares: decimal("instant_buy_shares", { precision: 18, scale: 4 }).notNull().default("3"),
  sellAccessDurationMinutes: int("sell_access_duration_minutes").notNull().default(60),
  sellingEligibilityMessage: varchar("selling_eligibility_message", { length: 1000 }).notNull().default("Hold at least 1,000 SPCX shares to sell. Investors below that threshold may unlock a one-hour selling window by completing the minimum instant purchase while selling is enabled."),
  withdrawalFeeAmount: decimal("withdrawal_fee_amount", { precision: 18, scale: 2 }).notNull().default("0"),
  launchDayEnabled: boolean("launch_day_enabled").notNull().default(false),
  highShareWithdrawalEnabled: boolean("high_share_withdrawal_enabled").notNull().default(true),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});
export type SiteConfig = typeof siteConfigTable.$inferSelect;

export const notificationsTable = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  investorId: int("investor_id").notNull().references(() => investorsTable.id, { onDelete: "cascade" }),
  message: text("message").notNull(),
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
export type Notification = typeof notificationsTable.$inferSelect;

export const sellAccessAuditActionEnum = mysqlEnum("action", ["opened", "closed", "automatic_unlock"]);
export const sellAccessAuditTable = mysqlTable("sell_access_audit", {
  id: int("id").autoincrement().primaryKey(),
  investorId: int("investor_id").notNull().references(() => investorsTable.id, { onDelete: "cascade" }),
  action: sellAccessAuditActionEnum.notNull(),
  previousExpiresAt: timestamp("previous_expires_at"),
  newExpiresAt: timestamp("new_expires_at"),
  source: varchar("source", { length: 40 }).notNull().default("admin"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
export type SellAccessAudit = typeof sellAccessAuditTable.$inferSelect;

export const analyticsEventsTable = mysqlTable("analytics_events", {
  id: int("id").autoincrement().primaryKey(),
  eventName: varchar("event_name", { length: 80 }).notNull(),
  path: varchar("path", { length: 255 }).notNull(),
  properties: json("properties").$type<Record<string, string | boolean | number>>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
export type AnalyticsEvent = typeof analyticsEventsTable.$inferSelect;

export const realtimeEventsTable = mysqlTable("realtime_events", {
  id: int("id").autoincrement().primaryKey(),
  resource: varchar("resource", { length: 80 }).notNull(),
  action: varchar("action", { length: 120 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
export type RealtimeEventRecord = typeof realtimeEventsTable.$inferSelect;

export const monthlyReportsTable = mysqlTable("monthly_reports", {
  id: int("id").autoincrement().primaryKey(),
  reportMonth: varchar("report_month", { length: 7 }).notNull().unique(),
  periodStart: timestamp("period_start").notNull(),
  periodEnd: timestamp("period_end").notNull(),
  totalMaintenanceFees: decimal("total_maintenance_fees", { precision: 18, scale: 2 }).notNull().default("0"),
  completedMaintenanceFees: decimal("completed_maintenance_fees", { precision: 18, scale: 2 }).notNull().default("0"),
  pendingMaintenanceFees: decimal("pending_maintenance_fees", { precision: 18, scale: 2 }).notNull().default("0"),
  failedMaintenanceFees: decimal("failed_maintenance_fees", { precision: 18, scale: 2 }).notNull().default("0"),
  totalDeposits: decimal("total_deposits", { precision: 18, scale: 2 }).notNull().default("0"),
  totalWithdrawals: decimal("total_withdrawals", { precision: 18, scale: 2 }).notNull().default("0"),
  transactionCount: int("transaction_count").notNull().default(0),
  details: json("details").$type<Record<string, unknown>>(),
  generatedAt: timestamp("generated_at").defaultNow().notNull(),
});
export type MonthlyReport = typeof monthlyReportsTable.$inferSelect;

export const btcPredictionDirectionEnum = mysqlEnum("direction", ["up", "down"]);
export const btcPredictionStatusEnum = mysqlEnum("status", ["open", "settled"]);
export const btcBetStatusEnum = mysqlEnum("status", ["pending", "won", "lost", "refunded"]);
export const btcPredictionContractsTable = mysqlTable("btc_prediction_contracts", {
  id: int("id").autoincrement().primaryKey(),
  startsAt: timestamp("starts_at").notNull(),
  settlesAt: timestamp("settles_at").notNull(),
  startPrice: decimal("start_price", { precision: 18, scale: 2 }).notNull(),
  payoutMultiplier: decimal("payout_multiplier", { precision: 5, scale: 2 }).notNull().default("1.90"),
  endPrice: decimal("end_price", { precision: 18, scale: 2 }),
  status: btcPredictionStatusEnum.notNull().default("open"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
export type BtcPredictionContract = typeof btcPredictionContractsTable.$inferSelect;

export const btcPredictionBetsTable = mysqlTable("btc_prediction_bets", {
  id: int("id").autoincrement().primaryKey(),
  investorId: int("investor_id").notNull().references(() => investorsTable.id, { onDelete: "cascade" }),
  contractId: int("contract_id").notNull().references(() => btcPredictionContractsTable.id, { onDelete: "cascade" }),
  direction: btcPredictionDirectionEnum.notNull(),
  amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
  payout: decimal("payout", { precision: 18, scale: 2 }).notNull().default("0"),
  status: btcBetStatusEnum.notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  settledAt: timestamp("settled_at"),
});
export type BtcPredictionBet = typeof btcPredictionBetsTable.$inferSelect;

export const withdrawalStatusEnum = mysqlEnum("status", ["pending", "completed", "failed"]);
export const withdrawalsTable = mysqlTable("withdrawals", {
  id: int("id").autoincrement().primaryKey(),
  investorId: int("investor_id").notNull().references(() => investorsTable.id, { onDelete: "cascade" }),
  email: varchar("email", { length: 320 }).notNull(),
  amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
  feeAmount: decimal("fee_amount", { precision: 18, scale: 2 }).notNull().default("0"),
  accessMode: varchar("access_mode", { length: 24 }).notNull().default("standard"),
  feeVerifiedAt: timestamp("fee_verified_at"),
  coin: varchar("coin", { length: 12 }).notNull(),
  address: text("address").notNull(),
  status: withdrawalStatusEnum.notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
export type Withdrawal = typeof withdrawalsTable.$inferSelect;

export const passwordSetupTokensTable = mysqlTable("password_setup_tokens", {
  id: int("id").autoincrement().primaryKey(),
  investorId: int("investor_id").notNull().references(() => investorsTable.id, { onDelete: "cascade" }),
  tokenHash: varchar("token_hash", { length: 128 }).notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  usedAt: timestamp("used_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
export type PasswordSetupToken = typeof passwordSetupTokensTable.$inferSelect;

export const schema = {
  users,
  investorsTable,
  depositsTable,
  holdingsTable,
  depositAddressesTable,
  siteConfigTable,
  notificationsTable,
  analyticsEventsTable,
  withdrawalsTable,
  passwordSetupTokensTable,
  monthlyReportsTable,
  btcPredictionContractsTable,
  btcPredictionBetsTable,
};
