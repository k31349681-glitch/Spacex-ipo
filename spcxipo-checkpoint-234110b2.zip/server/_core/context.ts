import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
};

export async function createContext(
  opts: CreateExpressContextOptions,
): Promise<TrpcContext> {
  // Manus OAuth has been removed. Investor authentication uses the local REST
  // sign-in flow and a defensive browser session; tRPC remains public-only.
  return {
    req: opts.req,
    res: opts.res,
    user: null,
  };
}
