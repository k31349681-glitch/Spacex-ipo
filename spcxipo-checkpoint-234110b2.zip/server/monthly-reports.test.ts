import { describe, expect, it } from "vitest";
import { previousMonth, reportToCsv, reportToPdf } from "./rest/lib/monthlyReports";

describe("monthly report periods", () => {
  it("uses the previous UTC calendar month", () => {
    const result = previousMonth(new Date("2026-10-04T16:00:00.000Z"));
    expect(result.reportMonth).toBe("2026-09");
    expect(result.start.toISOString()).toBe("2026-09-01T00:00:00.000Z");
    expect(result.end.toISOString()).toBe("2026-10-01T00:00:00.000Z");
  });

  it("handles the January year boundary", () => {
    const result = previousMonth(new Date("2027-01-01T00:15:00.000Z"));
    expect(result.reportMonth).toBe("2026-12");
    expect(result.start.toISOString()).toBe("2026-12-01T00:00:00.000Z");
    expect(result.end.toISOString()).toBe("2027-01-01T00:00:00.000Z");
  });

  it("exports a report as CSV and PDF", () => {
    const report = {
      reportMonth: "2026-09",
      totalMaintenanceFees: "60.00",
      completedMaintenanceFees: "60.00",
      pendingMaintenanceFees: "0.00",
      failedMaintenanceFees: "0.00",
      totalDeposits: "100.00",
      totalWithdrawals: "20.00",
      transactionCount: 3,
      details: { feePaymentCount: 1 },
    };
    expect(reportToCsv(report)).toContain('"Maintenance fees submitted","60.00"');
    expect(reportToPdf(report).subarray(0, 8).toString()).toBe("%PDF-1.4");
  });
});
