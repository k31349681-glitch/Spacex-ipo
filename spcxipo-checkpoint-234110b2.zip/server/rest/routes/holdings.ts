// @ts-nocheck
import { Router } from "express";
import { db, investorsTable, holdingsTable, notificationsTable, sellAccessAuditTable } from "../../db";
import { eq } from "drizzle-orm";
import { publishRealtimeEvent } from "../lib/realtime";

const router = Router();

// GET /api/holdings?email= — get holdings for current user
router.get("/holdings", async (req, res) => {
  const email = (req.query.email as string | undefined)?.toLowerCase().trim();
  if (!email) {
    res.status(400).json({ error: "Email is required." });
    return;
  }

  try {
    const [investor] = await db
      .select()
      .from(investorsTable)
      .where(eq(investorsTable.email, email))
      .limit(1);

    if (!investor) {
      res.status(404).json({ error: "Investor not found." });
      return;
    }

    if (investor.sellAccessExpiresAt && investor.sellAccessExpiresAt.getTime() <= Date.now()) {
      await db.update(investorsTable).set({ sellAccessExpiresAt: null }).where(eq(investorsTable.id, investor.id));
      await db.insert(sellAccessAuditTable).values({
        investorId: investor.id,
        action: "closed",
        previousExpiresAt: investor.sellAccessExpiresAt,
        newExpiresAt: null,
        source: "expiry",
      });
      await db.insert(notificationsTable).values({
        investorId: investor.id,
        message: "Your temporary selling window has expired and is now closed.",
        read: false,
      });
      investor.sellAccessExpiresAt = null;
      publishRealtimeEvent("notifications", "sell-access-expired");
    }

    const [holding] = await db
      .select()
      .from(holdingsTable)
      .where(eq(holdingsTable.investorId, investor.id))
      .limit(1);

    // Return zeroed holding if none exists yet
    const result = holding ?? {
      investorId: investor.id,
      shares: "0",
      avgCost: "0",
      cashBalance: "0",
      withdrawalEnabled: investor.withdrawalEnabled,
      withdrawalPermitExpiresAt: investor.withdrawalPermitExpiresAt,
      updatedAt: new Date(),
    };

    res.json({
      investorId: result.investorId,
      shares: result.shares,
      avgCost: result.avgCost,
      cashBalance: result.cashBalance,
      withdrawalEnabled: investor.withdrawalEnabled,
      withdrawalPermitExpiresAt: investor.withdrawalPermitExpiresAt?.toISOString() ?? null,
      sellAccessExpiresAt: investor.sellAccessExpiresAt?.toISOString() ?? null,
      updatedAt: result.updatedAt instanceof Date ? result.updatedAt.toISOString() : result.updatedAt,
    });
  } catch (err) {
    console.error({ err }, "Failed to get holdings");
    res.status(500).json({ error: "Something went wrong." });
  }
});

export default router;
