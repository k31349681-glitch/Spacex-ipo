// @ts-nocheck
import { logger } from "./logger";

const RESEND_API_URL = "https://api.resend.com/emails";
const FROM_ADDRESS = process.env.RESEND_FROM_EMAIL ?? "SPCX Investor Relations <onboarding@resend.dev>";

interface StatusEmailParams {
  to: string;
  fullName: string;
  status: "approved" | "rejected";
}

function renderStatusEmail({ fullName, status }: StatusEmailParams): { subject: string; html: string } {
  if (status === "approved") {
    return {
      subject: "Your SPCX investor access has been approved",
      html: `
        <div style="background:#050a0f;padding:40px 24px;font-family:Arial,Helvetica,sans-serif;color:#ffffff;">
          <div style="max-width:480px;margin:0 auto;">
            <p style="letter-spacing:2px;font-size:20px;font-weight:bold;text-transform:uppercase;margin:0 0 32px;">SPCX</p>
            <h1 style="font-size:24px;text-transform:uppercase;letter-spacing:1px;margin:0 0 16px;">Access approved</h1>
            <p style="font-size:15px;line-height:1.6;color:#d1d5db;">Hi ${fullName},</p>
            <p style="font-size:15px;line-height:1.6;color:#d1d5db;">
              Your investor access request for SPCX has been approved. You can now sign in to view live pricing,
              your portfolio, and deposit funds.
            </p>
            <p style="margin:28px 0;">
              <a href="https://spcxipoportal.pages.dev/signin" style="display:inline-block;background:#ffffff;color:#050a0f;padding:14px 22px;text-decoration:none;font-size:13px;font-weight:bold;letter-spacing:1.5px;text-transform:uppercase;">
                Sign in to SPCX
              </a>
            </p>
            <p style="font-size:12px;letter-spacing:1px;text-transform:uppercase;color:#6b7280;margin-top:32px;">
              &copy; 2026 SPCX. All rights reserved.
            </p>
          </div>
        </div>
      `,
    };
  }

  return {
    subject: "Update on your SPCX investor access request",
    html: `
      <div style="background:#050a0f;padding:40px 24px;font-family:Arial,Helvetica,sans-serif;color:#ffffff;">
        <div style="max-width:480px;margin:0 auto;">
          <p style="letter-spacing:2px;font-size:20px;font-weight:bold;text-transform:uppercase;margin:0 0 32px;">SPCX</p>
          <h1 style="font-size:24px;text-transform:uppercase;letter-spacing:1px;margin:0 0 16px;">Access request not approved</h1>
          <p style="font-size:15px;line-height:1.6;color:#d1d5db;">Hi ${fullName},</p>
          <p style="font-size:15px;line-height:1.6;color:#d1d5db;">
            After review, we're unable to approve your investor access request for SPCX at this time.
            If you believe this is a mistake, please contact investors@spcxipo.com.
          </p>
          <p style="font-size:12px;letter-spacing:1px;text-transform:uppercase;color:#6b7280;margin-top:32px;">
            &copy; 2026 SPCX. All rights reserved.
          </p>
        </div>
      </div>
    `,
  };
}

/**
 * Send an email to an investor when their access status changes.
 * Never throws — failures are logged so a flaky email provider can never
 * block an admin's approve/reject action.
 */
export async function sendInvestorStatusEmail(params: StatusEmailParams): Promise<void> {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    logger.warn("RESEND_API_KEY is not configured; skipping investor status email");
    return;
  }

  const { subject, html } = renderStatusEmail(params);

  try {
    const response = await fetch(RESEND_API_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: FROM_ADDRESS,
        to: params.to,
        subject,
        html,
      }),
    });

    if (!response.ok) {
      const body = await response.text();
      logger.error({ status: response.status, body }, "Failed to send investor status email");
    }
  } catch (err) {
    logger.error({ err }, "Failed to send investor status email");
  }
}

export async function sendMonthlyReportEmail(params: { to: string; report: any }): Promise<boolean> {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    logger.warn("RESEND_API_KEY is not configured; skipping monthly report email");
    return false;
  }
  const report = params.report;
  const subject = `SPCX monthly maintenance and transaction report — ${report.reportMonth}`;
  const html = `
    <div style="font-family:Arial,Helvetica,sans-serif;color:#111827;max-width:640px;margin:0 auto;padding:24px">
      <h1 style="margin:0 0 8px">SPCX Monthly Report</h1>
      <p style="color:#6b7280">Reporting period: ${report.reportMonth}</p>
      <table style="border-collapse:collapse;width:100%;margin-top:20px">
        <tr><td style="padding:8px;border-bottom:1px solid #e5e7eb">Maintenance fees submitted</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;text-align:right">$${report.totalMaintenanceFees}</td></tr>
        <tr><td style="padding:8px;border-bottom:1px solid #e5e7eb">Maintenance fees confirmed</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;text-align:right">$${report.completedMaintenanceFees}</td></tr>
        <tr><td style="padding:8px;border-bottom:1px solid #e5e7eb">Maintenance fees pending</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;text-align:right">$${report.pendingMaintenanceFees}</td></tr>
        <tr><td style="padding:8px;border-bottom:1px solid #e5e7eb">Maintenance fee errors</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;text-align:right">$${report.failedMaintenanceFees}</td></tr>
        <tr><td style="padding:8px;border-bottom:1px solid #e5e7eb">General deposits</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;text-align:right">$${report.totalDeposits}</td></tr>
        <tr><td style="padding:8px;border-bottom:1px solid #e5e7eb">Withdrawals</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;text-align:right">$${report.totalWithdrawals}</td></tr>
        <tr><td style="padding:8px;font-weight:bold">Transactions</td><td style="padding:8px;text-align:right;font-weight:bold">${report.transactionCount}</td></tr>
      </table>
    </div>`;
  try {
    const response = await fetch(RESEND_API_URL, {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from: FROM_ADDRESS, to: params.to, subject, html }),
    });
    if (!response.ok) {
      logger.error({ status: response.status, body: await response.text() }, "Failed to send monthly report email");
      return false;
    }
    return true;
  } catch (err) {
    logger.error({ err }, "Failed to send monthly report email");
    return false;
  }
}
