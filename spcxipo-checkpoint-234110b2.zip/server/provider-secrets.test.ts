import { describe, expect, it } from "vitest";

describe("configured provider secrets", () => {
  it("has a valid administrator report recipient configured", () => {
    const recipient = process.env.ADMIN_REPORT_EMAIL;
    expect(recipient, "ADMIN_REPORT_EMAIL must be configured").toBeTruthy();
    expect(recipient).toMatch(/^[^@\s]+@[^@\s]+\.[^@\s]+$/);
  });

  it("authenticates with Resend and Groq lightweight endpoints", async () => {
    const resendKey = process.env.RESEND_API_KEY;
    const groqKey = process.env.GROQ_API_KEY;
    expect(resendKey, "RESEND_API_KEY must be configured").toBeTruthy();
    expect(groqKey, "GROQ_API_KEY must be configured").toBeTruthy();

    const [resend, groq] = await Promise.all([
      fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${resendKey}` },
        body: JSON.stringify({}),
      }),
      fetch("https://api.groq.com/openai/v1/models", {
        headers: { Authorization: `Bearer ${groqKey}` },
      }),
    ]);

    // A send-only key is valid when Resend rejects the empty payload as a
    // validation error; a 401 would indicate an invalid or missing key.
    expect([400, 422], await resend.text()).toContain(resend.status);
    expect(groq.status, await groq.text()).toBe(200);
  }, 20_000);
});
