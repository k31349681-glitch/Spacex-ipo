// @ts-nocheck
import { Router } from "express";
import { z } from "zod";
import { db, analyticsEventsTable } from "../../db";

const router = Router();
const primitive = z.union([z.string().max(120), z.boolean(), z.number().finite()]);
const allowedPropertyKeys = new Set(["method", "asset", "source", "status", "feature", "result", "screen"]);
const safeProperties = z.record(z.string(), primitive).superRefine((properties, ctx) => {
  for (const key of Object.keys(properties)) {
    if (!allowedPropertyKeys.has(key)) {
      ctx.addIssue({ code: "custom", message: `Property ${key} is not allowed.` });
    }
  }
});
export const analyticsEventSchema = z.object({
  eventName: z.string().regex(/^[a-z0-9_.-]{1,80}$/),
  path: z.string().max(255).startsWith("/"),
  properties: safeProperties.optional().default({}),
});

router.post("/analytics/events", async (req, res) => {
  const parsed = analyticsEventSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid analytics event." });
    return;
  }

  try {
    await db.insert(analyticsEventsTable).values({
      eventName: parsed.data.eventName,
      path: parsed.data.path,
      properties: parsed.data.properties,
    });
    res.status(204).end();
  } catch (error) {
    req.log?.error?.({ error }, "Failed to persist analytics event");
    // Analytics must never break the user experience.
    res.status(204).end();
  }
});

export default router;
