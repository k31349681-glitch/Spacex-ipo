import { useEffect, useMemo, useState } from 'react';
import { ArrowDown, ArrowUp, Clock3, ShieldCheck, Trophy, X } from 'lucide-react';
import { toast } from 'sonner';
import { getInvestorSession } from '@/lib/session';

interface Contract {
  id: number;
  startsAt: string;
  settlesAt: string;
  startPrice: number;
  currentPrice: number;
  secondsRemaining: number;
  payoutMultiplier: number;
  maxStake: number;
  dailyLimit: number;
  source: string;
}

interface Bet {
  id: number;
  direction: 'up' | 'down';
  amount: number;
  payout: number;
  status: 'pending' | 'won' | 'lost' | 'refunded';
  createdAt: string;
  settledAt?: string | null;
}

export default function BtcPredictionMarket({ cashBalance, onBalanceChange }: { cashBalance: number; onBalanceChange: () => void }) {
  const email = getInvestorSession()?.email ?? '';
  const token = getInvestorSession()?.token ?? '';
  const [contract, setContract] = useState<Contract | null>(null);
  const [history, setHistory] = useState<Bet[]>([]);
  const [direction, setDirection] = useState<'up' | 'down'>('up');
  const [amount, setAmount] = useState('10');
  const [loading, setLoading] = useState(true);
  const [placing, setPlacing] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [now, setNow] = useState(Date.now());

  const load = async () => {
    if (!email) return;
    try {
      const [contractResponse, historyResponse] = await Promise.all([
        fetch('/api/predictions/btc/current'),
        fetch('/api/predictions/btc/history', { headers: { Authorization: `Bearer ${token}` } }),
      ]);
      if (contractResponse.ok) setContract(await contractResponse.json());
      if (historyResponse.ok) setHistory(await historyResponse.json());
    } catch { /* the next poll retries */ } finally { setLoading(false); }
  };

  useEffect(() => { load(); const timer = window.setInterval(load, 5000); return () => window.clearInterval(timer); }, [email]);
  useEffect(() => { const timer = window.setInterval(() => setNow(Date.now()), 1000); return () => window.clearInterval(timer); }, []);

  const secondsRemaining = useMemo(() => contract ? Math.max(0, Math.ceil((new Date(contract.settlesAt).getTime() - now) / 1000)) : 0, [contract, now]);
  const stake = Number(amount) || 0;
  const possiblePayout = stake * (contract?.payoutMultiplier ?? 1.9);
  const priceChange = contract ? contract.currentPrice - contract.startPrice : 0;

  const placeBet = async () => {
    if (!contract || secondsRemaining <= 0) return toast.error('This round is closed. Refresh for the next round.');
    if (stake < 1) return toast.error('Enter a stake of at least $1.');
    if (stake > contract.maxStake) return toast.error(`The maximum stake per prediction is $${contract.maxStake.toFixed(2)}.`);
    if (stake > cashBalance) return toast.error('Insufficient cash balance. Deposit funds first.');
    setConfirmOpen(true);
  };

  const confirmBet = async () => {
    setPlacing(true);
    try {
      const response = await fetch('/api/predictions/btc/bet', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }, body: JSON.stringify({ direction, amount: stake, confirmed: true }) });
      const body = await response.json();
      if (!response.ok) throw new Error(body.error || 'Unable to place prediction.');
      toast.success(`BTC ${direction.toUpperCase()} prediction placed for $${stake.toFixed(2)}.`);
      setConfirmOpen(false);
      await load();
      onBalanceChange();
    } catch (error: any) { toast.error(error.message); } finally { setPlacing(false); }
  };

  return (
    <section className="border border-cyan-300/20 bg-cyan-400/[0.04] rounded-xl overflow-hidden">
      <div className="p-5 border-b border-cyan-300/15 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div><div className="flex items-center gap-2 text-cyan-200 text-xs font-display tracking-widest uppercase"><span className="w-2 h-2 rounded-full bg-cyan-300 animate-pulse" /> BTC prediction market</div><h2 className="text-xl font-bold mt-2">Will Bitcoin be higher in {Math.max(1, Math.round((contract?.secondsRemaining ?? 300) / 60))} minutes?</h2><p className="text-xs text-white/45 mt-1">CoinGecko BTC/USD · real investor cash · tie returns the full stake</p></div>
        <div className="flex items-center gap-2 text-sm font-mono text-cyan-100"><Clock3 className="w-4 h-4" /> {Math.floor(secondsRemaining / 60).toString().padStart(2, '0')}:{(secondsRemaining % 60).toString().padStart(2, '0')}</div>
      </div>
      <div className="p-5 grid lg:grid-cols-[1fr_280px] gap-5">
        <div>
          <div className="flex items-end gap-3"><span className="text-3xl font-display font-bold">{loading ? '—' : `$${contract?.currentPrice.toLocaleString(undefined, { maximumFractionDigits: 2 })}`}</span><span className={`text-sm font-bold ${priceChange >= 0 ? 'text-green-300' : 'text-red-300'}`}>{priceChange >= 0 ? '+' : ''}{priceChange.toFixed(2)} vs start</span></div>
          <div className="grid grid-cols-2 gap-3 mt-5">
            <button onClick={() => setDirection('up')} className={`p-4 border rounded-lg text-left transition-colors cursor-pointer ${direction === 'up' ? 'border-green-300 bg-green-400/15' : 'border-white/10 hover:border-green-300/50'}`}><ArrowUp className="w-5 h-5 text-green-300" /><div className="font-bold mt-3">Higher</div><div className="text-xs text-white/45 mt-1">BTC finishes above ${contract?.startPrice.toLocaleString(undefined, { maximumFractionDigits: 2 }) ?? '—'}</div></button>
            <button onClick={() => setDirection('down')} className={`p-4 border rounded-lg text-left transition-colors cursor-pointer ${direction === 'down' ? 'border-red-300 bg-red-400/15' : 'border-white/10 hover:border-red-300/50'}`}><ArrowDown className="w-5 h-5 text-red-300" /><div className="font-bold mt-3">Lower</div><div className="text-xs text-white/45 mt-1">BTC finishes below the start price</div></button>
          </div>
          <div className="flex items-center gap-2 mt-4 text-xs text-white/45"><ShieldCheck className="w-4 h-4 text-cyan-200" /> Total payout: {contract?.payoutMultiplier ?? 1.9}× for a winning prediction. Ties are refunded.</div>
          <div className="text-xs text-white/40 mt-2">Limits: up to ${contract?.maxStake?.toFixed(2) ?? '100.00'} per prediction and ${contract?.dailyLimit?.toFixed(2) ?? '500.00'} per UTC day.</div>
        </div>
        <div className="border border-white/10 rounded-lg p-4 self-start">
          <label className="text-xs text-white/45">Stake amount</label>
          <div className="mt-2 flex items-center border border-white/10 rounded-lg px-3"><span className="text-white/40">$</span><input value={amount} onChange={(event) => setAmount(event.target.value)} type="number" min="1" step="1" className="w-full bg-transparent px-2 py-3 text-xl font-bold outline-none" /></div>
          <div className="flex gap-2 mt-2">{[10, 25, 50].map((value) => <button key={value} onClick={() => setAmount(String(Math.min(value, Math.max(1, Math.floor(cashBalance)))))} className="flex-1 bg-white/5 py-2 text-xs cursor-pointer hover:bg-white/10">${value}</button>)}</div>
          <div className="flex justify-between text-xs text-white/45 mt-5"><span>Potential payout</span><span className="text-white font-bold">${possiblePayout.toFixed(2)}</span></div>
          <div className="flex justify-between text-xs text-white/45 mt-2"><span>Available cash</span><span>${cashBalance.toFixed(2)}</span></div>
          <button onClick={placeBet} disabled={placing || !contract || secondsRemaining <= 0 || stake > cashBalance} className={`w-full mt-5 py-3 rounded-lg font-bold cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${direction === 'up' ? 'bg-green-400 text-black' : 'bg-red-400 text-black'}`}>{placing ? 'Placing…' : `Predict ${direction === 'up' ? 'Higher' : 'Lower'}`}</button>
        </div>
      </div>
      <div className="px-5 pb-5"><div className="flex items-center gap-2 text-xs font-display tracking-widest uppercase text-white/45 mb-3"><Trophy className="w-4 h-4" /> Your recent BTC predictions</div><div className="space-y-2">{history.slice(0, 4).map((bet) => <div key={bet.id} className="flex items-center justify-between border border-white/10 px-3 py-2 text-xs"><span className={bet.direction === 'up' ? 'text-green-300' : 'text-red-300'}>{bet.direction.toUpperCase()} · ${bet.amount.toFixed(2)}</span><span className={bet.status === 'won' ? 'text-green-300' : bet.status === 'lost' ? 'text-red-300' : bet.status === 'refunded' ? 'text-yellow-200' : 'text-white/50'}>{bet.status}{bet.payout ? ` · $${bet.payout.toFixed(2)}` : ''}</span></div>)}{history.length === 0 && <div className="text-xs text-white/35">No predictions yet.</div>}</div></div>
      {confirmOpen && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4" role="dialog" aria-modal="true" aria-labelledby="btc-confirm-title"><div className="w-full max-w-md border border-cyan-300/30 bg-[#0b1118] rounded-xl p-6 shadow-2xl"><div className="flex items-start justify-between gap-4"><div><div className="text-xs uppercase tracking-widest text-cyan-200">Real-cash confirmation</div><h3 id="btc-confirm-title" className="text-xl font-bold mt-2">Confirm your BTC prediction</h3></div><button onClick={() => setConfirmOpen(false)} className="text-white/50 hover:text-white cursor-pointer" aria-label="Close confirmation"><X className="w-5 h-5" /></button></div><div className="mt-5 space-y-3 text-sm"><div className="flex justify-between"><span className="text-white/50">Prediction</span><strong className={direction === 'up' ? 'text-green-300' : 'text-red-300'}>{direction === 'up' ? 'Higher' : 'Lower'}</strong></div><div className="flex justify-between"><span className="text-white/50">Stake debited now</span><strong>${stake.toFixed(2)}</strong></div><div className="flex justify-between"><span className="text-white/50">Potential payout</span><strong>${possiblePayout.toFixed(2)}</strong></div><p className="text-xs leading-relaxed text-white/55 border-t border-white/10 pt-4">This uses real investor cash. The stake is deducted immediately; a winning prediction pays the displayed multiplier, a losing prediction pays $0, and an exact-price tie refunds the stake. You can lose the entire stake.</p></div><div className="grid grid-cols-2 gap-3 mt-6"><button onClick={() => setConfirmOpen(false)} disabled={placing} className="border border-white/15 py-3 text-sm cursor-pointer">Cancel</button><button onClick={confirmBet} disabled={placing} className={`py-3 font-bold cursor-pointer disabled:opacity-50 ${direction === 'up' ? 'bg-green-400 text-black' : 'bg-red-400 text-black'}`}>{placing ? 'Confirming…' : 'I understand — place bet'}</button></div></div></div>}
    </section>
  );
}
