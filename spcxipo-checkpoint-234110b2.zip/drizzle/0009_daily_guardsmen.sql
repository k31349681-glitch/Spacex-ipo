ALTER TABLE `site_config` ADD `btc_payout_multiplier` decimal(5,2) DEFAULT '1.90' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_config` ADD `btc_contract_minutes` int DEFAULT 5 NOT NULL;--> statement-breakpoint
ALTER TABLE `site_config` ADD `btc_max_stake` decimal(18,2) DEFAULT '100.00' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_config` ADD `btc_daily_limit` decimal(18,2) DEFAULT '500.00' NOT NULL;