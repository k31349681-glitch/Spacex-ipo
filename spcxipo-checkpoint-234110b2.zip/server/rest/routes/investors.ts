// @ts-nocheck
import { Router } from "express";
import { db, investorsTable } from "../../db";
import { CreateInvestorBody } from "../api-zod";
import { count, eq } from "drizzle-orm";
import { hashPassword } from "../lib/password";
import { publishRealtimeEvent } from "../lib/realtime";

const router = Router();

// POST /api/investors — sign up for investor access
router.post("/investors", async (req, res) => {
  const parsed = CreateInvestorBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid input. Phone, full name, email, and a password of at least 8 characters are required." });
    return;
  }

  const { phone, fullName, email, password } = parsed.data;

  try {
    const normalizedEmail = email.toLowerCase().trim();
    await db.insert(investorsTable).values({
      phone: phone.trim(),
      fullName: fullName.trim(),
      email: normalizedEmail,
      passwordHash: hashPassword(password),
    });
    const [investor] = await db.select().from(investorsTable).where(eq(investorsTable.email, normalizedEmail)).limit(1);

    publishRealtimeEvent("investors", "created");
    res.status(201).json({
      id: investor.id,
      fullName: investor.fullName,
      phone: investor.phone,
      email: investor.email,
      status: investor.status,
      createdAt: investor.createdAt.toISOString(),
    });
  } catch (err: any) {
    const databaseError = err?.cause ?? err;
    if (databaseError?.code === "ER_DUP_ENTRY" || databaseError?.errno === 1062 || databaseError?.code === "23505") {
      res.status(409).json({ error: "This email is already registered." });
      return;
    }
    console.error({ err }, "Failed to create investor");
    res.status(500).json({ error: "Something went wrong. Please try again." });
  }
});

// GET /api/investors/count — get total registered investor count
router.get("/investors/count", async (req, res) => {
  try {
    const [result] = await db.select({ count: count() }).from(investorsTable);
    res.json({ count: Number(result.count) });
  } catch (err) {
    console.error({ err }, "Failed to get investor count");
    res.status(500).json({ error: "Something went wrong." });
  }
});

export default router;
