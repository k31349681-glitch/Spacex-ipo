import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import * as schema from "../drizzle/schema";
import type { InsertUser } from "../drizzle/schema";

export const db = process.env.DATABASE_URL
  ? drizzle(process.env.DATABASE_URL, { schema, mode: "default" })
  : (null as any);

export async function getDb() {
  return db;
}

export const {
  users,
  investorsTable,
  depositsTable,
  holdingsTable,
  depositAddressesTable,
  siteConfigTable,
  notificationsTable,
  sellAccessAuditTable,
  analyticsEventsTable,
  withdrawalsTable,
  passwordSetupTokensTable,
  realtimeEventsTable,
  monthlyReportsTable,
  btcPredictionContractsTable,
  btcPredictionBetsTable,
} = schema;

export type { InsertUser, User } from "../drizzle/schema";

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;

  for (const field of textFields) {
    const value = user[field];
    if (value !== undefined) {
      values[field] = value ?? null;
      updateSet[field] = value ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  }
  values.lastSignedIn ??= new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}
