ALTER TABLE `investors` ADD `withdrawal_permit_expires_at` timestamp;--> statement-breakpoint
ALTER TABLE `site_config` ADD `withdrawal_fee_amount` decimal(18,2) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_config` ADD `launch_day_enabled` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `site_config` ADD `high_share_withdrawal_enabled` boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE `withdrawals` ADD `fee_amount` decimal(18,2) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE `withdrawals` ADD `access_mode` varchar(24) DEFAULT 'standard' NOT NULL;--> statement-breakpoint
ALTER TABLE `withdrawals` ADD `fee_verified_at` timestamp;