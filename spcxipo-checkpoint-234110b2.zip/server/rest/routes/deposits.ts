// @ts-nocheck
import { Router } from "express";
import { db, investorsTable, depositsTable, depositAddressesTable, siteConfigTable } from "../../db";
import { eq, desc } from "drizzle-orm";
import { z } from "zod";
import { publishRealtimeEvent } from "../lib/realtime";

const router = Router();

const CreateDepositSchema = z.object({
  email: z.string().email(),
  amount: z.number().min(1),
  purpose: z.enum(["general", "maintenance_fee", "withdrawal_fee"]).default("general"),
  feePart: z.enum(["half", "full"]).default("full"),
  method: z.enum(["card", "crypto"]),
  coin: z.enum(["BTC", "ETH", "DOGE"]).optional(),
});

// POST /api/deposits — submit a deposit
router.post("/deposits", async (req, res) => {
  const parsed = CreateDepositSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid input." });
    return;
  }
  const { email, amount, purpose, feePart, method, coin } = parsed.data;

  if (purpose === "maintenance_fee") {
    const expected = feePart === "half" ? 35 : 70;
    if (amount !== expected) {
      res.status(400).json({ error: `Maintenance fee ${feePart} payment must be $${expected}.00.` });
      return;
    }
  } else if (purpose === "withdrawal_fee") {
    if (feePart !== "full") {
      res.status(400).json({ error: "Withdrawal fees must be submitted as a full separate payment." });
      return;
    }
    const [config] = await db.select().from(siteConfigTable).where(eq(siteConfigTable.id, 1)).limit(1);
    const expected = Number(config?.withdrawalFeeAmount ?? 0);
    if (expected <= 0 || amount !== expected) {
      res.status(400).json({ error: `Withdrawal fee payment must be $${expected.toFixed(2)}.` });
      return;
    }
  } else if (feePart !== "full") {
    res.status(400).json({ error: "Fee payment selection is only valid for maintenance fees." });
    return;
  }

  if (method === "card") {
    res.status(400).json({ error: "Card payments are not available at the moment. Kindly use Crypto Payment." });
    return;
  }

  try {
    const [investor] = await db
      .select()
      .from(investorsTable)
      .where(eq(investorsTable.email, email.toLowerCase().trim()))
      .limit(1);

    if (!investor) {
      res.status(404).json({ error: "Investor not found." });
      return;
    }

    const [inserted] = await db
      .insert(depositsTable)
      .values({
        investorId: investor.id,
        email: investor.email,
        amount: String(amount),
        purpose,
        feePart,
        method,
        coin: coin ?? null,
        status: "pending",
      })
      .$returningId();
    const [deposit] = await db.select().from(depositsTable).where(eq(depositsTable.id, inserted.id)).limit(1);

    publishRealtimeEvent("deposits", "created");
    res.status(201).json({
      id: deposit.id,
      investorId: deposit.investorId,
      email: deposit.email,
      amount: deposit.amount,
      purpose: deposit.purpose,
      feePart: deposit.feePart,
      method: deposit.method,
      coin: deposit.coin,
      status: deposit.status,
      createdAt: deposit.createdAt.toISOString(),
    });
  } catch (err) {
    console.error({ err }, "Failed to create deposit");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// GET /api/deposits?email= — deposit history for the current user
router.get("/deposits", async (req, res) => {
  const email = (req.query.email as string | undefined)?.toLowerCase().trim();
  if (!email) {
    res.status(400).json({ error: "Email is required." });
    return;
  }

  try {
    const [investor] = await db.select().from(investorsTable).where(eq(investorsTable.email, email)).limit(1);
    if (!investor) {
      res.status(404).json({ error: "Investor not found." });
      return;
    }

    const rows = await db
      .select()
      .from(depositsTable)
      .where(eq(depositsTable.investorId, investor.id))
      .orderBy(desc(depositsTable.createdAt));

    res.json(
      rows.map((d) => ({
        id: d.id,
        investorId: d.investorId,
        email: d.email,
        amount: d.amount,
        purpose: d.purpose,
        feePart: d.feePart,
        method: d.method,
        coin: d.coin,
        status: d.status,
        createdAt: d.createdAt.toISOString(),
      }))
    );
  } catch (err) {
    console.error({ err }, "Failed to list deposits");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// GET /api/deposit-addresses — public list of crypto deposit addresses
router.get("/deposit-addresses", async (req, res) => {
  try {
    const addresses = await db.select().from(depositAddressesTable);
    res.json(
      addresses.map((a) => ({
        coin: a.coin,
        address: a.address,
        updatedAt: a.updatedAt.toISOString(),
      }))
    );
  } catch (err) {
    console.error({ err }, "Failed to get deposit addresses");
    res.status(500).json({ error: "Something went wrong." });
  }
});

export default router;
