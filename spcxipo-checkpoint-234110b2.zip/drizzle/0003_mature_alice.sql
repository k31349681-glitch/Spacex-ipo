ALTER TABLE `investors` ADD `avatar_url` text;--> statement-breakpoint
ALTER TABLE `site_config` ADD `activity_ticker_enabled` boolean DEFAULT true NOT NULL;