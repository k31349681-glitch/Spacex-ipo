CREATE TABLE `analytics_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`event_name` varchar(80) NOT NULL,
	`path` varchar(255) NOT NULL,
	`properties` json,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `analytics_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `deposit_addresses` (
	`coin` varchar(12) NOT NULL,
	`address` text NOT NULL,
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `deposit_addresses_coin` PRIMARY KEY(`coin`)
);
--> statement-breakpoint
CREATE TABLE `deposits` (
	`id` int AUTO_INCREMENT NOT NULL,
	`investor_id` int NOT NULL,
	`email` varchar(320) NOT NULL,
	`amount` decimal(18,2) NOT NULL,
	`method` enum('card','crypto') NOT NULL,
	`coin` varchar(12),
	`status` enum('pending','completed','failed') NOT NULL DEFAULT 'pending',
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `deposits_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `holdings` (
	`investor_id` int NOT NULL,
	`shares` decimal(18,4) NOT NULL DEFAULT '0',
	`avg_cost` decimal(18,4) NOT NULL DEFAULT '0',
	`cash_balance` decimal(18,2) NOT NULL DEFAULT '0',
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `holdings_investor_id` PRIMARY KEY(`investor_id`)
);
--> statement-breakpoint
CREATE TABLE `investors` (
	`id` int AUTO_INCREMENT NOT NULL,
	`full_name` text NOT NULL,
	`phone` text,
	`email` varchar(320) NOT NULL,
	`password_hash` text,
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`withdrawal_enabled` boolean NOT NULL DEFAULT false,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `investors_id` PRIMARY KEY(`id`),
	CONSTRAINT `investors_email_unique` UNIQUE(`email`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`investor_id` int NOT NULL,
	`message` text NOT NULL,
	`read` boolean NOT NULL DEFAULT false,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `password_setup_tokens` (
	`id` int AUTO_INCREMENT NOT NULL,
	`investor_id` int NOT NULL,
	`token_hash` varchar(128) NOT NULL,
	`expires_at` timestamp NOT NULL,
	`used_at` timestamp,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `password_setup_tokens_id` PRIMARY KEY(`id`),
	CONSTRAINT `password_setup_tokens_token_hash_unique` UNIQUE(`token_hash`)
);
--> statement-breakpoint
CREATE TABLE `site_config` (
	`id` int NOT NULL DEFAULT 1,
	`selling_enabled` boolean NOT NULL DEFAULT false,
	`market_price` decimal(18,4) NOT NULL DEFAULT '147.62',
	`previous_market_price` decimal(18,4) NOT NULL DEFAULT '147.62',
	`market_cap` varchar(64) NOT NULL DEFAULT '$1.92T',
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `site_config_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `withdrawals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`investor_id` int NOT NULL,
	`email` varchar(320) NOT NULL,
	`amount` decimal(18,2) NOT NULL,
	`coin` varchar(12) NOT NULL,
	`address` text NOT NULL,
	`status` enum('pending','completed','failed') NOT NULL DEFAULT 'pending',
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `withdrawals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `deposits` ADD CONSTRAINT `deposits_investor_id_investors_id_fk` FOREIGN KEY (`investor_id`) REFERENCES `investors`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `holdings` ADD CONSTRAINT `holdings_investor_id_investors_id_fk` FOREIGN KEY (`investor_id`) REFERENCES `investors`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `notifications` ADD CONSTRAINT `notifications_investor_id_investors_id_fk` FOREIGN KEY (`investor_id`) REFERENCES `investors`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `password_setup_tokens` ADD CONSTRAINT `password_setup_tokens_investor_id_investors_id_fk` FOREIGN KEY (`investor_id`) REFERENCES `investors`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `withdrawals` ADD CONSTRAINT `withdrawals_investor_id_investors_id_fk` FOREIGN KEY (`investor_id`) REFERENCES `investors`(`id`) ON DELETE cascade ON UPDATE no action;