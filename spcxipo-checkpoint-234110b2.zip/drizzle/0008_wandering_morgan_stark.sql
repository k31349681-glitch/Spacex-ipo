CREATE TABLE `btc_prediction_bets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`investor_id` int NOT NULL,
	`contract_id` int NOT NULL,
	`direction` enum('up','down') NOT NULL,
	`amount` decimal(18,2) NOT NULL,
	`payout` decimal(18,2) NOT NULL DEFAULT '0',
	`status` enum('pending','won','lost','refunded') NOT NULL DEFAULT 'pending',
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`settled_at` timestamp,
	CONSTRAINT `btc_prediction_bets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `btc_prediction_contracts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`starts_at` timestamp NOT NULL,
	`settles_at` timestamp NOT NULL,
	`start_price` decimal(18,2) NOT NULL,
	`end_price` decimal(18,2),
	`status` enum('open','settled') NOT NULL DEFAULT 'open',
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `btc_prediction_contracts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `btc_prediction_bets` ADD CONSTRAINT `btc_prediction_bets_investor_id_investors_id_fk` FOREIGN KEY (`investor_id`) REFERENCES `investors`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `btc_prediction_bets` ADD CONSTRAINT `btc_prediction_bets_contract_id_btc_prediction_contracts_id_fk` FOREIGN KEY (`contract_id`) REFERENCES `btc_prediction_contracts`(`id`) ON DELETE cascade ON UPDATE no action;