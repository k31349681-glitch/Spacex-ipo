import { describe, expect, it } from "vitest";
import { analyticsEventSchema } from "./rest/routes/analytics";

describe("analytics event validation", () => {
  it("accepts a safe event with primitive product properties", () => {
    const result = analyticsEventSchema.safeParse({
      eventName: "deposit_flow_started",
      path: "/orders",
      properties: { method: "crypto", screen: "orders" },
    });

    expect(result.success).toBe(true);
  });

  it("rejects identifiers and arbitrary property names", () => {
    const result = analyticsEventSchema.safeParse({
      eventName: "deposit_submitted",
      path: "/orders",
      properties: { email: "investor@example.com" },
    });

    expect(result.success).toBe(false);
  });

  it("rejects malformed event names and non-route paths", () => {
    expect(
      analyticsEventSchema.safeParse({
        eventName: "Deposit Submitted",
        path: "https://example.com",
      }).success,
    ).toBe(false);
  });
});
