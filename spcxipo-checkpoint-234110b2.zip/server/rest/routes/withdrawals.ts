// @ts-nocheck
import { Router } from "express";
import { db, investorsTable, holdingsTable, withdrawalsTable, depositsTable, siteConfigTable } from "../../db";
import { CreateWithdrawalBody } from "../api-zod";
import { eq, desc, and, gte } from "drizzle-orm";
import { publishRealtimeEvent } from "../lib/realtime";

const router = Router();

function serializeWithdrawal(withdrawal: typeof withdrawalsTable.$inferSelect) {
  return {
    id: withdrawal.id,
    investorId: withdrawal.investorId,
    email: withdrawal.email,
    amount: withdrawal.amount,
    feeAmount: withdrawal.feeAmount,
    accessMode: withdrawal.accessMode,
    feeVerifiedAt: withdrawal.feeVerifiedAt?.toISOString() ?? null,
    coin: withdrawal.coin,
    address: withdrawal.address,
    status: withdrawal.status,
    createdAt: withdrawal.createdAt.toISOString(),
  };
}

async function getWithdrawalPolicy() {
  const [config] = await db.select().from(siteConfigTable).where(eq(siteConfigTable.id, 1)).limit(1);
  return {
    minimumShares: Number(config?.sellMinimumShares ?? 1000),
    highShareMinimum: 100000,
    feeAmount: Number(config?.withdrawalFeeAmount ?? 0),
    launchDayEnabled: Boolean(config?.launchDayEnabled),
    highShareWithdrawalEnabled: config?.highShareWithdrawalEnabled !== false,
  };
}

// GET /api/withdrawals?email= — current user's crypto withdrawal history
router.get("/withdrawals", async (req, res) => {
  const email = (req.query.email as string | undefined)?.toLowerCase().trim();
  if (!email) return res.status(400).json({ error: "Email is required." });
  try {
    const [investor] = await db.select().from(investorsTable).where(eq(investorsTable.email, email)).limit(1);
    if (!investor) return res.status(404).json({ error: "Investor not found." });
    const withdrawals = await db.select().from(withdrawalsTable).where(eq(withdrawalsTable.investorId, investor.id)).orderBy(desc(withdrawalsTable.createdAt));
    res.json(withdrawals.map(serializeWithdrawal));
  } catch (err) {
    console.error({ err }, "Failed to list withdrawals");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// POST /api/withdrawals — request a withdrawal after server-side eligibility and fee verification
router.post("/withdrawals", async (req, res) => {
  const parsed = CreateWithdrawalBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Provide a valid email, amount, coin, and wallet address." });
  const { email: rawEmail, amount, coin, address } = parsed.data;
  const email = rawEmail.toLowerCase().trim();

  try {
    const withdrawal = await db.transaction(async (tx) => {
      const [investor] = await tx.select().from(investorsTable).where(eq(investorsTable.email, email)).limit(1);
      if (!investor) throw new Error("INVESTOR_NOT_FOUND");
      if (investor.status !== "approved") throw new Error("NOT_APPROVED");

      const policy = await getWithdrawalPolicy();
      const [holding] = await tx.select().from(holdingsTable).where(eq(holdingsTable.investorId, investor.id)).limit(1);
      const shares = Number(holding?.shares ?? 0);
      const permitActive = investor.withdrawalPermitExpiresAt && investor.withdrawalPermitExpiresAt.getTime() > Date.now();
      const highShareEligible = policy.highShareWithdrawalEnabled && shares >= policy.highShareMinimum && permitActive;
      const standardEligible = shares >= policy.minimumShares;
      if (!policy.launchDayEnabled && !standardEligible && !highShareEligible) throw new Error(shares >= policy.highShareMinimum ? "PERMIT_REQUIRED" : "MINIMUM_SHARES_REQUIRED");

      let feeDeposit: any = null;
      if (policy.feeAmount > 0) {
        const [completedFee] = await tx.select().from(depositsTable).where(and(
          eq(depositsTable.investorId, investor.id),
          eq(depositsTable.purpose, "withdrawal_fee"),
          eq(depositsTable.status, "completed"),
          gte(depositsTable.amount, String(policy.feeAmount)),
        )).orderBy(desc(depositsTable.createdAt)).limit(1);
        feeDeposit = completedFee;
        if (!feeDeposit) throw new Error("WITHDRAWAL_FEE_REQUIRED");
      }

      const cashBalance = Number(holding?.cashBalance ?? 0);
      if (!holding || amount > cashBalance) throw new Error("INSUFFICIENT_BALANCE");
      await tx.update(holdingsTable).set({ cashBalance: String(cashBalance - amount), updatedAt: new Date() }).where(eq(holdingsTable.investorId, investor.id));
      const accessMode = policy.launchDayEnabled ? "launch_day" : highShareEligible ? "100k_permit" : "standard";
      const [inserted] = await tx.insert(withdrawalsTable).values({
        investorId: investor.id,
        email: investor.email,
        amount: String(amount),
        feeAmount: String(policy.feeAmount),
        accessMode,
        feeVerifiedAt: policy.feeAmount > 0 ? new Date() : null,
        coin,
        address: address.trim(),
        status: "pending",
      }).$returningId();
      const [created] = await tx.select().from(withdrawalsTable).where(eq(withdrawalsTable.id, inserted.id)).limit(1);
      return created;
    });
    publishRealtimeEvent("withdrawals", "created");
    res.status(201).json(serializeWithdrawal(withdrawal));
  } catch (err) {
    const reason = err instanceof Error ? err.message : "";
    const errors: Record<string, [number, string]> = {
      INVESTOR_NOT_FOUND: [404, "Investor not found."],
      NOT_APPROVED: [403, "Only approved investors can withdraw."],
      MINIMUM_SHARES_REQUIRED: [403, "Withdrawals require at least 1,000 SPCX shares unless Launch Day is open."],
      PERMIT_REQUIRED: [403, "Your 100k-share withdrawal opportunity is currently closed. An administrator must issue a timed permit."],
      WITHDRAWAL_FEE_REQUIRED: [403, "Pay the separate withdrawal fee and wait for it to be verified before requesting a withdrawal."],
      INSUFFICIENT_BALANCE: [400, "Insufficient cash balance."],
    };
    if (errors[reason]) return res.status(errors[reason][0]).json({ error: errors[reason][1] });
    console.error({ err }, "Failed to create withdrawal");
    res.status(500).json({ error: "Something went wrong." });
  }
});

export default router;
