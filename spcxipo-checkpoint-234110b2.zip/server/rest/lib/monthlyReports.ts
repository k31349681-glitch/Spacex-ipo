import { and, eq, gte, lt, asc } from "drizzle-orm";
import {
  db,
  depositsTable,
  monthlyReportsTable,
  withdrawalsTable,
} from "../../db";

function money(value: number) {
  return value.toFixed(2);
}

export function previousMonth(now = new Date()) {
  const year = now.getUTCFullYear();
  const month = now.getUTCMonth();
  const start = new Date(Date.UTC(year, month - 1, 1));
  const end = new Date(Date.UTC(year, month, 1));
  const reportMonth = `${start.getUTCFullYear()}-${String(start.getUTCMonth() + 1).padStart(2, "0")}`;
  return { reportMonth, start, end };
}

export async function generateMonthlyReport(reportMonth: string, start: Date, end: Date) {
  const [existing] = await db.select().from(monthlyReportsTable).where(eq(monthlyReportsTable.reportMonth, reportMonth)).limit(1);
  if (existing) return { report: existing, created: false };

  const deposits = await db.select().from(depositsTable).where(and(
    gte(depositsTable.createdAt, start),
    lt(depositsTable.createdAt, end),
  )).orderBy(asc(depositsTable.createdAt));
  const withdrawals = await db.select().from(withdrawalsTable).where(and(
    gte(withdrawalsTable.createdAt, start),
    lt(withdrawalsTable.createdAt, end),
  )).orderBy(asc(withdrawalsTable.createdAt));

  const feePayments: Array<{ amount: string; status: "completed" | "pending" | "failed" }> = deposits.filter((deposit: any) => deposit.purpose === "maintenance_fee");
  const generalDeposits: Array<{ amount: string }> = deposits.filter((deposit: any) => deposit.purpose !== "maintenance_fee");
  const sum = (rows: Array<{ amount: string }>) => rows.reduce((total, row) => total + Number(row.amount), 0);
  const byStatus = (status: "completed" | "pending" | "failed") => sum(feePayments.filter((row) => row.status === status));

  const details = {
    feePaymentCount: feePayments.length,
    completedFeePaymentCount: feePayments.filter((row: { status: string }) => row.status === "completed").length,
    pendingFeePaymentCount: feePayments.filter((row: { status: string }) => row.status === "pending").length,
    failedFeePaymentCount: feePayments.filter((row: { status: string }) => row.status === "failed").length,
    generalDepositCount: generalDeposits.length,
    withdrawalCount: withdrawals.length,
    completedWithdrawalCount: withdrawals.filter((row: { status: string }) => row.status === "completed").length,
    pendingWithdrawalCount: withdrawals.filter((row: { status: string }) => row.status === "pending").length,
    failedWithdrawalCount: withdrawals.filter((row: { status: string }) => row.status === "failed").length,
  };

  const [inserted] = await db.insert(monthlyReportsTable).values({
    reportMonth,
    periodStart: start,
    periodEnd: end,
    totalMaintenanceFees: money(sum(feePayments)),
    completedMaintenanceFees: money(byStatus("completed")),
    pendingMaintenanceFees: money(byStatus("pending")),
    failedMaintenanceFees: money(byStatus("failed")),
    totalDeposits: money(sum(generalDeposits)),
    totalWithdrawals: money(sum(withdrawals)),
    transactionCount: deposits.length + withdrawals.length,
    details,
  }).$returningId();

  const [report] = await db.select().from(monthlyReportsTable).where(
    and(gte(monthlyReportsTable.periodStart, start), lt(monthlyReportsTable.periodStart, new Date(end.getTime() + 1))),
  ).limit(1);
  return { report: report ?? { id: inserted.id, reportMonth, periodStart: start, periodEnd: end, ...details }, created: true };
}

export function reportRows(report: any) {
  return [
    ["Report month", report.reportMonth],
    ["Maintenance fees submitted", report.totalMaintenanceFees],
    ["Maintenance fees confirmed", report.completedMaintenanceFees],
    ["Maintenance fees pending", report.pendingMaintenanceFees],
    ["Maintenance fee errors", report.failedMaintenanceFees],
    ["General deposits", report.totalDeposits],
    ["Withdrawals", report.totalWithdrawals],
    ["Transactions", report.transactionCount],
    ["Fee requests", report.details?.feePaymentCount ?? 0],
  ] as Array<[string, string | number]>;
}

export function reportToCsv(report: any) {
  return reportRows(report)
    .map(([label, value]) => `${JSON.stringify(label)},${JSON.stringify(String(value))}`)
    .join("\n") + "\n";
}

function pdfEscape(value: string) {
  return value.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
}

export function reportToPdf(report: any): Buffer {
  const lines = [`SPCX Monthly Report — ${report.reportMonth}`, "", ...reportRows(report).map(([label, value]) => `${label}: ${value}`)];
  const content = ["BT", "/F1 12 Tf", "50 760 Td", ...lines.flatMap((line, index) => [index ? "0 -22 Td" : "", `(${pdfEscape(line)}) Tj`]), "ET"].filter(Boolean).join("\n");
  const objects = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    `<< /Length ${Buffer.byteLength(content, "latin1")} >>\nstream\n${content}\nendstream`,
  ];
  let pdf = "%PDF-1.4\n";
  const offsets = [0];
  objects.forEach((object, index) => {
    offsets.push(Buffer.byteLength(pdf, "latin1"));
    pdf += `${index + 1} 0 obj\n${object}\nendobj\n`;
  });
  const xref = Buffer.byteLength(pdf, "latin1");
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i < offsets.length; i += 1) pdf += `${String(offsets[i]).padStart(10, "0")} 00000 n \n`;
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return Buffer.from(pdf, "latin1");
}
