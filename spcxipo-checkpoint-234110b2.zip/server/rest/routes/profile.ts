// @ts-nocheck
import { Router } from "express";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db, investorsTable } from "../../db";
import { storagePut } from "../../storage";
import { getInvestorSessionFromAuthorization } from "../lib/investorSession";
import { publishRealtimeEvent } from "../lib/realtime";

const router = Router();
const MAX_IMAGE_BYTES = 2 * 1024 * 1024;
const mimeToExtension: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
};

function requireInvestor(req: any, res: any) {
  const session = getInvestorSessionFromAuthorization(req.headers.authorization);
  if (!session) {
    res.status(401).json({ error: "Your session has expired. Please sign in again." });
    return null;
  }
  return session;
}

router.get("/profile", async (req, res) => {
  const session = requireInvestor(req, res);
  if (!session) return;

  const [investor] = await db
    .select({ fullName: investorsTable.fullName, email: investorsTable.email, avatarUrl: investorsTable.avatarUrl })
    .from(investorsTable)
    .where(eq(investorsTable.email, session.email))
    .limit(1);

  if (!investor) {
    res.status(404).json({ error: "Investor not found." });
    return;
  }

  res.json(investor);
});

router.post("/profile/avatar", async (req, res) => {
  const session = requireInvestor(req, res);
  if (!session) return;

  const parsed = z.object({ imageData: z.string().min(1) }).safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Select a valid image." });
    return;
  }

  const match = parsed.data.imageData.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/);
  if (!match) {
    res.status(400).json({ error: "Use a JPEG, PNG, or WebP image." });
    return;
  }

  const [, mimeType, encoded] = match;
  const bytes = Buffer.from(encoded, "base64");
  if (bytes.length === 0 || bytes.length > MAX_IMAGE_BYTES) {
    res.status(400).json({ error: "Image must be smaller than 2 MB." });
    return;
  }

  try {
    const [investor] = await db
      .select({ id: investorsTable.id })
      .from(investorsTable)
      .where(eq(investorsTable.email, session.email))
      .limit(1);
    if (!investor) {
      res.status(404).json({ error: "Investor not found." });
      return;
    }

    const { url } = await storagePut(
      `investors/${investor.id}/profile.${mimeToExtension[mimeType]}`,
      bytes,
      mimeType,
    );
    await db.update(investorsTable).set({ avatarUrl: url }).where(eq(investorsTable.id, investor.id));
    publishRealtimeEvent("investors", "avatar-updated");
    res.json({ avatarUrl: url });
  } catch (err) {
    console.error({ err }, "Failed to upload investor avatar");
    res.status(500).json({ error: "Unable to upload this image right now." });
  }
});

export default router;
