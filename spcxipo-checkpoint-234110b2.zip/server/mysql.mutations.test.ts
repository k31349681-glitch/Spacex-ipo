import express from "express";
import { createServer } from "node:http";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { eq } from "drizzle-orm";
import restRouter from "./rest/routes";
import {
  db,
  depositAddressesTable,
  depositsTable,
  holdingsTable,
  investorsTable,
  notificationsTable,
  withdrawalsTable,
} from "./db";

let server: ReturnType<typeof createServer>;
let baseUrl = "";
let investorId = 0;
let createdDepositAddress = false;
const email = `mysql-e2e-${Date.now()}@example.test`;
const password = "TestPass2026";
const adminPassword = process.env.ADMIN_PASSWORD_URLENCODED
  ? decodeURIComponent(process.env.ADMIN_PASSWORD_URLENCODED)
  : process.env.ADMIN_PASSWORD ?? "";
const previousResendKey = process.env.RESEND_API_KEY;

async function request(path: string, options: RequestInit = {}) {
  return fetch(`${baseUrl}/api${path}`, {
    ...options,
    headers: { "content-type": "application/json", ...(options.headers ?? {}) },
  });
}

async function adminRequest(path: string, options: RequestInit = {}) {
  return request(path, {
    ...options,
    headers: { "x-admin-password": adminPassword, ...(options.headers ?? {}) },
  });
}

beforeAll(async () => {
  expect(adminPassword).toBeTruthy();
  delete process.env.RESEND_API_KEY;
  const app = express();
  app.use(express.json());
  app.use("/api", restRouter);
  server = createServer(app);
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  if (!address || typeof address === "string") throw new Error("Test server did not bind");
  baseUrl = `http://127.0.0.1:${address.port}`;
});

afterAll(async () => {
  if (investorId) {
    await db.delete(notificationsTable).where(eq(notificationsTable.investorId, investorId));
    await db.delete(withdrawalsTable).where(eq(withdrawalsTable.investorId, investorId));
    await db.delete(depositsTable).where(eq(depositsTable.investorId, investorId));
    await db.delete(holdingsTable).where(eq(holdingsTable.investorId, investorId));
    await db.delete(investorsTable).where(eq(investorsTable.id, investorId));
  }
  if (createdDepositAddress) {
    await db.delete(depositAddressesTable).where(eq(depositAddressesTable.coin, "DOGE"));
  }
  if (previousResendKey) process.env.RESEND_API_KEY = previousResendKey;
  await new Promise<void>((resolve) => server.close(() => resolve()));
});

describe("MySQL/TiDB mutation compatibility", () => {
  it("completes investor, admin, deposit, trade, withdrawal, and notification workflows", async () => {
    const registration = await request("/investors", {
      method: "POST",
      body: JSON.stringify({ fullName: "MySQL E2E Investor", phone: "+441234567890", email, password }),
    });
    expect(registration.status).toBe(201);
    const registered = await registration.json() as { id: number; status: string };
    investorId = registered.id;
    expect(registered.status).toBe("pending");

    const duplicate = await request("/investors", {
      method: "POST",
      body: JSON.stringify({ fullName: "Duplicate", phone: "+441234567890", email, password }),
    });
    expect(duplicate.status).toBe(409);

    const signin = await request("/signin", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    });
    expect(signin.status).toBe(200);
    const signedIn = await signin.json() as { token: string };
    expect(signedIn.token).toBeTruthy();

    const unauthorizedProfile = await request("/profile");
    expect(unauthorizedProfile.status).toBe(401);

    const profile = await request("/profile", {
      headers: { authorization: `Bearer ${signedIn.token}` },
    });
    expect(profile.status).toBe(200);

    const avatar = await request("/profile/avatar", {
      method: "POST",
      headers: { authorization: `Bearer ${signedIn.token}` },
      body: JSON.stringify({
        imageData: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=",
      }),
    });
    expect(avatar.status).toBe(200);
    expect((await avatar.json() as { avatarUrl: string }).avatarUrl).toMatch(/^\/manus-storage\//);

    const approval = await adminRequest(`/admin/investors/${investorId}/status`, {
      method: "PATCH",
      body: JSON.stringify({ status: "approved" }),
    });
    expect(approval.status).toBe(200);

    const withdrawalAccess = await adminRequest(`/admin/investors/${investorId}/withdrawal-access`, {
      method: "PATCH",
      body: JSON.stringify({ withdrawalEnabled: true }),
    });
    expect(withdrawalAccess.status).toBe(200);

    const credit = await adminRequest(`/admin/investors/${investorId}/credit`, {
      method: "POST",
      body: JSON.stringify({ shares: 1000, pricePerShare: 100 }),
    });
    expect(credit.status).toBe(200);

    const deposit = await request("/deposits", {
      method: "POST",
      body: JSON.stringify({ email, amount: 10, method: "crypto", coin: "BTC" }),
    });
    expect(deposit.status).toBe(201);
    const createdDeposit = await deposit.json() as { id: number };

    const completeDeposit = await adminRequest(`/admin/deposits/${createdDeposit.id}/status`, {
      method: "PATCH",
      body: JSON.stringify({ status: "completed" }),
    });
    expect(completeDeposit.status).toBe(200);

    const invalidFee = await request("/deposits", {
      method: "POST",
      body: JSON.stringify({ email, amount: 60, purpose: "maintenance_fee", feePart: "full", method: "crypto", coin: "BTC" }),
    });
    expect(invalidFee.status).toBe(400);

    const halfFee = await request("/deposits", {
      method: "POST",
      body: JSON.stringify({ email, amount: 35, purpose: "maintenance_fee", feePart: "half", method: "crypto", coin: "BTC" }),
    });
    expect(halfFee.status).toBe(201);
    const createdHalfFee = await halfFee.json() as { id: number; feePart: string };
    expect(createdHalfFee.feePart).toBe("half");

    const completeHalfFee = await adminRequest(`/admin/deposits/${createdHalfFee.id}/status`, {
      method: "PATCH",
      body: JSON.stringify({ status: "completed" }),
    });
    expect(completeHalfFee.status).toBe(200);

    const fullFee = await request("/deposits", {
      method: "POST",
      body: JSON.stringify({ email, amount: 70, purpose: "maintenance_fee", feePart: "full", method: "crypto", coin: "BTC" }),
    });
    expect(fullFee.status).toBe(201);
    expect((await fullFee.json() as { feePart: string }).feePart).toBe("full");

    const buy = await request("/trade/buy", {
      method: "POST",
      body: JSON.stringify({ email, amountUsd: 1 }),
    });
    expect(buy.status).toBe(200);

    const withdrawal = await request("/withdrawals", {
      method: "POST",
      body: JSON.stringify({ email, amount: 1, coin: "BTC", address: "bc1q-test-wallet-address" }),
    });
    expect(withdrawal.status).toBe(201);
    const createdWithdrawal = await withdrawal.json() as { id: number };

    const failWithdrawal = await adminRequest(`/admin/withdrawals/${createdWithdrawal.id}/status`, {
      method: "PATCH",
      body: JSON.stringify({ status: "failed" }),
    });
    expect(failWithdrawal.status).toBe(200);

    const notification = await adminRequest("/admin/notifications", {
      method: "POST",
      body: JSON.stringify({ email, message: "Compatibility test notification" }),
    });
    expect(notification.status).toBe(201);

    const publicConfig = await request("/site-config");
    expect(publicConfig.status).toBe(200);
    const config = await publicConfig.json() as { sellingEnabled: boolean; marketPrice: number; marketCap: string };
    const configUpdate = await adminRequest("/admin/site-config", {
      method: "PATCH",
      body: JSON.stringify(config),
    });
    expect(configUpdate.status).toBe(200);

    const existingAddresses = await request("/deposit-addresses");
    const addresses = await existingAddresses.json() as Array<{ coin: string; address: string }>;
    const doge = addresses.find((address) => address.coin === "DOGE");
    const addressValue = doge?.address ?? "DOGE-compatibility-test-address";
    createdDepositAddress = !doge;
    const addressUpdate = await adminRequest("/admin/deposit-addresses/DOGE", {
      method: "PUT",
      body: JSON.stringify({ address: addressValue }),
    });
    expect(addressUpdate.status).toBe(200);
  }, 30_000);
});
