// @ts-nocheck
import { Router } from "express";
import { getRealtimeEventsAfter, realtimeEvents } from "../lib/realtime";

const router = Router();

router.get("/events", (req, res) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders?.();

  const writeEvent = (event: unknown) => {
    res.write(`data: ${JSON.stringify(event)}\n\n`);
  };
  const onEvent = (event: unknown) => writeEvent(event);
  const keepAlive = setInterval(() => res.write(": keep-alive\n\n"), 25000);
  let lastEventId = 0;
  const poll = setInterval(async () => {
    try {
      const events = await getRealtimeEventsAfter(lastEventId);
      for (const event of events) {
        lastEventId = event.id;
        writeEvent({ type: "refresh", resource: event.resource, action: event.action, at: event.createdAt.toISOString(), id: event.id });
      }
    } catch {
      // A transient broker/database error must not terminate the SSE stream.
    }
  }, 2000);

  realtimeEvents.on("event", onEvent);
  writeEvent({ type: "connected" });

  req.on("close", () => {
    clearInterval(keepAlive);
    clearInterval(poll);
    realtimeEvents.off("event", onEvent);
  });
});

export default router;
