import { describe, expect, it } from "vitest";
import { hashPassword, verifyPassword } from "./rest/lib/password";

describe("investor password verification", () => {
  it("accepts the original password and rejects a different password", () => {
    const stored = hashPassword("correct horse battery staple");

    expect(verifyPassword("correct horse battery staple", stored)).toBe(true);
    expect(verifyPassword("wrong password", stored)).toBe(false);
  });

  it("fails closed for malformed stored hashes", () => {
    expect(verifyPassword("anything", "not-a-valid-hash")).toBe(false);
    expect(verifyPassword("anything", "")).toBe(false);
  });
});
