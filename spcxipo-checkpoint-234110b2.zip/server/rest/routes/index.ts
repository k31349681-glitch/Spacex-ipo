// @ts-nocheck
import { Router, type IRouter } from "express";
import healthRouter from "./health";
import investorsRouter from "./investors";
import authRouter from "./auth";
import stockRouter from "./stock";
import adminRouter from "./admin";
import depositsRouter from "./deposits";
import holdingsRouter from "./holdings";
import tradeRouter from "./trade";
import notificationsRouter from "./notifications";
import assistantRouter from "./assistant";
import withdrawalsRouter from "./withdrawals";
import analyticsRouter from "./analytics";
import realtimeRouter from "./realtime";
import profileRouter from "./profile";
import scheduledRouter from "./scheduled";
import predictionsRouter from "./predictions";

const router: IRouter = Router();

router.use(healthRouter);
router.use(investorsRouter);
router.use(authRouter);
router.use(stockRouter);
router.use(adminRouter);
router.use(depositsRouter);
router.use(holdingsRouter);
router.use(tradeRouter);
router.use(notificationsRouter);
router.use(assistantRouter);
router.use(withdrawalsRouter);
router.use(analyticsRouter);
router.use(realtimeRouter);
router.use(profileRouter);
router.use(scheduledRouter);
router.use(predictionsRouter);

export default router;
