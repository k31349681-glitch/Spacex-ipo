import { afterEach, describe, expect, it, vi } from "vitest";
import { publishRealtimeEvent, realtimeEvents } from "./rest/lib/realtime";

describe("realtime event hub", () => {
  afterEach(() => realtimeEvents.removeAllListeners());

  it("publishes resource-specific mutation events", () => {
    const listener = vi.fn();
    realtimeEvents.on("event", listener);

    publishRealtimeEvent("deposits", "status-updated");

    expect(listener).toHaveBeenCalledOnce();
    expect(listener.mock.calls[0]?.[0]).toMatchObject({
      type: "refresh",
      resource: "deposits",
      action: "status-updated",
    });
  });
});
