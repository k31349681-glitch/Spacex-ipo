// @ts-nocheck
import { Router } from "express";
import { db, investorsTable, holdingsTable, siteConfigTable, notificationsTable, sellAccessAuditTable } from "../../db";
import { BuySharesBody, SellSharesBody } from "../api-zod";
import { eq } from "drizzle-orm";
import { getCurrentStockPrice, getMarketConfig } from "../lib/stock";
import { publishRealtimeEvent } from "../lib/realtime";

const router = Router();

async function getSellingEnabled(): Promise<boolean> {
  const [config] = await db.select().from(siteConfigTable).where(eq(siteConfigTable.id, 1)).limit(1);
  return config?.sellingEnabled ?? false;
}

async function getSellEligibilityConfig() {
  const [config] = await db.select().from(siteConfigTable).where(eq(siteConfigTable.id, 1)).limit(1);
  return {
    minimumShares: Number(config?.sellMinimumShares ?? 1000),
    instantBuyShares: Number(config?.instantBuyShares ?? 3),
    durationMinutes: Number(config?.sellAccessDurationMinutes ?? 60),
    message: config?.sellingEligibilityMessage ?? "Hold at least 1,000 SPCX shares to sell. Investors below that threshold may unlock a one-hour selling window by completing the minimum instant purchase while selling is enabled.",
  };
}

// GET /api/site-config — public platform configuration
router.get("/site-config", async (req, res) => {
  try {
    const sellingEnabled = await getSellingEnabled();
    const { marketPrice, marketCap, activityTickerEnabled } = await getMarketConfig();
    const [config] = await db.select().from(siteConfigTable).where(eq(siteConfigTable.id, 1)).limit(1);
    res.json({
      sellingEnabled,
      activityTickerEnabled,
      marketPrice,
      marketCap,
      btcPayoutMultiplier: Number(config?.btcPayoutMultiplier ?? 1.9),
      btcContractMinutes: Number(config?.btcContractMinutes ?? 5),
      btcMaxStake: Number(config?.btcMaxStake ?? 100),
      btcDailyLimit: Number(config?.btcDailyLimit ?? 500),
      sellMinimumShares: Number(config?.sellMinimumShares ?? 1000),
      instantBuyShares: Number(config?.instantBuyShares ?? 3),
      sellAccessDurationMinutes: Number(config?.sellAccessDurationMinutes ?? 60),
      sellingEligibilityMessage: config?.sellingEligibilityMessage ?? "Hold at least 1,000 SPCX shares to sell. Investors below that threshold may unlock a one-hour selling window by completing the minimum instant purchase while selling is enabled.",
      withdrawalFeeAmount: Number(config?.withdrawalFeeAmount ?? 0),
      launchDayEnabled: Boolean(config?.launchDayEnabled),
      highShareWithdrawalEnabled: config?.highShareWithdrawalEnabled !== false,
    });
  } catch (err) {
    console.error({ err }, "Failed to get site config");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// POST /api/trade/buy — spend cash balance to buy shares at the current quote
router.post("/trade/buy", async (req, res) => {
  const parsed = BuySharesBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid input. Provide email and amountUsd." });
    return;
  }
  const { email, amountUsd } = parsed.data;

  try {
    const [investor] = await db
      .select()
      .from(investorsTable)
      .where(eq(investorsTable.email, email.toLowerCase().trim()))
      .limit(1);

    if (!investor) {
      res.status(404).json({ error: "Investor not found." });
      return;
    }
    if (investor.status !== "approved") {
      res.status(403).json({ error: "Only approved investors can trade." });
      return;
    }

    const [existing] = await db.select().from(holdingsTable).where(eq(holdingsTable.investorId, investor.id)).limit(1);
    const cashBalance = parseFloat(existing?.cashBalance ?? "0");

    if (amountUsd > cashBalance) {
      res.status(400).json({ error: "Insufficient cash balance." });
      return;
    }

    const price = await getCurrentStockPrice();
    const sharesBought = amountUsd / price;
    const existingShares = parseFloat(existing?.shares ?? "0");
    const existingAvg = parseFloat(existing?.avgCost ?? "0");
    const totalShares = existingShares + sharesBought;
    const newAvgCost = totalShares > 0 ? (existingShares * existingAvg + sharesBought * price) / totalShares : 0;
    const newCashBalance = cashBalance - amountUsd;
    const eligibility = await getSellEligibilityConfig();
    const temporaryAccessAlreadyActive = Boolean(investor.sellAccessExpiresAt && investor.sellAccessExpiresAt.getTime() > Date.now());
    const unlocksSellAccess = sharesBought >= eligibility.instantBuyShares && totalShares < eligibility.minimumShares && !temporaryAccessAlreadyActive;
    const sellAccessExpiresAt = unlocksSellAccess
      ? new Date(Date.now() + eligibility.durationMinutes * 60_000)
      : investor.sellAccessExpiresAt;
    if (unlocksSellAccess) {
      await db.update(investorsTable).set({ sellAccessExpiresAt }).where(eq(investorsTable.id, investor.id));
      await db.insert(sellAccessAuditTable).values({
        investorId: investor.id,
        action: "automatic_unlock",
        previousExpiresAt: investor.sellAccessExpiresAt,
        newExpiresAt: sellAccessExpiresAt,
        source: "instant_buy",
      });
      await db.insert(notificationsTable).values({
        investorId: investor.id,
        message: `Your purchase unlocked a ${eligibility.durationMinutes}-minute selling window, active until ${sellAccessExpiresAt.toLocaleString()}.`,
        read: false,
      });
      publishRealtimeEvent("notifications", "sell-access-activated");
    }

    await db
      .insert(holdingsTable)
      .values({
        investorId: investor.id,
        shares: String(totalShares),
        avgCost: String(newAvgCost),
        cashBalance: String(newCashBalance),
        updatedAt: new Date(),
      })
      .onDuplicateKeyUpdate({
        set: {
          shares: String(totalShares),
          avgCost: String(newAvgCost),
          cashBalance: String(newCashBalance),
          updatedAt: new Date(),
        },
      });
    const [holding] = await db.select().from(holdingsTable).where(eq(holdingsTable.investorId, investor.id)).limit(1);

    if (investor.tradeNotifications) {
      await db.insert(notificationsTable).values({
        investorId: investor.id,
        message: `Share bought: ${sharesBought.toFixed(4)} SPCX for $${amountUsd.toFixed(2)}.`,
      });
    }

    publishRealtimeEvent("holdings", "buy");
    res.json({
      investorId: holding.investorId,
      shares: holding.shares,
      avgCost: holding.avgCost,
      cashBalance: holding.cashBalance,
      sellAccessExpiresAt: sellAccessExpiresAt?.toISOString() ?? null,
      updatedAt: holding.updatedAt.toISOString(),
    });
  } catch (err) {
    console.error({ err }, "Failed to buy shares");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// POST /api/trade/sell — sell shares back for cash at the current quote (admin-gated)
router.post("/trade/sell", async (req, res) => {
  const parsed = SellSharesBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid input. Provide email and shares." });
    return;
  }
  const { email, shares: sellShares } = parsed.data;

  try {
    const sellingEnabled = await getSellingEnabled();
    if (!sellingEnabled) {
      res.status(403).json({ error: "Selling is currently disabled by the platform admin." });
      return;
    }

    const [investor] = await db
      .select()
      .from(investorsTable)
      .where(eq(investorsTable.email, email.toLowerCase().trim()))
      .limit(1);

    if (!investor) {
      res.status(404).json({ error: "Investor not found." });
      return;
    }
    if (investor.status !== "approved") {
      res.status(403).json({ error: "Only approved investors can trade." });
      return;
    }

    const [existing] = await db.select().from(holdingsTable).where(eq(holdingsTable.investorId, investor.id)).limit(1);
    const ownedShares = parseFloat(existing?.shares ?? "0");
    const eligibility = await getSellEligibilityConfig();
    const temporaryAccessActive = Boolean(investor.sellAccessExpiresAt && investor.sellAccessExpiresAt.getTime() > Date.now());
    if (ownedShares < eligibility.minimumShares && !temporaryAccessActive) {
      res.status(403).json({ error: eligibility.message, shares: ownedShares, minimumShares: eligibility.minimumShares, instantBuyShares: eligibility.instantBuyShares });
      return;
    }

    if (sellShares > ownedShares) {
      res.status(400).json({ error: "You cannot sell more shares than you own." });
      return;
    }

    const price = await getCurrentStockPrice();
    const proceeds = sellShares * price;
    const remainingShares = ownedShares - sellShares;
    const newAvgCost = remainingShares > 0 ? parseFloat(existing?.avgCost ?? "0") : 0;
    const newCashBalance = parseFloat(existing?.cashBalance ?? "0") + proceeds;

    await db
      .insert(holdingsTable)
      .values({
        investorId: investor.id,
        shares: String(remainingShares),
        avgCost: String(newAvgCost),
        cashBalance: String(newCashBalance),
        updatedAt: new Date(),
      })
      .onDuplicateKeyUpdate({
        set: {
          shares: String(remainingShares),
          avgCost: String(newAvgCost),
          cashBalance: String(newCashBalance),
          updatedAt: new Date(),
        },
      });
    const [holding] = await db.select().from(holdingsTable).where(eq(holdingsTable.investorId, investor.id)).limit(1);

    if (investor.tradeNotifications) {
      await db.insert(notificationsTable).values({
        investorId: investor.id,
        message: `Share sold: ${sellShares.toFixed(4)} SPCX for $${proceeds.toFixed(2)}.`,
      });
    }

    publishRealtimeEvent("holdings", "sell");
    res.json({
      investorId: holding.investorId,
      shares: holding.shares,
      avgCost: holding.avgCost,
      cashBalance: holding.cashBalance,
      sellAccessExpiresAt: investor.sellAccessExpiresAt?.toISOString() ?? null,
      updatedAt: holding.updatedAt.toISOString(),
    });
  } catch (err) {
    console.error({ err }, "Failed to sell shares");
    res.status(500).json({ error: "Something went wrong." });
  }
});

export default router;
