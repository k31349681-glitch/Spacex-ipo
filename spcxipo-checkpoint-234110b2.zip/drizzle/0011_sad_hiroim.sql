ALTER TABLE `investors` ADD `sell_access_expires_at` timestamp;--> statement-breakpoint
ALTER TABLE `site_config` ADD `sell_minimum_shares` decimal(18,4) DEFAULT '1000' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_config` ADD `instant_buy_shares` decimal(18,4) DEFAULT '3' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_config` ADD `sell_access_duration_minutes` int DEFAULT 60 NOT NULL;--> statement-breakpoint
ALTER TABLE `site_config` ADD `selling_eligibility_message` text DEFAULT ('Hold at least 1,000 SPCX shares to sell. Investors below that threshold may unlock a one-hour selling window by completing the minimum instant purchase while selling is enabled.') NOT NULL;