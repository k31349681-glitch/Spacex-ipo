// @ts-nocheck
import { Router } from "express";
import { and, eq, gte } from "drizzle-orm";
import { db, investorsTable, notificationsTable } from "../../db";
import { publishRealtimeEvent } from "../lib/realtime";
import { generateMonthlyReport, previousMonth } from "../lib/monthlyReports";
import { sendMonthlyReportEmail } from "../lib/email";

const router = Router();
const PUBLIC_URL = "https://spcxipoportal.pages.dev";

async function getJson(path: string) {
  const response = await fetch(`${PUBLIC_URL}${path}`, {
    headers: { "user-agent": "SPCX-Daily-Health/1.0" },
    signal: AbortSignal.timeout(12_000),
  });
  const body = await response.json().catch(() => null);
  return { ok: response.ok, status: response.status, body };
}

// Side-effect-free and idempotent: safe for platform retries.
router.post("/scheduled/daily-health", async (_req, res) => {
  const checkedAt = new Date().toISOString();
  try {
    const [health, quote] = await Promise.all([
      getJson("/api/healthz"),
      getJson("/api/stock/quote"),
    ]);
    const quoteValid = quote.ok && quote.body?.symbol === "SPCX" && Number.isFinite(quote.body?.price);
    const healthy = health.ok && health.body?.status === "ok" && health.body?.database === "ok" && quoteValid;
    const result = {
      ok: healthy,
      checkedAt,
      deploymentUrl: PUBLIC_URL,
      checks: {
        https: health.ok,
        database: health.body?.database === "ok",
        liveQuote: quoteValid,
      },
      quotePrice: quote.body?.price ?? null,
    };
    res.status(healthy ? 200 : 503).json(result);
  } catch (err) {
    res.status(503).json({
      ok: false,
      checkedAt,
      deploymentUrl: PUBLIC_URL,
      error: err instanceof Error ? err.message : String(err),
    });
  }
});

// Monthly maintenance-fee reminder. Safe to retry: one reminder is created per investor per month.
router.post("/scheduled/monthly-maintenance-fees", async (_req, res) => {
  try {
    const now = new Date();
    const dueDay = now.getUTCDate();
    if (dueDay !== 5 && dueDay !== 20) return res.json({ ok: true, skipped: "not-due-day" });

    const monthStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
    const investors = await db.select({ id: investorsTable.id }).from(investorsTable).where(eq(investorsTable.status, "approved"));
    let created = 0;
    for (const investor of investors) {
      const existing = await db.select({ id: notificationsTable.id }).from(notificationsTable).where(and(
        eq(notificationsTable.investorId, investor.id),
        gte(notificationsTable.createdAt, monthStart),
      ));
      if (existing.some((row) => row.id)) {
        const messages = await db.select({ message: notificationsTable.message }).from(notificationsTable).where(and(
          eq(notificationsTable.investorId, investor.id),
          gte(notificationsTable.createdAt, monthStart),
        ));
        if (messages.some((row) => row.message.startsWith("Monthly fee payment due"))) continue;
      }
      await db.insert(notificationsTable).values({
        investorId: investor.id,
          message: dueDay === 5
            ? "Monthly fee payment due: $35.00 half payment is available from the 5th–10th, or settle the full $70.00 monthly fee."
            : "Monthly fee payment due: the second $35.00 half payment is available from the 20th–26th, or settle the full $70.00 monthly fee.",
      });
      created += 1;
    }
    if (created > 0) publishRealtimeEvent("notifications", "maintenance-fee-reminder");
    res.json({ ok: true, created, month: `${now.getUTCFullYear()}-${String(now.getUTCMonth() + 1).padStart(2, "0")}` });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : String(err) });
  }
});

// Generate the previous calendar month's fee and transaction summary. Safe to retry because reportMonth is unique.
router.post("/scheduled/monthly-maintenance-report", async (_req, res) => {
  try {
    const now = new Date();
    if (now.getUTCDate() !== 1) return res.json({ ok: true, skipped: "not-report-day" });
    const period = previousMonth(now);
    const result = await generateMonthlyReport(period.reportMonth, period.start, period.end);
    const recipient = process.env.ADMIN_REPORT_EMAIL?.trim();
    const emailSent = Boolean(result.created && recipient && await sendMonthlyReportEmail({ to: recipient, report: result.report }));
    res.json({ ok: true, reportMonth: period.reportMonth, created: result.created, emailSent, emailConfigured: Boolean(recipient), report: result.report });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : String(err) });
  }
});

export default router;
