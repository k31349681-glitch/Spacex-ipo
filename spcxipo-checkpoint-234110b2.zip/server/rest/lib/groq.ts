// @ts-nocheck
import OpenAI from "openai";

let client: OpenAI | null = null;

function getClient() {
  if (!process.env.GROQ_API_KEY) {
    throw new Error("GROQ_API_KEY is not configured");
  }
  client ??= new OpenAI({
    apiKey: process.env.GROQ_API_KEY,
    baseURL: "https://api.groq.com/openai/v1",
  });
  return client;
}

export const groq = new Proxy({} as OpenAI, {
  get(_target, property) {
    const value = (getClient() as any)[property];
    return typeof value === "function" ? value.bind(getClient()) : value;
  },
});

export const GROQ_CHAT_MODEL = "openai/gpt-oss-120b";
