# SPCX Platform Migration Todo

## Completed

- Migrated the SPCX investor frontend and REST backend into Manus full-stack hosting.
- Added the investor, deposit, holdings, notifications, withdrawal, password-token, site configuration, and analytics data model to MySQL/TiDB.
- Added the protected admin panel using the server-side `ADMIN_PASSWORD` secret.
- Configured the supplied `RESEND_API_KEY` and `GROQ_API_KEY` as server-only secrets; both credentials passed lightweight provider API smoke tests.
- Added Resend investor approval/rejection email integration and the lazy Groq support-assistant integration.
- Replaced the fixed 15-second SSE refresh fallback with an event hub that publishes resource/action-specific mutation events for investor, deposit, holding, notification, withdrawal, address, and site-configuration changes.
- Added frontend SSE subscription and query invalidation on mutation events.
- Added privacy-minimized analytics ingestion at `/api/analytics/events`.
- Verified the live preview health endpoint, market quote endpoint, analytics endpoint, and SSE connection.
- Verified `pnpm test` with 7 passing tests, `pnpm check`, and `pnpm build`.

## Remaining hosting action

The publish-ready Manus checkpoint is saved. The remaining external action is attaching the production Manus hostname to `spacexipo.jo3.org` and updating the FreeDomain.one DNS A records/CNAME as required by the published hostname, after which Manus can provision SSL for the custom domain.
