import { getInvestorSession, clearInvestorSession } from '@/lib/session';
import React, { useMemo, useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Menu, ArrowLeft, BarChart3, HelpCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { useQueryClient } from '@tanstack/react-query';
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import {
  useGetStockQuote,
  getGetStockQuoteQueryKey,
  useGetStockHistory,
  getGetStockHistoryQueryKey,
  GetStockHistoryPeriod,
  useGetHoldings,
  getGetHoldingsQueryKey,
  useGetSiteConfig,
  useBuyShares,
  useSellShares,
} from '@/api-client-react';
import SideNav from '../components/SideNav';
import NotificationBell from '../components/NotificationBell';
import LiveActivityTicker from '../components/LiveActivityTicker';
import BtcPredictionMarket from '../components/BtcPredictionMarket';

type Mode = 'buy' | 'sell';

export default function Trade() {
  const [, setLocation] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [mode, setMode] = useState<Mode>('buy');
  const [buyAmount, setBuyAmount] = useState('');
  const [sellShares, setSellShares] = useState('');
  const [clock, setClock] = useState(() => Date.now());
  const [showUnlockConfirm, setShowUnlockConfirm] = useState(false);
  const queryClient = useQueryClient();
  const user = typeof window !== 'undefined' ? getInvestorSession() : null;
  const email: string = user?.email ?? '';

  useEffect(() => {
    if (!user) setLocation('/signin');
  }, [user, setLocation]);

  useEffect(() => {
    const timer = window.setInterval(() => setClock(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const { data: quote } = useGetStockQuote({ query: { refetchInterval: 2000, queryKey: getGetStockQuoteQueryKey() } });
  const historyPeriod = '1D' as GetStockHistoryPeriod;
  const { data: history } = useGetStockHistory({ period: historyPeriod }, { query: { refetchInterval: 15000, queryKey: getGetStockHistoryQueryKey({ period: historyPeriod }) } });
  const { data: holdings } = useGetHoldings({ email }, { query: { enabled: !!email, queryKey: getGetHoldingsQueryKey({ email }) } });
  const { data: siteConfig } = useGetSiteConfig();
  const buyMutation = useBuyShares();
  const sellMutation = useSellShares();

  const handleSignOut = () => {
    clearInvestorSession();
    setLocation('/');
  };

  const price = quote?.price ?? 147.62;
  const cashBalance = parseFloat(holdings?.cashBalance ?? '0');
  const ownedShares = parseFloat(holdings?.shares ?? '0');
  const sellingEnabled = siteConfig?.sellingEnabled ?? false;
  const eligibilityConfig = (siteConfig ?? {}) as typeof siteConfig & { sellMinimumShares?: number; instantBuyShares?: number; sellAccessDurationMinutes?: number; sellingEligibilityMessage?: string };
  const minimumSellShares = Number(eligibilityConfig.sellMinimumShares ?? 1000);
  const instantBuyShares = Number(eligibilityConfig.instantBuyShares ?? 3);
  const sellAccessDurationMinutes = Number(eligibilityConfig.sellAccessDurationMinutes ?? 60);
  const eligibilityMessage = eligibilityConfig.sellingEligibilityMessage ?? 'Hold at least 1,000 SPCX shares to sell. Investors below that threshold may unlock a one-hour selling window by completing the minimum instant purchase while selling is enabled.';
  const holdingWithAccess = holdings as typeof holdings & { sellAccessExpiresAt?: string | null } | undefined;
  const sellAccessExpiresMs = holdingWithAccess?.sellAccessExpiresAt ? Date.parse(holdingWithAccess.sellAccessExpiresAt) : 0;
  const temporarySellAccessActive = sellAccessExpiresMs > clock;
  const shareEligibleToSell = ownedShares >= minimumSellShares;
  const canSell = sellingEnabled && (shareEligibleToSell || temporarySellAccessActive);
  const sellAccessMinutesLeft = temporarySellAccessActive ? Math.max(0, Math.ceil((sellAccessExpiresMs - clock) / 60_000)) : 0;
  const buyAmountNum = parseFloat(buyAmount || '0');
  const estimatedShares = buyAmountNum > 0 ? buyAmountNum / price : 0;
  const instantBuyAmount = instantBuyShares * price;
  const sellSharesNum = parseFloat(sellShares || '0');
  const estimatedProceeds = sellSharesNum > 0 ? sellSharesNum * price : 0;
  const positive = (quote?.change ?? 0) >= 0;
  const chartColor = positive ? '#22c55e' : '#ef4444';

  const orderBook = useMemo(() => {
    const asks = [0.18, 0.12, 0.07].map((spread, index) => ({ price: price + spread, shares: 8.2 + index * 6.4 }));
    const bids = [0.05, 0.11, 0.19].map((spread, index) => ({ price: price - spread, shares: 11.8 + index * 7.1 }));
    return { asks: asks.reverse(), bids };
  }, [price]);

  const qualifiesForSellUnlock = !shareEligibleToSell && !temporarySellAccessActive && estimatedShares >= instantBuyShares;
  const placeBuy = () => {
    buyMutation.mutate({ data: { email, amountUsd: buyAmountNum } }, {
      onSuccess: () => {
        toast.success(`Bought approximately ${estimatedShares.toFixed(4)} SPCX shares.`);
        setBuyAmount('');
        queryClient.invalidateQueries({ queryKey: getGetHoldingsQueryKey({ email }) });
      },
      onError: (err: any) => toast.error(err?.data?.error || 'Failed to buy shares.'),
    });
  };

  const handleBuy = () => {
    if (!buyAmountNum || buyAmountNum <= 0) return toast.error('Enter a valid amount.');
    if (buyAmountNum > cashBalance) return toast.error('Insufficient cash balance. Deposit funds first.');
    if (qualifiesForSellUnlock) {
      setShowUnlockConfirm(true);
      return;
    }
    placeBuy();
  };

  const handleSell = () => {
    if (!sellSharesNum || sellSharesNum <= 0) return toast.error('Enter a valid number of shares.');
    if (sellSharesNum > ownedShares) return toast.error('You cannot sell more shares than you own.');
    sellMutation.mutate({ data: { email, shares: sellSharesNum } }, {
      onSuccess: () => {
        toast.success(`Sold ${sellSharesNum.toFixed(4)} SPCX shares for approximately $${estimatedProceeds.toFixed(2)}.`);
        setSellShares('');
        queryClient.invalidateQueries({ queryKey: getGetHoldingsQueryKey({ email }) });
      },
      onError: (err: any) => toast.error(err?.data?.error || 'Failed to sell shares.'),
    });
  };

  return (
    <div className="min-h-[100dvh] bg-[#070b10] text-white selection:bg-cyan-300/20 flex flex-col">
      <SideNav open={menuOpen} onClose={() => setMenuOpen(false)} onSignOut={handleSignOut} />
      <header className="flex items-center justify-between px-4 sm:px-6 py-4 border-b border-white/[0.07] bg-[#070b10]/95 backdrop-blur-xl">
        <div className="flex items-center gap-4">
          <button onClick={() => setLocation('/dashboard')} aria-label="Back to dashboard" className="p-2 text-white/60 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"><ArrowLeft className="w-5 h-5" /></button>
          <div className="hidden sm:flex items-center gap-2">
            <span className="font-display font-bold tracking-widest">SPCX</span>
            <span className="px-2 py-1 rounded bg-white/5 text-[10px] text-white/45 tracking-widest uppercase">Private market</span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-2 text-[10px] uppercase tracking-[0.18em] text-green-400"><span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" /> Market live</span>
          <button onClick={() => setMenuOpen(true)} aria-label="Open menu" className="p-2 text-white/60 hover:text-white cursor-pointer"><Menu className="w-5 h-5" /></button>
          <NotificationBell />
        </div>
      </header>
      <LiveActivityTicker />

      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        <div className="grid lg:grid-cols-[minmax(0,1fr)_390px] gap-5">
          <section className="space-y-5 min-w-0">
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="border border-white/[0.08] bg-[#0b1118] rounded-xl overflow-hidden">
              <div className="p-5 sm:p-6 border-b border-white/[0.07] flex flex-col sm:flex-row sm:items-start justify-between gap-5">
                <div>
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-11 h-11 rounded-full bg-white text-black grid place-items-center font-black text-sm">X</div>
                    <div>
                      <h1 className="text-xl sm:text-2xl font-bold">SpaceX pre-IPO shares</h1>
                      <p className="text-xs text-white/40 mt-1">SPCX · USD · Indicative internal market</p>
                    </div>
                  </div>
                  <div className="flex items-end gap-3">
                    <span className="text-4xl sm:text-5xl font-bold font-display tabular-nums">${price.toFixed(2)}</span>
                    <span className={`pb-1 text-sm font-bold ${positive ? 'text-green-400' : 'text-red-400'}`}>
                      {positive ? '+' : '-'}${Math.abs(quote?.change ?? 0).toFixed(2)} ({Math.abs(quote?.changePct ?? 0).toFixed(2)}%)
                    </span>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 text-right sm:min-w-52">
                  <div className="bg-black/20 rounded-lg p-3"><div className="text-[10px] text-white/35 uppercase tracking-widest">Bid</div><div className="font-bold text-green-400">${quote?.bid?.toFixed(2) ?? '—'}</div></div>
                  <div className="bg-black/20 rounded-lg p-3"><div className="text-[10px] text-white/35 uppercase tracking-widest">Ask</div><div className="font-bold text-red-400">${quote?.ask?.toFixed(2) ?? '—'}</div></div>
                </div>
              </div>

              <div className="h-[330px] px-2 pt-6 pb-3">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={history?.data ?? []} margin={{ top: 8, right: 12, left: 8, bottom: 0 }}>
                    <defs><linearGradient id="tradePrice" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={chartColor} stopOpacity={0.28} /><stop offset="100%" stopColor={chartColor} stopOpacity={0} /></linearGradient></defs>
                    <XAxis dataKey="time" axisLine={false} tickLine={false} minTickGap={45} tick={{ fill: '#66717d', fontSize: 10 }} />
                    <YAxis orientation="right" domain={['auto', 'auto']} axisLine={false} tickLine={false} width={52} tick={{ fill: '#66717d', fontSize: 10 }} tickFormatter={(value) => `$${Number(value).toFixed(0)}`} />
                    <Tooltip contentStyle={{ background: '#0b1118', border: '1px solid rgba(255,255,255,.12)', borderRadius: 8 }} formatter={(value) => [`$${Number(value).toFixed(2)}`, 'SPCX']} />
                    <Area type="monotone" dataKey="price" stroke={chartColor} strokeWidth={2.3} fill="url(#tradePrice)" animationDuration={450} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <div className="grid grid-cols-3 border-t border-white/[0.07]">
                <div className="p-4 border-r border-white/[0.07]"><div className="text-[10px] text-white/35 uppercase tracking-widest">24h volume</div><div className="font-bold mt-1">{quote?.volume ?? '25.69M'}</div></div>
                <div className="p-4 border-r border-white/[0.07]"><div className="text-[10px] text-white/35 uppercase tracking-widest">Market cap</div><div className="font-bold mt-1">{quote?.marketCap ?? '$1.92T'}</div></div>
                <div className="p-4"><div className="text-[10px] text-white/35 uppercase tracking-widest">Day range</div><div className="font-bold mt-1 text-xs sm:text-base">${quote?.dayLow?.toFixed(2) ?? '—'}–${quote?.dayHigh?.toFixed(2) ?? '—'}</div></div>
              </div>
            </motion.div>

            <div className="grid md:grid-cols-2 gap-5">
              <div className="border border-white/[0.08] bg-[#0b1118] rounded-xl p-5">
                <div className="flex items-center gap-2 mb-5"><BarChart3 className="w-4 h-4 text-cyan-300" /><h2 className="font-bold text-sm tracking-wide">Order book</h2></div>
                <div className="grid grid-cols-3 text-[10px] uppercase tracking-widest text-white/30 pb-2"><span>Side</span><span className="text-right">Price</span><span className="text-right">Shares</span></div>
                {orderBook.asks.map((row) => <div key={`a-${row.price}`} className="relative grid grid-cols-3 text-xs py-2.5"><div className="absolute inset-y-1 right-0 bg-red-500/5" style={{ width: `${Math.min(90, row.shares * 2)}%` }} /><span className="relative text-red-400">ASK</span><span className="relative text-right font-mono">${row.price.toFixed(2)}</span><span className="relative text-right text-white/50">{row.shares.toFixed(2)}</span></div>)}
                <div className="py-3 my-1 border-y border-white/[0.07] text-center font-mono font-bold text-sm">${price.toFixed(2)} <span className="text-white/30 font-sans text-[10px] ml-2">SPREAD $0.18</span></div>
                {orderBook.bids.map((row) => <div key={`b-${row.price}`} className="relative grid grid-cols-3 text-xs py-2.5"><div className="absolute inset-y-1 right-0 bg-green-500/5" style={{ width: `${Math.min(90, row.shares * 2)}%` }} /><span className="relative text-green-400">BID</span><span className="relative text-right font-mono">${row.price.toFixed(2)}</span><span className="relative text-right text-white/50">{row.shares.toFixed(2)}</span></div>)}
              </div>
            </div>
          </section>

          <aside className="lg:sticky lg:top-5 self-start border border-white/[0.09] bg-[#0b1118] rounded-xl overflow-hidden shadow-2xl shadow-black/30">
            <div className="grid grid-cols-2 p-1.5 bg-black/25 m-4 rounded-lg">
              <button onClick={() => setMode('buy')} className={`rounded-md py-3 text-sm font-bold transition-all cursor-pointer ${mode === 'buy' ? 'bg-green-500 text-[#061009] shadow-lg' : 'text-white/45 hover:text-white'}`}>Buy</button>
              <button onClick={() => setMode('sell')} className={`rounded-md py-3 text-sm font-bold transition-all cursor-pointer ${mode === 'sell' ? 'bg-red-500 text-white shadow-lg' : 'text-white/45 hover:text-white'}`}>Sell</button>
            </div>

            <div className="px-5 pb-5">
              <div className="flex justify-between text-xs mb-5"><span className="text-white/40">Available</span><span className="font-mono">{mode === 'buy' ? `$${cashBalance.toFixed(2)}` : `${ownedShares.toFixed(4)} SPCX`}</span></div>
              {mode === 'buy' ? (
                <>
                  <label className="text-xs text-white/45">Amount to invest</label>
                  <div className="mt-2 flex items-center rounded-lg border border-white/10 bg-black/25 px-4 focus-within:border-green-400/50">
                    <span className="text-xl text-white/45">$</span>
                    <input type="number" min="0" step="0.01" value={buyAmount} onChange={(event) => setBuyAmount(event.target.value)} placeholder="0.00" className="w-full bg-transparent px-3 py-4 text-2xl font-bold outline-none tabular-nums" />
                    <span className="text-xs text-white/30">USD</span>
                  </div>
                  <div className="grid grid-cols-4 gap-2 mt-3">
                    {[25, 50, 100].map((amount) => <button key={amount} onClick={() => setBuyAmount(String(Math.min(amount, cashBalance)))} className="rounded-md bg-white/5 py-2 text-xs text-white/60 hover:bg-white/10 cursor-pointer">${amount}</button>)}
                    <button onClick={() => setBuyAmount(cashBalance.toFixed(2))} className="rounded-md bg-white/5 py-2 text-xs text-white/60 hover:bg-white/10 cursor-pointer">Max</button>
                  </div>
                  {!shareEligibleToSell && <button onClick={() => setBuyAmount(instantBuyAmount.toFixed(2))} disabled={instantBuyAmount > cashBalance} className="w-full mt-3 rounded-md border border-cyan-300/30 bg-cyan-300/10 py-2 text-xs text-cyan-100 hover:bg-cyan-300/20 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer">Buy {instantBuyShares} shares to unlock {sellAccessDurationMinutes}-minute selling</button>}
                  <div className="my-5 space-y-3 text-xs"><div className="flex justify-between"><span className="text-white/40">Estimated shares</span><span>{estimatedShares.toFixed(4)} SPCX</span></div><div className="flex justify-between"><span className="text-white/40">Live price</span><span>${price.toFixed(2)}</span></div><div className="flex justify-between"><span className="text-white/40">Platform fee</span><span>$0.00</span></div></div>
                  {cashBalance <= 0 && <button onClick={() => setLocation('/orders')} className="w-full mb-3 text-xs text-yellow-300 hover:text-yellow-200 cursor-pointer">Deposit funds before placing an order</button>}
                  <button onClick={handleBuy} disabled={buyMutation.isPending || buyAmountNum <= 0 || buyAmountNum > cashBalance} className="w-full rounded-lg bg-green-500 py-4 font-bold text-[#061009] hover:bg-green-400 disabled:opacity-35 disabled:cursor-not-allowed transition-colors cursor-pointer">{buyMutation.isPending ? 'Placing order…' : 'Buy SPCX'}</button>
                </>
              ) : !sellingEnabled ? (
                <div className="rounded-lg border border-yellow-400/15 bg-yellow-400/5 p-5 text-center"><p className="text-sm text-white/65">Selling is currently unavailable. Your current balance is <strong>{ownedShares.toFixed(4)} SPCX</strong>; purchase SPCX shares to establish a position.</p><p className="text-xs text-white/35 mt-2">You can continue buying shares while selling is unavailable.</p></div>
              ) : !canSell ? (
                <div className="rounded-lg border border-yellow-400/15 bg-yellow-400/5 p-5 text-center"><div className="flex items-center justify-center gap-2 text-sm text-yellow-100"><span>Sell access is not yet available</span><HelpCircle className="w-4 h-4" /></div><p className="text-sm text-white/65 mt-3">Current balance: <strong>{ownedShares.toFixed(4)} SPCX</strong> · Required balance: <strong>{minimumSellShares.toLocaleString()} SPCX</strong></p><p className="text-xs text-white/40 mt-2">{eligibilityMessage}</p><button onClick={() => setMode('buy')} className="mt-4 rounded-md bg-cyan-300 px-4 py-2 text-xs font-bold text-black cursor-pointer">Buy {instantBuyShares} shares for a {sellAccessDurationMinutes}-minute window</button></div>
              ) : (
                <>
                  {temporarySellAccessActive && !shareEligibleToSell && <div className="mb-4 rounded-md border border-cyan-300/20 bg-cyan-300/10 p-3 text-xs text-cyan-100">Temporary sell access is active for {sellAccessMinutesLeft} more minute{sellAccessMinutesLeft === 1 ? '' : 's'}.</div>}
                  <label className="text-xs text-white/45">Shares to sell</label>
                  <div className="mt-2 flex items-center rounded-lg border border-white/10 bg-black/25 px-4 focus-within:border-red-400/50">
                    <input type="number" min="0" step="0.0001" value={sellShares} onChange={(event) => setSellShares(event.target.value)} placeholder="0.0000" className="w-full bg-transparent py-4 text-2xl font-bold outline-none tabular-nums" />
                    <span className="text-xs text-white/30">SPCX</span>
                  </div>
                  <div className="grid grid-cols-4 gap-2 mt-3">{[0.25, 0.5, 0.75, 1].map((portion) => <button key={portion} onClick={() => setSellShares((ownedShares * portion).toFixed(4))} className="rounded-md bg-white/5 py-2 text-xs text-white/60 hover:bg-white/10 cursor-pointer">{portion === 1 ? 'Max' : `${portion * 100}%`}</button>)}</div>
                  <div className="my-5 space-y-3 text-xs"><div className="flex justify-between"><span className="text-white/40">Estimated proceeds</span><span>${estimatedProceeds.toFixed(2)}</span></div><div className="flex justify-between"><span className="text-white/40">Live price</span><span>${price.toFixed(2)}</span></div><div className="flex justify-between"><span className="text-white/40">Platform fee</span><span>$0.00</span></div></div>
                  <button onClick={handleSell} disabled={sellMutation.isPending || sellSharesNum <= 0 || sellSharesNum > ownedShares} className="w-full rounded-lg bg-red-500 py-4 font-bold text-white hover:bg-red-400 disabled:opacity-35 disabled:cursor-not-allowed transition-colors cursor-pointer">{sellMutation.isPending ? 'Placing order…' : 'Sell SPCX'}</button>
                </>
              )}
              <details className="mt-4 rounded-md border border-white/10 bg-white/[0.03] p-3 text-xs text-white/45"><summary className="flex cursor-pointer list-none items-center gap-2 text-white/65"><HelpCircle className="w-4 h-4 text-cyan-300" /> How selling eligibility works</summary><div className="mt-3 space-y-2 leading-relaxed"><p>Investors with at least {minimumSellShares.toLocaleString()} SPCX shares can sell when selling is enabled.</p><p>Below that threshold, a purchase of at least {instantBuyShares} shares opens a {sellAccessDurationMinutes}-minute selling window. The administrator can close temporary access at any time.</p></div></details>
              <p className="mt-4 text-[10px] leading-relaxed text-white/25 text-center">Indicative private-market trading experience. Orders are subject to eligibility, availability, and platform terms.</p>
            </div>
          </aside>
        </div>
        <div className="mt-5"><BtcPredictionMarket cashBalance={cashBalance} onBalanceChange={() => queryClient.invalidateQueries({ queryKey: getGetHoldingsQueryKey({ email }) })} /></div>
      </main>
      {showUnlockConfirm && <div className="fixed inset-0 z-50 grid place-items-center bg-black/75 px-4" role="presentation" onMouseDown={() => setShowUnlockConfirm(false)}><div role="dialog" aria-modal="true" aria-labelledby="sell-window-title" className="w-full max-w-md rounded-xl border border-cyan-300/25 bg-[#0b1118] p-6 shadow-2xl" onMouseDown={(event) => event.stopPropagation()}><h2 id="sell-window-title" className="text-lg font-bold">Confirm temporary sell access</h2><p className="mt-3 text-sm leading-relaxed text-white/65">This purchase is expected to buy approximately <strong>{estimatedShares.toFixed(4)} SPCX shares</strong>. Because it meets the {instantBuyShares}-share trigger, it will activate a {sellAccessDurationMinutes}-minute selling window when selling is enabled.</p><p className="mt-3 text-xs leading-relaxed text-white/45">Selling remains subject to platform availability. The window expires automatically and an administrator may close it earlier.</p><div className="mt-6 flex gap-3"><button type="button" onClick={() => setShowUnlockConfirm(false)} className="flex-1 rounded-lg border border-white/15 px-4 py-3 text-sm text-white/65 hover:text-white cursor-pointer">Cancel</button><button type="button" onClick={() => { setShowUnlockConfirm(false); placeBuy(); }} className="flex-1 rounded-lg bg-cyan-300 px-4 py-3 text-sm font-bold text-black hover:bg-cyan-200 cursor-pointer">Confirm purchase</button></div></div></div>}
    </div>
  );
}
