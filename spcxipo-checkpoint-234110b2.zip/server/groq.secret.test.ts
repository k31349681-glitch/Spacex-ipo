import { describe, expect, it } from "vitest";

describe("configured Groq secret", () => {
  it("authenticates against the lightweight models endpoint", async () => {
    const key = process.env.GROQ_API_KEY;
    expect(key, "GROQ_API_KEY must be configured").toBeTruthy();

    const response = await fetch("https://api.groq.com/openai/v1/models", {
      headers: { Authorization: `Bearer ${key}` },
    });

    expect(response.ok).toBe(true);
    const payload = (await response.json()) as { data?: unknown[] };
    expect(Array.isArray(payload.data)).toBe(true);
  }, 30_000);
});
