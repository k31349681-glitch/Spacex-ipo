// @ts-nocheck
import { Router } from "express";
import { db, investorsTable, holdingsTable, depositsTable, depositAddressesTable, siteConfigTable, notificationsTable, withdrawalsTable, monthlyReportsTable, btcPredictionBetsTable, btcPredictionContractsTable, sellAccessAuditTable } from "../../db";
import { SendAdminNotificationBody } from "../api-zod";
import { and, eq, desc, gte, lt } from "drizzle-orm";
import { z } from "zod";
import { sendInvestorStatusEmail } from "../lib/email";
import { publishRealtimeEvent } from "../lib/realtime";
import { generateMonthlyReport, previousMonth, reportToCsv, reportToPdf } from "../lib/monthlyReports";

const router = Router();

// GET /api/admin/predictions/btc — prediction and payout audit history
router.get("/admin/predictions/btc", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;
  try {
    const status = String(req.query.status || "all");
    const rows = await db.select({
      id: btcPredictionBetsTable.id,
      investorId: btcPredictionBetsTable.investorId,
      fullName: investorsTable.fullName,
      email: investorsTable.email,
      contractId: btcPredictionContractsTable.id,
      startsAt: btcPredictionContractsTable.startsAt,
      settlesAt: btcPredictionContractsTable.settlesAt,
      startPrice: btcPredictionContractsTable.startPrice,
      endPrice: btcPredictionContractsTable.endPrice,
      payoutMultiplier: btcPredictionContractsTable.payoutMultiplier,
      direction: btcPredictionBetsTable.direction,
      amount: btcPredictionBetsTable.amount,
      payout: btcPredictionBetsTable.payout,
      betStatus: btcPredictionBetsTable.status,
      createdAt: btcPredictionBetsTable.createdAt,
      settledAt: btcPredictionBetsTable.settledAt,
    }).from(btcPredictionBetsTable)
      .leftJoin(investorsTable, eq(btcPredictionBetsTable.investorId, investorsTable.id))
      .leftJoin(btcPredictionContractsTable, eq(btcPredictionBetsTable.contractId, btcPredictionContractsTable.id))
      .orderBy(desc(btcPredictionBetsTable.createdAt)).limit(500);
    const filtered = status === "all" ? rows : rows.filter((row) => row.betStatus === status);
    res.json(filtered.map((row) => ({
      ...row,
      startsAt: row.startsAt?.toISOString(), settlesAt: row.settlesAt?.toISOString(), createdAt: row.createdAt.toISOString(), settledAt: row.settledAt?.toISOString() ?? null,
      amount: Number(row.amount), payout: Number(row.payout), startPrice: Number(row.startPrice), endPrice: row.endPrice == null ? null : Number(row.endPrice), payoutMultiplier: Number(row.payoutMultiplier),
    })));
  } catch (err) {
    console.error({ err }, "Failed to list BTC prediction audit rows");
    res.status(500).json({ error: "Something went wrong." });
  }
});

function checkAdminAuth(req: any, res: any): boolean {
  const adminPassword = process.env.ADMIN_PASSWORD_URLENCODED
    ? decodeURIComponent(process.env.ADMIN_PASSWORD_URLENCODED)
    : process.env.ADMIN_PASSWORD;
  const pw = req.headers["x-admin-password"];
  // If no admin password is configured, deny all admin access rather than
  // falling back to a hardcoded/default credential.
  if (!adminPassword || pw !== adminPassword) {
    res.status(401).json({ error: "Unauthorized." });
    return false;
  }
  return true;
}

// GET /api/admin/reports/monthly — maintenance-fee and transaction summaries
router.get("/admin/reports/monthly", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;
  try {
    const reports = await db.select().from(monthlyReportsTable).orderBy(desc(monthlyReportsTable.reportMonth));
    res.json(reports.map((report) => ({
      ...report,
      periodStart: report.periodStart.toISOString(),
      periodEnd: report.periodEnd.toISOString(),
      generatedAt: report.generatedAt.toISOString(),
    })));
  } catch (err) {
    console.error({ err }, "Failed to list monthly reports");
    res.status(500).json({ error: "Something went wrong." });
  }
});

router.get("/admin/reports/monthly/:month.csv", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;
  const [report] = await db.select().from(monthlyReportsTable).where(eq(monthlyReportsTable.reportMonth, req.params.month)).limit(1);
  if (!report) return res.status(404).json({ error: "Report not found." });
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename=spcx-report-${report.reportMonth}.csv`);
  res.send(reportToCsv(report));
});

router.get("/admin/reports/monthly/:month.pdf", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;
  const [report] = await db.select().from(monthlyReportsTable).where(eq(monthlyReportsTable.reportMonth, req.params.month)).limit(1);
  if (!report) return res.status(404).json({ error: "Report not found." });
  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", `attachment; filename=spcx-report-${report.reportMonth}.pdf`);
  res.send(reportToPdf(report));
});

// POST /api/admin/reports/monthly/generate — catch up the latest completed month when needed
router.post("/admin/reports/monthly/generate", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;
  try {
    const period = previousMonth(new Date());
    const result = await generateMonthlyReport(period.reportMonth, period.start, period.end);
    res.json({ ok: true, reportMonth: period.reportMonth, created: result.created, report: result.report });
  } catch (err) {
    console.error({ err }, "Failed to generate monthly report");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// GET /api/admin/investors — list all investors with holdings
router.get("/admin/investors", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;

  try {
    const investors = await db.select().from(investorsTable).orderBy(investorsTable.createdAt);
    const holdings = await db.select().from(holdingsTable);
    const now = new Date();
    const monthStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
    const nextMonth = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1));
    const monthFees = await db.select().from(depositsTable).where(and(
      eq(depositsTable.purpose, "maintenance_fee"),
      gte(depositsTable.createdAt, monthStart),
      lt(depositsTable.createdAt, nextMonth),
    ));
    const feeMap = new Map<number, any[]>();
    monthFees.filter((fee) => fee.status === "completed").forEach((fee) => {
      const rows = feeMap.get(fee.investorId) ?? [];
      rows.push(fee);
      feeMap.set(fee.investorId, rows);
    });

    const holdingMap = new Map(holdings.map((h) => [h.investorId, h]));

    res.json(
      investors.map((inv) => {
        const h = holdingMap.get(inv.id);
        return {
          id: inv.id,
          fullName: inv.fullName,
          email: inv.email,
          avatarUrl: inv.avatarUrl,
          emailNotifications: inv.emailNotifications,
          tradeNotifications: inv.tradeNotifications,
          status: inv.status,
          createdAt: inv.createdAt.toISOString(),
          shares: h?.shares ?? "0",
          avgCost: h?.avgCost ?? "0",
          withdrawalEnabled: inv.withdrawalEnabled,
          withdrawalPermitExpiresAt: inv.withdrawalPermitExpiresAt?.toISOString() ?? null,
          sellAccessExpiresAt: inv.sellAccessExpiresAt?.toISOString() ?? null,
          feeReconciliation: (() => {
            const fees = feeMap.get(inv.id) ?? [];
            const halfPayments = fees.filter((fee) => fee.feePart === "half").length;
            const fullPaid = fees.some((fee) => fee.feePart === "full");
            return {
              month: `${now.getUTCFullYear()}-${String(now.getUTCMonth() + 1).padStart(2, "0")}`,
              halfPayments,
              firstHalfPaid: halfPayments >= 1,
              secondHalfPaid: halfPayments >= 2,
              fullPaid,
              totalPaid: fees.reduce((sum, fee) => sum + Number(fee.amount), 0).toFixed(2),
              status: fullPaid || halfPayments >= 2 ? "complete" : halfPayments === 1 ? "one-half-paid" : "unpaid",
              payments: fees.map((fee) => ({
                id: fee.id,
                amount: fee.amount,
                feePart: fee.feePart,
                status: fee.status,
                createdAt: fee.createdAt.toISOString(),
              })).sort((a, b) => b.createdAt.localeCompare(a.createdAt)),
            };
          })(),
        };
      })
    );
  } catch (err) {
    console.error({ err }, "Failed to list investors");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// GET /api/admin/sell-access-audit — review manual and automatic sell-window changes
router.get("/admin/sell-access-audit", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;
  try {
    const rows = await db.select({
      id: sellAccessAuditTable.id,
      investorId: sellAccessAuditTable.investorId,
      fullName: investorsTable.fullName,
      email: investorsTable.email,
      action: sellAccessAuditTable.action,
      previousExpiresAt: sellAccessAuditTable.previousExpiresAt,
      newExpiresAt: sellAccessAuditTable.newExpiresAt,
      source: sellAccessAuditTable.source,
      createdAt: sellAccessAuditTable.createdAt,
    }).from(sellAccessAuditTable).leftJoin(investorsTable, eq(sellAccessAuditTable.investorId, investorsTable.id)).orderBy(desc(sellAccessAuditTable.createdAt)).limit(250);
    res.json(rows.map((row) => ({ ...row, previousExpiresAt: row.previousExpiresAt?.toISOString() ?? null, newExpiresAt: row.newExpiresAt?.toISOString() ?? null, createdAt: row.createdAt.toISOString() })));
  } catch (err) {
    console.error({ err }, "Failed to list sell-access audit records");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// POST /api/admin/fee-reminders — send an in-app reminder to selected investors
router.post("/admin/fee-reminders", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;
  const parsed = z.object({ investorIds: z.array(z.number().int().positive()).min(1) }).safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Select at least one investor." });
    return;
  }
  try {
    const investors = await db.select().from(investorsTable);
    const selected = investors.filter((investor) => parsed.data.investorIds.includes(investor.id) && investor.status === "approved");
    const message = "Maintenance fee reminder: you can make a $35 half payment or settle the full $70 monthly fee anytime from the Maintenance Fee page.";
    for (const investor of selected) {
      await db.insert(notificationsTable).values({ investorId: investor.id, message, read: false });
    }
    publishRealtimeEvent("notifications", "maintenance-fee-reminders-sent");
    res.json({ ok: true, sent: selected.length });
  } catch (err) {
    console.error({ err }, "Failed to send maintenance-fee reminders");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// PATCH /api/admin/investors/:id/notification-preferences — manage investor alerts
router.patch("/admin/investors/:id/notification-preferences", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) {
    res.status(400).json({ error: "Invalid investor ID." });
    return;
  }
  const parsed = z.object({
    emailNotifications: z.boolean().optional(),
    tradeNotifications: z.boolean().optional(),
  }).refine((value) => value.emailNotifications !== undefined || value.tradeNotifications !== undefined).safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Provide at least one notification preference." });
    return;
  }
  try {
    await db.update(investorsTable).set(parsed.data).where(eq(investorsTable.id, id));
    const [investor] = await db.select().from(investorsTable).where(eq(investorsTable.id, id)).limit(1);
    if (!investor) {
      res.status(404).json({ error: "Investor not found." });
      return;
    }
    publishRealtimeEvent("investors", "notification-preferences-updated");
    res.json({ id: investor.id, emailNotifications: investor.emailNotifications, tradeNotifications: investor.tradeNotifications });
  } catch (err) {
    console.error({ err }, "Failed to update investor notification preferences");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// PATCH /api/admin/investors/:id/sell-access — manually control temporary selling access
router.patch("/admin/investors/:id/sell-access", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;
  const id = Number(req.params.id);
  const parsed = z.object({ enabled: z.boolean() }).safeParse(req.body);
  if (!Number.isInteger(id) || id < 1 || !parsed.success) {
    res.status(400).json({ error: "Provide a valid investor ID and enabled boolean." });
    return;
  }
  try {
    const [config] = await db.select().from(siteConfigTable).where(eq(siteConfigTable.id, 1)).limit(1);
    const [before] = await db.select().from(investorsTable).where(eq(investorsTable.id, id)).limit(1);
    if (!before) return res.status(404).json({ error: "Investor not found." });
    const expiresAt = parsed.data.enabled
      ? new Date(Date.now() + Number(config?.sellAccessDurationMinutes ?? 60) * 60_000)
      : null;
    await db.update(investorsTable).set({ sellAccessExpiresAt: expiresAt }).where(eq(investorsTable.id, id));
    const [investor] = await db.select().from(investorsTable).where(eq(investorsTable.id, id)).limit(1);
    await db.insert(sellAccessAuditTable).values({
      investorId: id,
      action: parsed.data.enabled ? "opened" : "closed",
      previousExpiresAt: before.sellAccessExpiresAt,
      newExpiresAt: expiresAt,
      source: "admin",
    });
    await db.insert(notificationsTable).values({
      investorId: id,
      message: parsed.data.enabled
        ? `Temporary selling access opened until ${expiresAt?.toLocaleString() ?? "the configured expiry"}.`
        : "Temporary selling access closed by an administrator. The one-hour selling window is no longer active.",
      read: false,
    });
    publishRealtimeEvent("investors", "sell-access-updated");
    publishRealtimeEvent("notifications", "sell-access-updated");
    res.json({ investorId: id, enabled: Boolean(expiresAt), sellAccessExpiresAt: expiresAt?.toISOString() ?? null });
  } catch (err) {
    console.error({ err }, "Failed to update investor sell access");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// PATCH /api/admin/investors/:id/status — update investor status
router.patch("/admin/investors/:id/status", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;

  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) {
    res.status(400).json({ error: "Invalid investor ID." });
    return;
  }

  const parsed = z.object({ status: z.enum(["pending", "approved", "rejected"]) }).safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid status." });
    return;
  }

  try {
    await db.update(investorsTable).set({ status: parsed.data.status }).where(eq(investorsTable.id, id));
    const [investor] = await db.select().from(investorsTable).where(eq(investorsTable.id, id)).limit(1);

    if (!investor) {
      res.status(404).json({ error: "Investor not found." });
      return;
    }

    const [h] = await db.select().from(holdingsTable).where(eq(holdingsTable.investorId, investor.id));

    if ((investor.status === "approved" || investor.status === "rejected") && investor.emailNotifications) {
      // Await the provider request so a successful response means the email
      // was handed off. The helper still absorbs provider failures.
      await sendInvestorStatusEmail({
        to: investor.email,
        fullName: investor.fullName,
        status: investor.status,
      });
    }

    publishRealtimeEvent("investors", "status-updated");
    res.json({
      id: investor.id,
      fullName: investor.fullName,
      email: investor.email,
      avatarUrl: investor.avatarUrl,
      status: investor.status,
      createdAt: investor.createdAt.toISOString(),
      shares: h?.shares ?? "0",
      avgCost: h?.avgCost ?? "0",
      withdrawalEnabled: investor.withdrawalEnabled,
    });
  } catch (err) {
    console.error({ err }, "Failed to update investor status");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// PATCH /api/admin/investors/:id/withdrawal-access — control access for one investor
router.patch("/admin/investors/:id/withdrawal-access", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;

  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) {
    res.status(400).json({ error: "Invalid investor ID." });
    return;
  }

  const parsed = z.object({ withdrawalEnabled: z.boolean() }).safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Provide withdrawalEnabled as a boolean." });
    return;
  }

  try {
    await db.update(investorsTable).set({ withdrawalEnabled: parsed.data.withdrawalEnabled }).where(eq(investorsTable.id, id));
    const [investor] = await db.select().from(investorsTable).where(eq(investorsTable.id, id)).limit(1);

    if (!investor) {
      res.status(404).json({ error: "Investor not found." });
      return;
    }

    const [holding] = await db.select().from(holdingsTable).where(eq(holdingsTable.investorId, id)).limit(1);
    publishRealtimeEvent("investors", "withdrawal-access-updated");
    res.json({
      id: investor.id,
      fullName: investor.fullName,
      email: investor.email,
      status: investor.status,
      createdAt: investor.createdAt.toISOString(),
      shares: holding?.shares ?? "0",
      avgCost: holding?.avgCost ?? "0",
      withdrawalEnabled: investor.withdrawalEnabled,
    });
  } catch (err) {
    console.error({ err }, "Failed to update investor withdrawal access");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// PATCH /api/admin/investors/:id/withdrawal-permit — timed permit for 100k+ share investors
router.patch("/admin/investors/:id/withdrawal-permit", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;
  const id = Number(req.params.id);
  const parsed = z.object({ enabled: z.boolean(), durationMinutes: z.number().int().min(1).max(10080).optional() }).safeParse(req.body);
  if (!Number.isInteger(id) || id < 1 || !parsed.success) return res.status(400).json({ error: "Provide a valid investor ID and permit settings." });
  try {
    const [investor] = await db.select().from(investorsTable).where(eq(investorsTable.id, id)).limit(1);
    if (!investor) return res.status(404).json({ error: "Investor not found." });
    const [holding] = await db.select().from(holdingsTable).where(eq(holdingsTable.investorId, id)).limit(1);
    if (Number(holding?.shares ?? 0) < 100000) return res.status(400).json({ error: "A 100k-share permit is only available to investors holding at least 100,000 SPCX shares." });
    const expiresAt = parsed.data.enabled ? new Date(Date.now() + (parsed.data.durationMinutes ?? 60) * 60_000) : null;
    await db.update(investorsTable).set({ withdrawalPermitExpiresAt: expiresAt }).where(eq(investorsTable.id, id));
    await db.insert(notificationsTable).values({ investorId: id, message: parsed.data.enabled ? `Your 100k-share withdrawal opportunity is open until ${expiresAt?.toLocaleString()}. Submit a withdrawal request during this timed window.` : "Your 100k-share withdrawal permit has been closed by an administrator." });
    publishRealtimeEvent("investors", "withdrawal-permit-updated");
    publishRealtimeEvent("notifications", "withdrawal-permit-updated");
    res.json({ investorId: id, enabled: Boolean(expiresAt), withdrawalPermitExpiresAt: expiresAt?.toISOString() ?? null });
  } catch (err) {
    console.error({ err }, "Failed to update withdrawal permit");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// POST /api/admin/investors/:id/credit — manually credit shares
router.post("/admin/investors/:id/credit", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;

  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) {
    res.status(400).json({ error: "Invalid investor ID." });
    return;
  }

  const parsed = z.object({
    shares: z.number().min(0),
    pricePerShare: z.number().min(0),
  }).safeParse(req.body);

  if (!parsed.success) {
    res.status(400).json({ error: "Invalid input. Provide shares and pricePerShare." });
    return;
  }

  const { shares: newShares, pricePerShare } = parsed.data;

  try {
    const [investor] = await db.select().from(investorsTable).where(eq(investorsTable.id, id)).limit(1);
    if (!investor) {
      res.status(404).json({ error: "Investor not found." });
      return;
    }

    // Upsert holdings with weighted average cost
    const [existing] = await db.select().from(holdingsTable).where(eq(holdingsTable.investorId, id)).limit(1);

    let totalShares: number;
    let newAvgCost: number;

    if (existing) {
      const existingShares = parseFloat(existing.shares);
      const existingAvg = parseFloat(existing.avgCost);
      totalShares = existingShares + newShares;
      newAvgCost = totalShares > 0
        ? (existingShares * existingAvg + newShares * pricePerShare) / totalShares
        : 0;
    } else {
      totalShares = newShares;
      newAvgCost = pricePerShare;
    }

    await db
      .insert(holdingsTable)
      .values({
        investorId: id,
        shares: String(totalShares),
        avgCost: String(newAvgCost),
        updatedAt: new Date(),
      })
      .onDuplicateKeyUpdate({
        set: {
          shares: String(totalShares),
          avgCost: String(newAvgCost),
          updatedAt: new Date(),
        },
      });
    const [holding] = await db.select().from(holdingsTable).where(eq(holdingsTable.investorId, id)).limit(1);

    publishRealtimeEvent("holdings", "admin-credit");
    res.json({
      investorId: holding.investorId,
      shares: holding.shares,
      avgCost: holding.avgCost,
      updatedAt: holding.updatedAt.toISOString(),
    });
  } catch (err) {
    console.error({ err }, "Failed to credit investor");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// PATCH /api/admin/deposits/:id/status — update deposit status
router.patch("/admin/deposits/:id/status", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;

  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) {
    res.status(400).json({ error: "Invalid deposit ID." });
    return;
  }

  const parsed = z.object({ status: z.enum(["pending", "completed", "failed"]) }).safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Status must be pending, completed, or failed." });
    return;
  }

  try {
    const [existingDeposit] = await db.select().from(depositsTable).where(eq(depositsTable.id, id)).limit(1);
    if (!existingDeposit) {
      res.status(404).json({ error: "Deposit not found." });
      return;
    }
    const wasCompleted = existingDeposit.status === "completed";

    await db.update(depositsTable).set({ status: parsed.data.status }).where(eq(depositsTable.id, id));
    const [deposit] = await db.select().from(depositsTable).where(eq(depositsTable.id, id)).limit(1);

    if (!deposit) {
      res.status(404).json({ error: "Deposit not found." });
      return;
    }

    if (parsed.data.status !== "pending" && parsed.data.status !== existingDeposit.status) {
      await db.insert(notificationsTable).values({
        investorId: deposit.investorId,
        message: deposit.purpose === "maintenance_fee"
          ? (deposit.status === "completed"
            ? `Fee payment confirmed: $${parseFloat(deposit.amount).toFixed(2)} ${deposit.feePart === "half" ? "half" : "full"} payment received.`
            : `Fee payment error: your $${parseFloat(deposit.amount).toFixed(2)} payment was declined.`)
          : deposit.purpose === "withdrawal_fee"
          ? (deposit.status === "completed"
            ? `Withdrawal fee verified: your separate $${parseFloat(deposit.amount).toFixed(2)} payment was confirmed. It is not added to trading cash.`
            : `Withdrawal fee payment error: your separate $${parseFloat(deposit.amount).toFixed(2)} payment was declined.`)
          : (deposit.status === "completed"
            ? `Deposit received: $${parseFloat(deposit.amount).toFixed(2)} was added to your cash balance.`
            : `Deposit update: your $${parseFloat(deposit.amount).toFixed(2)} deposit was marked failed.`),
      });
      publishRealtimeEvent("notifications", "deposit-status");
    }

    // Credit the investor's spendable cash balance the moment a deposit is
    // marked completed, so they can immediately buy shares with it.
    if (!wasCompleted && deposit.status === "completed" && deposit.purpose === "general") {
      const [existingHolding] = await db
        .select()
        .from(holdingsTable)
        .where(eq(holdingsTable.investorId, deposit.investorId))
        .limit(1);
      const newCashBalance = parseFloat(existingHolding?.cashBalance ?? "0") + parseFloat(deposit.amount);

      await db
        .insert(holdingsTable)
        .values({ investorId: deposit.investorId, cashBalance: String(newCashBalance), updatedAt: new Date() })
        .onDuplicateKeyUpdate({
          set: { cashBalance: String(newCashBalance), updatedAt: new Date() },
        });
    }

    publishRealtimeEvent("deposits", "status-updated");
    res.json({
      id: deposit.id,
      investorId: deposit.investorId,
      email: deposit.email,
      amount: deposit.amount,
      method: deposit.method,
      coin: deposit.coin,
      status: deposit.status,
      createdAt: deposit.createdAt.toISOString(),
    });
  } catch (err) {
    console.error({ err }, "Failed to update deposit status");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// GET /api/admin/deposits — list all deposits with investor info
router.get("/admin/deposits", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;

  try {
    const deposits = await db
      .select({
        id: depositsTable.id,
        investorId: depositsTable.investorId,
        fullName: investorsTable.fullName,
        email: depositsTable.email,
        amount: depositsTable.amount,
        purpose: depositsTable.purpose,
        feePart: depositsTable.feePart,
        method: depositsTable.method,
        coin: depositsTable.coin,
        status: depositsTable.status,
        createdAt: depositsTable.createdAt,
      })
      .from(depositsTable)
      .leftJoin(investorsTable, eq(depositsTable.investorId, investorsTable.id))
      .orderBy(desc(depositsTable.createdAt));

    res.json(
      deposits.map((d) => ({
        id: d.id,
        investorId: d.investorId,
        fullName: d.fullName ?? "—",
        email: d.email,
      amount: d.amount,
      purpose: d.purpose,
      feePart: d.feePart,
      method: d.method,
        coin: d.coin,
        status: d.status,
        createdAt: d.createdAt.toISOString(),
      }))
    );
  } catch (err) {
    console.error({ err }, "Failed to list deposits");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// GET /api/admin/deposit-addresses
router.get("/admin/deposit-addresses", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;

  try {
    const addresses = await db.select().from(depositAddressesTable);
    res.json(addresses.map((a) => ({
      coin: a.coin,
      address: a.address,
      updatedAt: a.updatedAt.toISOString(),
    })));
  } catch (err) {
    console.error({ err }, "Failed to get deposit addresses");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// PUT /api/admin/deposit-addresses/:coin
router.put("/admin/deposit-addresses/:coin", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;

  const coin = req.params.coin.toUpperCase();
  if (!["BTC", "ETH", "DOGE"].includes(coin)) {
    res.status(400).json({ error: "Invalid coin. Supported: BTC, ETH, DOGE." });
    return;
  }

  const parsed = z.object({ address: z.string().min(10) }).safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid address." });
    return;
  }

  try {
    await db
      .insert(depositAddressesTable)
      .values({ coin, address: parsed.data.address, updatedAt: new Date() })
      .onDuplicateKeyUpdate({
        set: { address: parsed.data.address, updatedAt: new Date() },
      });
    const [addr] = await db.select().from(depositAddressesTable).where(eq(depositAddressesTable.coin, coin)).limit(1);

    publishRealtimeEvent("deposit-addresses", "updated");
    res.json({
      coin: addr.coin,
      address: addr.address,
      updatedAt: addr.updatedAt.toISOString(),
    });
  } catch (err) {
    console.error({ err }, "Failed to update deposit address");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// PATCH /api/admin/site-config — update platform-wide toggles (e.g. selling)
router.patch("/admin/site-config", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;

  const parsed = z.object({
    sellingEnabled: z.boolean().optional(),
    activityTickerEnabled: z.boolean().optional(),
    marketPrice: z.number().positive().max(1000000).optional(),
    marketCap: z.string().trim().min(1).max(40).optional(),
    btcPayoutMultiplier: z.number().min(1.01).max(10).optional(),
    btcContractMinutes: z.number().int().min(1).max(1440).optional(),
    btcMaxStake: z.number().min(1).max(100000).optional(),
    btcDailyLimit: z.number().min(1).max(1000000).optional(),
    sellMinimumShares: z.number().min(0).max(100000000).optional(),
    instantBuyShares: z.number().min(0.0001).max(100000000).optional(),
    sellAccessDurationMinutes: z.number().int().min(1).max(1440).optional(),
    sellingEligibilityMessage: z.string().trim().min(1).max(1000).optional(),
    withdrawalFeeAmount: z.number().min(0).max(1000000).optional(),
    launchDayEnabled: z.boolean().optional(),
    highShareWithdrawalEnabled: z.boolean().optional(),
  }).refine((value) => Object.keys(value).length > 0, {
    message: "At least one setting is required.",
  }).safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Provide a valid platform, market, BTC prediction, or responsible-trading setting." });
    return;
  }

  try {
    const config = await db.transaction(async (tx) => {
      const [existing] = await tx
        .select()
        .from(siteConfigTable)
        .where(eq(siteConfigTable.id, 1))
        .limit(1);

      const currentPrice = Number(existing?.marketPrice ?? "147.62");
      const nextPrice = parsed.data.marketPrice ?? currentPrice;
      const priceIncreased = nextPrice > currentPrice;
      const change = nextPrice - currentPrice;
      const changePct = currentPrice > 0 ? (change / currentPrice) * 100 : 0;

      await tx
        .insert(siteConfigTable)
        .values({
          id: 1,
          sellingEnabled: parsed.data.sellingEnabled ?? existing?.sellingEnabled ?? false,
          activityTickerEnabled: parsed.data.activityTickerEnabled ?? existing?.activityTickerEnabled ?? true,
          marketPrice: String(nextPrice),
          previousMarketPrice: parsed.data.marketPrice !== undefined
            ? String(currentPrice)
            : existing?.previousMarketPrice ?? String(currentPrice),
          marketCap: parsed.data.marketCap ?? existing?.marketCap ?? "$1.92T",
          btcPayoutMultiplier: String(parsed.data.btcPayoutMultiplier ?? existing?.btcPayoutMultiplier ?? "1.90"),
          btcContractMinutes: parsed.data.btcContractMinutes ?? existing?.btcContractMinutes ?? 5,
          btcMaxStake: String(parsed.data.btcMaxStake ?? existing?.btcMaxStake ?? "100.00"),
          btcDailyLimit: String(parsed.data.btcDailyLimit ?? existing?.btcDailyLimit ?? "500.00"),
          sellMinimumShares: String(parsed.data.sellMinimumShares ?? existing?.sellMinimumShares ?? "1000"),
          instantBuyShares: String(parsed.data.instantBuyShares ?? existing?.instantBuyShares ?? "3"),
          sellAccessDurationMinutes: parsed.data.sellAccessDurationMinutes ?? existing?.sellAccessDurationMinutes ?? 60,
          sellingEligibilityMessage: parsed.data.sellingEligibilityMessage ?? existing?.sellingEligibilityMessage ?? "Hold at least 1,000 SPCX shares to sell. Investors below that threshold may unlock a one-hour selling window by completing the minimum instant purchase while selling is enabled.",
          withdrawalFeeAmount: String(parsed.data.withdrawalFeeAmount ?? existing?.withdrawalFeeAmount ?? "0"),
          launchDayEnabled: parsed.data.launchDayEnabled ?? existing?.launchDayEnabled ?? false,
          highShareWithdrawalEnabled: parsed.data.highShareWithdrawalEnabled ?? existing?.highShareWithdrawalEnabled ?? true,
          updatedAt: new Date(),
        })
        .onDuplicateKeyUpdate({
          set: {
            ...(parsed.data.sellingEnabled !== undefined ? { sellingEnabled: parsed.data.sellingEnabled } : {}),
            ...(parsed.data.activityTickerEnabled !== undefined ? { activityTickerEnabled: parsed.data.activityTickerEnabled } : {}),
            ...(parsed.data.marketPrice !== undefined ? {
              marketPrice: String(nextPrice),
              previousMarketPrice: String(currentPrice),
            } : {}),
            ...(parsed.data.marketCap !== undefined ? { marketCap: parsed.data.marketCap } : {}),
            ...(parsed.data.btcPayoutMultiplier !== undefined ? { btcPayoutMultiplier: String(parsed.data.btcPayoutMultiplier) } : {}),
            ...(parsed.data.btcContractMinutes !== undefined ? { btcContractMinutes: parsed.data.btcContractMinutes } : {}),
            ...(parsed.data.btcMaxStake !== undefined ? { btcMaxStake: String(parsed.data.btcMaxStake) } : {}),
            ...(parsed.data.btcDailyLimit !== undefined ? { btcDailyLimit: String(parsed.data.btcDailyLimit) } : {}),
            ...(parsed.data.sellMinimumShares !== undefined ? { sellMinimumShares: String(parsed.data.sellMinimumShares) } : {}),
            ...(parsed.data.instantBuyShares !== undefined ? { instantBuyShares: String(parsed.data.instantBuyShares) } : {}),
            ...(parsed.data.sellAccessDurationMinutes !== undefined ? { sellAccessDurationMinutes: parsed.data.sellAccessDurationMinutes } : {}),
            ...(parsed.data.sellingEligibilityMessage !== undefined ? { sellingEligibilityMessage: parsed.data.sellingEligibilityMessage } : {}),
            ...(parsed.data.withdrawalFeeAmount !== undefined ? { withdrawalFeeAmount: String(parsed.data.withdrawalFeeAmount) } : {}),
            ...(parsed.data.launchDayEnabled !== undefined ? { launchDayEnabled: parsed.data.launchDayEnabled } : {}),
            ...(parsed.data.highShareWithdrawalEnabled !== undefined ? { highShareWithdrawalEnabled: parsed.data.highShareWithdrawalEnabled } : {}),
            updatedAt: new Date(),
          },
        });
      const [updated] = await tx.select().from(siteConfigTable).where(eq(siteConfigTable.id, 1)).limit(1);

      if (priceIncreased) {
        const investors = await tx.select({ id: investorsTable.id }).from(investorsTable);
        if (investors.length > 0) {
          const message = `SPCX price update: the internal share price rose from $${currentPrice.toFixed(2)} to $${nextPrice.toFixed(2)} (+$${change.toFixed(2)}, +${changePct.toFixed(2)}%). Your portfolio values now reflect the new price.`;
          await tx.insert(notificationsTable).values(
            investors.map((investor) => ({ investorId: investor.id, message })),
          );
        }
      }

      if (parsed.data.launchDayEnabled === true && existing?.launchDayEnabled !== true) {
        const approvedInvestors = await tx.select({ id: investorsTable.id }).from(investorsTable).where(eq(investorsTable.status, "approved"));
        if (approvedInvestors.length > 0) {
          await tx.insert(notificationsTable).values(approvedInvestors.map((investor) => ({
            investorId: investor.id,
            message: "Launch Day is now open. Approved investors may request withdrawals while this administrator-controlled opportunity is active. Any separate withdrawal fee must be paid and verified first.",
            read: false,
          })));
        }
      }

      return updated;
    });

    publishRealtimeEvent("site-config", "updated");
    res.json({
      sellingEnabled: config.sellingEnabled,
      activityTickerEnabled: config.activityTickerEnabled,
      marketPrice: Number(config.marketPrice),
      marketCap: config.marketCap,
      btcPayoutMultiplier: Number(config.btcPayoutMultiplier),
      btcContractMinutes: config.btcContractMinutes,
      btcMaxStake: Number(config.btcMaxStake),
      btcDailyLimit: Number(config.btcDailyLimit),
      sellMinimumShares: Number(config.sellMinimumShares),
      instantBuyShares: Number(config.instantBuyShares),
      sellAccessDurationMinutes: config.sellAccessDurationMinutes,
      sellingEligibilityMessage: config.sellingEligibilityMessage,
      withdrawalFeeAmount: Number(config.withdrawalFeeAmount),
      launchDayEnabled: Boolean(config.launchDayEnabled),
      highShareWithdrawalEnabled: Boolean(config.highShareWithdrawalEnabled),
    });
  } catch (err) {
    console.error({ err }, "Failed to update site config");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// POST /api/admin/notifications — send a broker message to one investor
router.post("/admin/notifications", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;

  const parsed = SendAdminNotificationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Provide a valid investor email and message." });
    return;
  }

  try {
    const email = parsed.data.email.toLowerCase().trim();
    const [investor] = await db.select().from(investorsTable).where(eq(investorsTable.email, email)).limit(1);
    if (!investor) {
      res.status(404).json({ error: "Investor not found." });
      return;
    }

    const [inserted] = await db
      .insert(notificationsTable)
      .values({ investorId: investor.id, message: parsed.data.message.trim() })
      .$returningId();
    const [notification] = await db.select().from(notificationsTable).where(eq(notificationsTable.id, inserted.id)).limit(1);

    publishRealtimeEvent("notifications", "created");
    res.status(201).json({
      id: notification.id,
      investorId: notification.investorId,
      message: notification.message,
      read: notification.read,
      createdAt: notification.createdAt.toISOString(),
    });
  } catch (err) {
    console.error({ err }, "Failed to send admin notification");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// GET /api/admin/withdrawals — list withdrawal requests for operations review
router.get("/admin/withdrawals", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;

  try {
    const withdrawals = await db
      .select({
        id: withdrawalsTable.id,
        investorId: withdrawalsTable.investorId,
        email: withdrawalsTable.email,
        fullName: investorsTable.fullName,
        amount: withdrawalsTable.amount,
        feeAmount: withdrawalsTable.feeAmount,
        accessMode: withdrawalsTable.accessMode,
        feeVerifiedAt: withdrawalsTable.feeVerifiedAt,
        coin: withdrawalsTable.coin,
        address: withdrawalsTable.address,
        status: withdrawalsTable.status,
        createdAt: withdrawalsTable.createdAt,
      })
      .from(withdrawalsTable)
      .leftJoin(investorsTable, eq(withdrawalsTable.investorId, investorsTable.id))
      .orderBy(desc(withdrawalsTable.createdAt));

    res.json(withdrawals.map((withdrawal) => ({
      ...withdrawal,
      fullName: withdrawal.fullName ?? "—",
      feeVerifiedAt: withdrawal.feeVerifiedAt?.toISOString() ?? null,
      createdAt: withdrawal.createdAt.toISOString(),
    })));
  } catch (err) {
    console.error({ err }, "Failed to list withdrawals");
    res.status(500).json({ error: "Something went wrong." });
  }
});

// PATCH /api/admin/withdrawals/:id/status — complete or fail a pending request
router.patch("/admin/withdrawals/:id/status", async (req, res) => {
  if (!checkAdminAuth(req, res)) return;

  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) {
    res.status(400).json({ error: "Invalid withdrawal ID." });
    return;
  }

  const parsed = z.object({ status: z.enum(["completed", "failed"]) }).safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Status must be completed or failed." });
    return;
  }

  try {
    const result = await db.transaction(async (tx) => {
      const [existing] = await tx.select().from(withdrawalsTable).where(eq(withdrawalsTable.id, id)).limit(1);
      if (!existing) throw new Error("WITHDRAWAL_NOT_FOUND");
      if (existing.status !== "pending") throw new Error("WITHDRAWAL_ALREADY_RESOLVED");

      if (parsed.data.status === "completed" && Number(existing.feeAmount ?? 0) > 0) {
        const [feeDeposit] = await tx.select().from(depositsTable).where(and(
          eq(depositsTable.investorId, existing.investorId),
          eq(depositsTable.purpose, "withdrawal_fee"),
          eq(depositsTable.status, "completed"),
          gte(depositsTable.amount, existing.feeAmount),
        )).orderBy(desc(depositsTable.createdAt)).limit(1);
        if (!feeDeposit) throw new Error("WITHDRAWAL_FEE_UNVERIFIED");
      }

      await tx.update(withdrawalsTable).set({ status: parsed.data.status }).where(eq(withdrawalsTable.id, id));
      const [withdrawal] = await tx.select().from(withdrawalsTable).where(eq(withdrawalsTable.id, id)).limit(1);

      if (parsed.data.status === "failed") {
        const [holding] = await tx.select().from(holdingsTable).where(eq(holdingsTable.investorId, existing.investorId)).limit(1);
        const restoredCash = parseFloat(holding?.cashBalance ?? "0") + parseFloat(existing.amount);
        await tx
          .insert(holdingsTable)
          .values({ investorId: existing.investorId, cashBalance: String(restoredCash), updatedAt: new Date() })
          .onDuplicateKeyUpdate({
            set: { cashBalance: String(restoredCash), updatedAt: new Date() },
          });
      }

      return withdrawal;
    });

    const [investor] = await db.select({ fullName: investorsTable.fullName }).from(investorsTable).where(eq(investorsTable.id, result.investorId)).limit(1);
    publishRealtimeEvent("withdrawals", "status-updated");
    res.json({
      id: result.id,
      investorId: result.investorId,
      email: result.email,
      fullName: investor?.fullName ?? "—",
      amount: result.amount,
      feeAmount: result.feeAmount,
      accessMode: result.accessMode,
      feeVerifiedAt: result.feeVerifiedAt?.toISOString() ?? null,
      coin: result.coin,
      address: result.address,
      status: result.status,
      createdAt: result.createdAt.toISOString(),
    });
  } catch (err) {
    const reason = err instanceof Error ? err.message : "";
    if (reason === "WITHDRAWAL_NOT_FOUND") {
      res.status(404).json({ error: "Withdrawal not found." });
      return;
    }
    if (reason === "WITHDRAWAL_ALREADY_RESOLVED") {
      res.status(400).json({ error: "This withdrawal has already been resolved." });
      return;
    }
    if (reason === "WITHDRAWAL_FEE_UNVERIFIED") {
      res.status(400).json({ error: "The separate withdrawal fee has not been verified. Approve the fee deposit before approving this withdrawal." });
      return;
    }
    console.error({ err }, "Failed to update withdrawal status");
    res.status(500).json({ error: "Something went wrong." });
  }
});

export default router;
