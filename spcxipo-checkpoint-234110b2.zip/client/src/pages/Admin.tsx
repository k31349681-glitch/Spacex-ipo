import React, { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { Lock, Check, X, DollarSign, Wallet, TrendingUp, ArrowDownToLine, Copy, Eye, EyeOff } from 'lucide-react';
import { motion } from 'framer-motion';

type Investor = { id: number; fullName: string; email: string; avatarUrl?: string | null; emailNotifications: boolean; tradeNotifications: boolean; status: 'pending' | 'approved' | 'rejected'; createdAt: string; shares: string; avgCost: string; withdrawalEnabled: boolean; withdrawalPermitExpiresAt?: string | null; sellAccessExpiresAt?: string | null; feeReconciliation?: { month: string; halfPayments: number; firstHalfPaid: boolean; secondHalfPaid: boolean; fullPaid: boolean; totalPaid: string; status: 'complete' | 'one-half-paid' | 'unpaid'; payments: Array<{ id: number; amount: string; feePart: string; status: string; createdAt: string }> } };
type Deposit = { id: number; investorId: number; fullName: string; email: string; amount: string; purpose: string; feePart: string; method: 'card' | 'crypto'; coin: string | null; status: 'pending' | 'completed' | 'failed'; createdAt: string };
type DepositAddress = { coin: string; address: string; updatedAt: string };
type Withdrawal = { id: number; investorId: number; fullName: string; email: string; amount: string; feeAmount: string; accessMode: string; feeVerifiedAt: string | null; coin: string; address: string; status: 'pending' | 'completed' | 'failed'; createdAt: string };
type MonthlyReport = { id: number; reportMonth: string; periodStart: string; periodEnd: string; totalMaintenanceFees: string; completedMaintenanceFees: string; pendingMaintenanceFees: string; failedMaintenanceFees: string; totalDeposits: string; totalWithdrawals: string; transactionCount: number; details?: Record<string, number>; generatedAt: string };
type PredictionAudit = { id: number; fullName?: string | null; email?: string | null; contractId: number; startsAt: string; settlesAt: string; startPrice: number; endPrice: number | null; payoutMultiplier: number; direction: 'up' | 'down'; amount: number; payout: number; betStatus: 'pending' | 'won' | 'lost' | 'refunded'; createdAt: string; settledAt: string | null };
type SellAccessAudit = { id: number; investorId: number; fullName?: string | null; email?: string | null; action: 'opened' | 'closed' | 'automatic_unlock'; previousExpiresAt: string | null; newExpiresAt: string | null; source: string; createdAt: string };

const TABS = ['Investors', 'Fee Reconciliation', 'Deposits', 'Reports', 'Credit', 'Withdrawals', 'Notify User', 'Deposit Addresses', 'Trading', 'BTC Audit', 'Sell Access Audit'] as const;
type Tab = typeof TABS[number];
type FeeFilter = 'all' | 'unpaid' | 'partial' | 'complete';

async function adminFetch(path: string, password: string, options: RequestInit = {}) {
  const res = await fetch(`/api${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'x-admin-password': password,
      ...(options.headers || {}),
    },
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed (${res.status})`);
  }
  return res.json();
}

export default function Admin() {
  const [password, setPassword] = useState('');
  const [authed, setAuthed] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [showAdminPassword, setShowAdminPassword] = useState(false);
  const [authError, setAuthError] = useState('');
  const [tab, setTab] = useState<Tab>('Investors');
  const [feeFilter, setFeeFilter] = useState<FeeFilter>('all');
  const [sendingFeeReminders, setSendingFeeReminders] = useState(false);

  const [investors, setInvestors] = useState<Investor[]>([]);
  const [deposits, setDeposits] = useState<Deposit[]>([]);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [reports, setReports] = useState<MonthlyReport[]>([]);
  const [addresses, setAddresses] = useState<DepositAddress[]>([]);
  const [loading, setLoading] = useState(false);

  const [creditInvestorId, setCreditInvestorId] = useState('');
  const [creditShares, setCreditShares] = useState('');
  const [creditPrice, setCreditPrice] = useState('');
  const [addressEdits, setAddressEdits] = useState<Record<string, string>>({});
  const [sellingEnabled, setSellingEnabled] = useState(false);
  const [activityTickerEnabled, setActivityTickerEnabled] = useState(true);
  const [marketPrice, setMarketPrice] = useState('');
  const [marketCap, setMarketCap] = useState('');
  const [savingConfig, setSavingConfig] = useState(false);
  const [savingMarketData, setSavingMarketData] = useState(false);
  const [notificationEmail, setNotificationEmail] = useState('');
  const [notificationMessage, setNotificationMessage] = useState('');
  const [sendingNotification, setSendingNotification] = useState(false);
  const [btcPayoutMultiplier, setBtcPayoutMultiplier] = useState('1.90');
  const [btcContractMinutes, setBtcContractMinutes] = useState('5');
  const [btcMaxStake, setBtcMaxStake] = useState('100');
  const [btcDailyLimit, setBtcDailyLimit] = useState('500');
  const [sellMinimumShares, setSellMinimumShares] = useState('1000');
  const [instantBuyShares, setInstantBuyShares] = useState('3');
  const [sellAccessDurationMinutes, setSellAccessDurationMinutes] = useState('60');
  const [sellingEligibilityMessage, setSellingEligibilityMessage] = useState('');
  const [withdrawalFeeAmount, setWithdrawalFeeAmount] = useState('0');
  const [launchDayEnabled, setLaunchDayEnabled] = useState(false);
  const [highShareWithdrawalEnabled, setHighShareWithdrawalEnabled] = useState(true);
  const [permitDurationMinutes, setPermitDurationMinutes] = useState('60');
  const [predictionAudit, setPredictionAudit] = useState<PredictionAudit[]>([]);
  const [sellAccessAudit, setSellAccessAudit] = useState<SellAccessAudit[]>([]);

  const loadInvestors = async (pw: string) => {
    const data = await adminFetch('/admin/investors', pw);
    setInvestors(data);
  };
  const loadDeposits = async (pw: string) => {
    const data = await adminFetch('/admin/deposits', pw);
    setDeposits(data);
  };
  const loadWithdrawals = async (pw: string) => {
    const data = await adminFetch('/admin/withdrawals', pw);
    setWithdrawals(data);
  };
  const loadReports = async (pw: string) => {
    const data = await adminFetch('/admin/reports/monthly', pw);
    setReports(data);
  };
  const loadAddresses = async (pw: string) => {
    const data = await adminFetch('/admin/deposit-addresses', pw);
    setAddresses(data);
    const edits: Record<string, string> = {};
    data.forEach((a: DepositAddress) => { edits[a.coin] = a.address; });
    setAddressEdits(edits);
  };
  const loadSiteConfig = async (_pw?: string) => {
    const res = await fetch('/api/site-config');
    if (!res.ok) throw new Error('Failed to load site config.');
    const data = await res.json();
    setSellingEnabled(data.sellingEnabled);
    setActivityTickerEnabled(data.activityTickerEnabled ?? true);
    setMarketPrice(String(data.marketPrice ?? '147.62'));
    setMarketCap(data.marketCap ?? '$1.92T');
    setBtcPayoutMultiplier(String(data.btcPayoutMultiplier ?? '1.90'));
    setBtcContractMinutes(String(data.btcContractMinutes ?? '5'));
    setBtcMaxStake(String(data.btcMaxStake ?? '100'));
    setBtcDailyLimit(String(data.btcDailyLimit ?? '500'));
    setSellMinimumShares(String(data.sellMinimumShares ?? '1000'));
    setInstantBuyShares(String(data.instantBuyShares ?? '3'));
    setSellAccessDurationMinutes(String(data.sellAccessDurationMinutes ?? '60'));
    setSellingEligibilityMessage(data.sellingEligibilityMessage ?? '');
    setWithdrawalFeeAmount(String(data.withdrawalFeeAmount ?? '0'));
    setLaunchDayEnabled(Boolean(data.launchDayEnabled));
    setHighShareWithdrawalEnabled(data.highShareWithdrawalEnabled !== false);
  };
  const loadPredictionAudit = async (pw: string) => setPredictionAudit(await adminFetch('/admin/predictions/btc', pw));
  const loadSellAccessAudit = async (pw: string) => setSellAccessAudit(await adminFetch('/admin/sell-access-audit', pw));

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setLoading(true);
    try {
      await adminFetch('/admin/investors', passwordInput);
      setPassword(passwordInput);
      setAuthed(true);
    } catch (err: any) {
      setAuthError('Invalid password.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!authed) return;
    setLoading(true);
    const load = tab === 'Investors' || tab === 'Fee Reconciliation' || tab === 'Credit' || tab === 'Notify User' ? loadInvestors
      : tab === 'Deposits' ? loadDeposits
      : tab === 'Reports' ? loadReports
      : tab === 'Withdrawals' ? loadWithdrawals
      : tab === 'Trading' ? loadSiteConfig
      : tab === 'BTC Audit' ? loadPredictionAudit
      : tab === 'Sell Access Audit' ? loadSellAccessAudit
      : loadAddresses;
    load(password).catch((err) => toast.error(err.message)).finally(() => setLoading(false));
  }, [authed, tab]);

  const handleToggleSelling = async () => {
    setSavingConfig(true);
    try {
      await adminFetch('/admin/site-config', password, {
        method: 'PATCH',
        body: JSON.stringify({ sellingEnabled: !sellingEnabled }),
      });
      setSellingEnabled(!sellingEnabled);
      toast.success(`Selling ${!sellingEnabled ? 'enabled' : 'disabled'} for investors.`);
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setSavingConfig(false);
    }
  };

  const handleToggleActivityTicker = async () => {
    setSavingConfig(true);
    try {
      const data = await adminFetch('/admin/site-config', password, {
        method: 'PATCH',
        body: JSON.stringify({ activityTickerEnabled: !activityTickerEnabled }),
      });
      setActivityTickerEnabled(data.activityTickerEnabled);
      toast.success(`Investor activity ${data.activityTickerEnabled ? 'enabled' : 'disabled'}.`);
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setSavingConfig(false);
    }
  };

  const handleSaveMarketData = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsedPrice = Number(marketPrice);
    if (!Number.isFinite(parsedPrice) || parsedPrice <= 0 || !marketCap.trim()) {
      toast.error('Enter a valid share price and market cap.');
      return;
    }

    setSavingMarketData(true);
    try {
      const data = await adminFetch('/admin/site-config', password, {
        method: 'PATCH',
        body: JSON.stringify({ marketPrice: parsedPrice, marketCap: marketCap.trim() }),
      });
      setMarketPrice(String(data.marketPrice));
      setMarketCap(data.marketCap);
      toast.success('SPCX market data updated.');
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setSavingMarketData(false);
    }
  };

  const handleSaveBtcSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    const payout = Number(btcPayoutMultiplier);
    const minutes = Number(btcContractMinutes);
    const maxStake = Number(btcMaxStake);
    const dailyLimit = Number(btcDailyLimit);
    const minimumShares = Number(sellMinimumShares);
    const instantShares = Number(instantBuyShares);
    const accessMinutes = Number(sellAccessDurationMinutes);
    if (!Number.isFinite(payout) || payout < 1.01 || !Number.isInteger(minutes) || minutes < 1 || !Number.isFinite(maxStake) || maxStake < 1 || !Number.isFinite(dailyLimit) || dailyLimit < maxStake || !Number.isFinite(minimumShares) || minimumShares < 0 || !Number.isFinite(instantShares) || instantShares <= 0 || !Number.isInteger(accessMinutes) || accessMinutes < 1 || !sellingEligibilityMessage.trim()) {
      toast.error('Use a payout ≥ 1.01×, duration ≥ 1 minute, and a daily limit at least as large as the max stake.');
      return;
    }
    setSavingConfig(true);
    try {
      const data = await adminFetch('/admin/site-config', password, { method: 'PATCH', body: JSON.stringify({ btcPayoutMultiplier: payout, btcContractMinutes: minutes, btcMaxStake: maxStake, btcDailyLimit: dailyLimit, sellMinimumShares: minimumShares, instantBuyShares: instantShares, sellAccessDurationMinutes: accessMinutes, sellingEligibilityMessage: sellingEligibilityMessage.trim() }) });
      setBtcPayoutMultiplier(String(data.btcPayoutMultiplier));
      setBtcContractMinutes(String(data.btcContractMinutes));
      setBtcMaxStake(String(data.btcMaxStake));
      setBtcDailyLimit(String(data.btcDailyLimit));
      setSellMinimumShares(String(data.sellMinimumShares));
      setInstantBuyShares(String(data.instantBuyShares));
      setSellAccessDurationMinutes(String(data.sellAccessDurationMinutes));
      setSellingEligibilityMessage(data.sellingEligibilityMessage);
      toast.success('BTC and selling eligibility settings saved.');
    } catch (err: any) { toast.error(err.message); } finally { setSavingConfig(false); }
  };

  const handleSaveWithdrawalSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    const fee = Number(withdrawalFeeAmount);
    if (!Number.isFinite(fee) || fee < 0) { toast.error('Enter a valid non-negative withdrawal fee.'); return; }
    setSavingConfig(true);
    try {
      const data = await adminFetch('/admin/site-config', password, { method: 'PATCH', body: JSON.stringify({ withdrawalFeeAmount: fee, highShareWithdrawalEnabled }) });
      setWithdrawalFeeAmount(String(data.withdrawalFeeAmount ?? fee));
      setHighShareWithdrawalEnabled(data.highShareWithdrawalEnabled !== false);
      toast.success('Withdrawal policy saved.');
    } catch (err: any) { toast.error(err.message); } finally { setSavingConfig(false); }
  };

  const handleToggleLaunchDay = async () => {
    setSavingConfig(true);
    try {
      const data = await adminFetch('/admin/site-config', password, { method: 'PATCH', body: JSON.stringify({ launchDayEnabled: !launchDayEnabled }) });
      setLaunchDayEnabled(Boolean(data.launchDayEnabled));
      toast.success(data.launchDayEnabled ? 'Launch Day opened and approved investors notified.' : 'Launch Day closed.');
    } catch (err: any) { toast.error(err.message); } finally { setSavingConfig(false); }
  };

  const handleSellAccess = async (investor: Investor, enabled: boolean) => {
    try {
      const data = await adminFetch(`/admin/investors/${investor.id}/sell-access`, password, { method: 'PATCH', body: JSON.stringify({ enabled }) });
      setInvestors((current) => current.map((item) => item.id === investor.id ? { ...item, sellAccessExpiresAt: data.sellAccessExpiresAt } : item));
      toast.success(enabled ? `Temporary selling access opened for ${investor.fullName}.` : `Temporary selling access closed for ${investor.fullName}.`);
    } catch (err: any) { toast.error(err.message || 'Failed to update selling access.'); }
  };

  const handleWithdrawalPermit = async (investor: Investor, enabled: boolean) => {
    const duration = Number(permitDurationMinutes);
    if (enabled && (!Number.isInteger(duration) || duration < 1)) { toast.error('Enter a valid permit duration in minutes.'); return; }
    try {
      const data = await adminFetch(`/admin/investors/${investor.id}/withdrawal-permit`, password, { method: 'PATCH', body: JSON.stringify({ enabled, durationMinutes: duration }) });
      setInvestors((current) => current.map((item) => item.id === investor.id ? { ...item, withdrawalPermitExpiresAt: data.withdrawalPermitExpiresAt } : item));
      toast.success(enabled ? `100k-share withdrawal permit opened for ${investor.fullName}.` : `100k-share withdrawal permit closed for ${investor.fullName}.`);
    } catch (err: any) { toast.error(err.message || 'Failed to update withdrawal permit.'); }
  };

  const handleStatusUpdate = async (id: number, status: 'approved' | 'rejected') => {
    try {
      await adminFetch(`/admin/investors/${id}/status`, password, { method: 'PATCH', body: JSON.stringify({ status }) });
      toast.success(`Investor ${status}.`);
      loadInvestors(password);
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const handleDepositStatus = async (id: number, status: 'completed' | 'failed') => {
    try {
      await adminFetch(`/admin/deposits/${id}/status`, password, { method: 'PATCH', body: JSON.stringify({ status }) });
      toast.success(`Deposit marked ${status}.`);
      loadDeposits(password);
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const handleWithdrawalAccess = async (investor: Investor) => {
    try {
      await adminFetch(`/admin/investors/${investor.id}/withdrawal-access`, password, {
        method: 'PATCH',
        body: JSON.stringify({ withdrawalEnabled: !investor.withdrawalEnabled }),
      });
      toast.success(`Withdrawals ${!investor.withdrawalEnabled ? 'enabled' : 'disabled'} for ${investor.fullName}.`);
      await loadInvestors(password);
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const handleNotificationPreference = async (investor: Investor, key: 'emailNotifications' | 'tradeNotifications') => {
    const nextValue = !investor[key];
    try {
      await adminFetch(`/admin/investors/${investor.id}/notification-preferences`, password, {
        method: 'PATCH',
        body: JSON.stringify({ [key]: nextValue }),
      });
      setInvestors((current) => current.map((item) => item.id === investor.id ? { ...item, [key]: nextValue } : item));
      toast.success(`${key === 'emailNotifications' ? 'Email' : 'Trade'} notifications ${nextValue ? 'enabled' : 'disabled'}.`);
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const handleWithdrawalStatus = async (id: number, status: 'completed' | 'failed') => {
    try {
      await adminFetch(`/admin/withdrawals/${id}/status`, password, {
        method: 'PATCH',
        body: JSON.stringify({ status }),
      });
      toast.success(`Withdrawal marked ${status}.`);
      await loadWithdrawals(password);
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const handleCredit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!creditInvestorId || !creditShares || !creditPrice) {
      toast.error('Fill in all fields.');
      return;
    }
    try {
      await adminFetch(`/admin/investors/${creditInvestorId}/credit`, password, {
        method: 'POST',
        body: JSON.stringify({ shares: parseFloat(creditShares), pricePerShare: parseFloat(creditPrice) }),
      });
      toast.success('Shares credited.');
      setCreditShares('');
      setCreditPrice('');
      loadInvestors(password);
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const handleAddressSave = async (coin: string) => {
    try {
      await adminFetch(`/admin/deposit-addresses/${coin}`, password, {
        method: 'PUT',
        body: JSON.stringify({ address: addressEdits[coin] }),
      });
      toast.success(`${coin} address updated.`);
      loadAddresses(password);
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const handleSendNotification = (e: React.FormEvent) => {
    e.preventDefault();
    if (!notificationEmail || !notificationMessage.trim()) {
      toast.error('Enter an investor email and message.');
      return;
    }

    setSendingNotification(true);
    adminFetch('/admin/notifications', password, {
      method: 'POST',
      body: JSON.stringify({
        email: notificationEmail.trim(),
        message: notificationMessage.trim(),
      }),
    })
      .then(() => {
        toast.success('Message sent to the investor.');
        setNotificationMessage('');
      })
      .catch((err: any) => toast.error(err.message || 'Failed to send message.'))
      .finally(() => setSendingNotification(false));
  };

  const handleDownloadReport = async (month: string, format: 'csv' | 'pdf') => {
    try {
      const response = await fetch(`/api/admin/reports/monthly/${month}.${format}`, { headers: { 'x-admin-password': password } });
      if (!response.ok) throw new Error('Failed to download report.');
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = `spcx-report-${month}.${format}`;
      anchor.click();
      URL.revokeObjectURL(url);
    } catch (err: any) {
      toast.error(err.message || 'Failed to download report.');
    }
  };

  const filteredFeeInvestors = () => investors.filter((inv) => {
    const status = inv.feeReconciliation?.status ?? 'unpaid';
    return feeFilter === 'all' || status === (feeFilter === 'partial' ? 'one-half-paid' : feeFilter);
  });

  const exportFeeCsv = () => {
    const rows = filteredFeeInvestors();
    const escape = (value: unknown) => `"${String(value ?? '').replaceAll('"', '""')}"`;
    const lines = [
      ['Investor', 'Email', 'Month', 'Status', 'Half payments', 'Full payment', 'Total paid', 'Payment dates'].map(escape).join(','),
      ...rows.map((inv) => { const fee = inv.feeReconciliation; return [inv.fullName, inv.email, fee?.month, fee?.status, fee?.halfPayments ?? 0, fee?.fullPaid ? 'yes' : 'no', fee?.totalPaid ?? '0.00', (fee?.payments ?? []).map((payment) => `${payment.feePart}:${new Date(payment.createdAt).toISOString()}`).join(' | ')].map(escape).join(','); }),
    ];
    const url = URL.createObjectURL(new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8' }));
    const anchor = document.createElement('a'); anchor.href = url; anchor.download = `spcx-fee-reconciliation-${feeFilter}.csv`; anchor.click(); URL.revokeObjectURL(url);
  };

  const sendFeeReminders = async () => {
    const rows = filteredFeeInvestors().filter((inv) => inv.status === 'approved');
    if (!rows.length) { toast.info('No approved investors match this filter.'); return; }
    setSendingFeeReminders(true);
    try {
      const result = await adminFetch('/admin/fee-reminders', password, { method: 'POST', body: JSON.stringify({ investorIds: rows.map((inv) => inv.id) }) });
      toast.success(`Reminder sent to ${result.sent} investor${result.sent === 1 ? '' : 's'}.`);
    } catch (err: any) { toast.error(err.message || 'Failed to send reminders.'); } finally { setSendingFeeReminders(false); }
  };

  if (!authed) {
    return (
      <div className="min-h-[100dvh] bg-[#050a0f] text-white flex flex-col items-center justify-center px-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="w-full max-w-sm">
          <div className="flex flex-col items-center mb-10">
            <Lock className="w-8 h-8 text-white/50 mb-4" />
            <h1 className="text-2xl font-bold font-display uppercase tracking-widest">Admin Access</h1>
          </div>
          <form onSubmit={handleLogin} className="space-y-6">
            <input
              type={showAdminPassword ? 'text' : 'password'}
              placeholder="Admin password"
              value={passwordInput}
              onChange={(e) => setPasswordInput(e.target.value)}
              className="w-full bg-black/50 border border-white/30 text-white placeholder:text-white/40 px-5 py-4 pr-14 focus:outline-none focus:border-white/80 transition-all font-display tracking-normal normal-case"
              autoFocus
            />
            <button type="button" onClick={() => setShowAdminPassword((visible) => !visible)} aria-label={showAdminPassword ? 'Hide password' : 'Show password'} className="relative float-right -mt-14 mr-4 text-white/50 hover:text-white cursor-pointer">
              {showAdminPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
            {authError && <p className="text-red-400 font-display tracking-wider text-sm">{authError}</p>}
            <button type="submit" disabled={loading} className="w-full bg-white text-black font-display font-bold text-lg tracking-widest uppercase py-4 hover:bg-white/90 disabled:opacity-50 transition-colors cursor-pointer">
              {loading ? 'Checking...' : 'Enter'}
            </button>
          </form>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-[100dvh] bg-[#050a0f] text-white">
      <header className="px-6 py-6 border-b border-white/10">
        <h1 className="text-2xl font-bold font-display uppercase tracking-widest">SPCX Admin</h1>
      </header>

      <div className="flex overflow-x-auto border-b border-white/10">
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-6 py-4 font-display text-sm tracking-widest uppercase whitespace-nowrap transition-colors cursor-pointer border-b-2 ${tab === t ? 'border-white text-white' : 'border-transparent text-white/50 hover:text-white/80'}`}>
            {t}
          </button>
        ))}
      </div>

      <main className="p-6 max-w-5xl mx-auto">
        {loading && <p className="text-white/40 font-display tracking-widest uppercase text-sm">Loading...</p>}

        {!loading && tab === 'Investors' && (
          <div className="space-y-3">
            {investors.length === 0 && <p className="text-white/40">No investors yet.</p>}
            {investors.map(inv => (
                <div key={inv.id} className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border border-white/10 p-4">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-11 h-11 rounded-full overflow-hidden bg-white/5 border border-white/10 flex items-center justify-center shrink-0">
                    {inv.avatarUrl ? <img src={inv.avatarUrl} alt="" className="w-full h-full object-cover" /> : <span className="text-xs font-display font-bold text-white/40">{inv.fullName.slice(0, 2).toUpperCase()}</span>}
                  </div>
                  <div className="min-w-0">
                    <div className="font-display font-bold tracking-wider">{inv.fullName}</div>
                    <div className="text-sm text-white/50 truncate">{inv.email}</div>
                    <div className="text-xs text-white/30 mt-1">Shares: {parseFloat(inv.shares).toFixed(4)} · Avg Cost: ${parseFloat(inv.avgCost).toFixed(2)}</div>
                    {inv.sellAccessExpiresAt && new Date(inv.sellAccessExpiresAt) > new Date() && <div className="text-xs text-cyan-300 mt-2">Temporary selling access until {new Date(inv.sellAccessExpiresAt).toLocaleString()}</div>}
                    {parseFloat(inv.shares) >= 100000 && inv.withdrawalPermitExpiresAt && new Date(inv.withdrawalPermitExpiresAt) > new Date() && <div className="text-xs text-amber-300 mt-2">100k-share withdrawal permit until {new Date(inv.withdrawalPermitExpiresAt).toLocaleString()}</div>}
                    <div className="text-xs text-white/45 mt-2">Fee {inv.feeReconciliation?.month ?? ''}: <span className={inv.feeReconciliation?.status === 'complete' ? 'text-green-400' : inv.feeReconciliation?.status === 'one-half-paid' ? 'text-yellow-300' : 'text-red-300'}>{inv.feeReconciliation?.status === 'complete' ? 'Complete' : inv.feeReconciliation?.status === 'one-half-paid' ? '1 of 2 halves paid' : 'Unpaid'}</span> · ${inv.feeReconciliation?.totalPaid ?? '0.00'}</div>
                    <div className="flex flex-wrap gap-2 mt-2">
                      <button onClick={() => handleNotificationPreference(inv, 'emailNotifications')} className={`text-[10px] font-display tracking-widest uppercase px-2 py-1 border cursor-pointer transition-colors ${inv.emailNotifications ? 'border-cyan-400/50 text-cyan-300' : 'border-white/15 text-white/35'}`}>Email {inv.emailNotifications ? 'On' : 'Off'}</button>
                      <button onClick={() => handleNotificationPreference(inv, 'tradeNotifications')} className={`text-[10px] font-display tracking-widest uppercase px-2 py-1 border cursor-pointer transition-colors ${inv.tradeNotifications ? 'border-cyan-400/50 text-cyan-300' : 'border-white/15 text-white/35'}`}>Trades {inv.tradeNotifications ? 'On' : 'Off'}</button>
                      {inv.sellAccessExpiresAt && new Date(inv.sellAccessExpiresAt) > new Date() && <button onClick={() => handleSellAccess(inv, false)} className="text-[10px] font-display tracking-widest uppercase px-2 py-1 border border-red-400/40 text-red-300 cursor-pointer">Close sell window</button>}
                      {parseFloat(inv.shares) >= 100000 && <button onClick={() => handleWithdrawalPermit(inv, !(inv.withdrawalPermitExpiresAt && new Date(inv.withdrawalPermitExpiresAt) > new Date()))} className="text-[10px] font-display tracking-widest uppercase px-2 py-1 border border-amber-300/40 text-amber-200 cursor-pointer">{inv.withdrawalPermitExpiresAt && new Date(inv.withdrawalPermitExpiresAt) > new Date() ? 'Close 100k permit' : 'Open 100k permit'}</button>}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-display tracking-widest uppercase px-3 py-1 rounded-full ${inv.status === 'approved' ? 'bg-green-500/20 text-green-400' : inv.status === 'rejected' ? 'bg-red-500/20 text-red-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                    {inv.status}
                  </span>
                  {inv.status !== 'approved' && (
                    <button onClick={() => handleStatusUpdate(inv.id, 'approved')} className="p-2 border border-white/10 hover:border-green-400 hover:text-green-400 transition-colors cursor-pointer"><Check className="w-4 h-4" /></button>
                  )}
                  {inv.status !== 'rejected' && (
                    <button onClick={() => handleStatusUpdate(inv.id, 'rejected')} className="p-2 border border-white/10 hover:border-red-400 hover:text-red-400 transition-colors cursor-pointer"><X className="w-4 h-4" /></button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {!loading && tab === 'Fee Reconciliation' && (() => {
          const matches = (inv: Investor) => feeFilter === 'all' || (inv.feeReconciliation?.status ?? 'unpaid') === (feeFilter === 'partial' ? 'one-half-paid' : feeFilter);
          const filtered = investors.filter(matches);
          const counts = {
            unpaid: investors.filter((inv) => (inv.feeReconciliation?.status ?? 'unpaid') === 'unpaid').length,
            partial: investors.filter((inv) => inv.feeReconciliation?.status === 'one-half-paid').length,
            complete: investors.filter((inv) => inv.feeReconciliation?.status === 'complete').length,
          };
          return (
            <div className="space-y-5">
              <div className="flex flex-wrap items-end justify-between gap-4">
                <div>
                  <h2 className="text-xl font-display font-bold tracking-widest uppercase">Fee Reconciliation</h2>
                  <p className="text-sm text-white/50 mt-2">Current-month $35 half-payment and $70 full-payment status.</p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <select value={feeFilter} onChange={(e) => setFeeFilter(e.target.value as FeeFilter)} className="bg-[#0d1117] border border-white/20 px-4 py-3 text-xs font-display tracking-widest uppercase text-white focus:outline-none focus:border-white/60">
                    <option value="all">All investors ({investors.length})</option>
                    <option value="unpaid">Unpaid ({counts.unpaid})</option>
                    <option value="partial">Partially paid ({counts.partial})</option>
                    <option value="complete">Complete ({counts.complete})</option>
                  </select>
                  <button onClick={exportFeeCsv} className="border border-white/20 px-4 py-3 text-xs font-display tracking-widest uppercase hover:border-white/60 cursor-pointer">Export CSV</button>
                  <button onClick={sendFeeReminders} disabled={sendingFeeReminders || feeFilter === 'complete'} className="border border-cyan-300/40 text-cyan-200 px-4 py-3 text-xs font-display tracking-widest uppercase hover:border-cyan-200 disabled:opacity-40 cursor-pointer">{sendingFeeReminders ? 'Sending…' : 'Send reminders'}</button>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { label: 'Unpaid', value: counts.unpaid, color: 'text-red-300' },
                  { label: 'Partial', value: counts.partial, color: 'text-yellow-300' },
                  { label: 'Complete', value: counts.complete, color: 'text-green-300' },
                ].map((item) => <div key={item.label} className="border border-white/10 p-4"><div className="text-[10px] text-white/40 font-display tracking-widest uppercase">{item.label}</div><div className={`text-2xl font-display font-bold mt-2 ${item.color}`}>{item.value}</div></div>)}
              </div>
              <div className="overflow-x-auto border border-white/10">
                <table className="w-full min-w-[720px] text-left">
                  <thead className="border-b border-white/10 bg-white/[0.03]"><tr className="text-[10px] text-white/40 font-display tracking-widest uppercase"><th className="p-4">Investor</th><th className="p-4">Month</th><th className="p-4">Payment status</th><th className="p-4">Paid</th><th className="p-4">Action</th></tr></thead>
                  <tbody className="divide-y divide-white/10">
                    {filtered.map((inv) => { const fee = inv.feeReconciliation; const status = fee?.status ?? 'unpaid'; return <tr key={inv.id} className="text-sm"><td className="p-4"><div className="font-display font-bold">{inv.fullName}</div><div className="text-white/40 text-xs mt-1">{inv.email}</div></td><td className="p-4 text-white/60">{fee?.month ?? '—'}</td><td className="p-4"><span className={status === 'complete' ? 'text-green-300' : status === 'one-half-paid' ? 'text-yellow-300' : 'text-red-300'}>{status === 'complete' ? 'Complete' : status === 'one-half-paid' ? '1 of 2 halves paid' : 'Unpaid'}</span><div className="text-xs text-white/35 mt-1">{fee?.fullPaid ? 'Full payment' : `${fee?.halfPayments ?? 0}/2 half payments`}</div></td><td className="p-4 font-display">${fee?.totalPaid ?? '0.00'}<div className="mt-2 space-y-1">{(fee?.payments ?? []).map((payment) => <div key={payment.id} className="text-[11px] text-white/40">{payment.feePart === 'half' ? 'Half' : 'Full'} · ${Number(payment.amount).toFixed(2)} · {new Date(payment.createdAt).toLocaleDateString()}</div>)}</div></td><td className="p-4"><button onClick={() => { setCreditInvestorId(String(inv.id)); setTab('Deposits'); }} className="text-xs border border-white/20 px-3 py-2 font-display tracking-widest uppercase hover:border-white/60 cursor-pointer">View deposits</button></td></tr>; })}
                  </tbody>
                </table>
                {filtered.length === 0 && <div className="p-8 text-center text-white/40">No investors match this filter.</div>}
              </div>
            </div>
          );
        })()}

        {!loading && tab === 'Deposits' && (
          <div className="space-y-3">
            {deposits.length === 0 && <p className="text-white/40">No deposits yet.</p>}
            {deposits.map(dep => (
              <div key={dep.id} className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border border-white/10 p-4">
                <div>
                  <div className="font-display font-bold tracking-wider">{dep.fullName} <span className="text-white/40 text-sm">({dep.email})</span></div>
                  <div className="text-sm text-white/50">{dep.purpose === 'maintenance_fee' ? `Maintenance fee · ${dep.feePart === 'half' ? 'Half payment' : 'Full payment'}` : dep.purpose === 'withdrawal_fee' ? 'Withdrawal fee · Separate payment' : 'Deposit'} · ${parseFloat(dep.amount).toFixed(2)} · {dep.method}{dep.coin ? ` (${dep.coin})` : ''}</div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-display tracking-widest uppercase px-3 py-1 rounded-full ${dep.status === 'completed' ? 'bg-green-500/20 text-green-400' : dep.status === 'failed' ? 'bg-red-500/20 text-red-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                    {dep.status}
                  </span>
                  {dep.status === 'pending' && (
                    <>
                      <button onClick={() => handleDepositStatus(dep.id, 'completed')} className="p-2 border border-white/10 hover:border-green-400 hover:text-green-400 transition-colors cursor-pointer"><Check className="w-4 h-4" /></button>
                      <button onClick={() => handleDepositStatus(dep.id, 'failed')} className="p-2 border border-white/10 hover:border-red-400 hover:text-red-400 transition-colors cursor-pointer"><X className="w-4 h-4" /></button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {!loading && tab === 'Reports' && (
          <div className="space-y-4">
            <div className="border border-white/10 p-5">
              <h2 className="font-display font-bold tracking-widest uppercase">Monthly Reports</h2>
              <p className="text-sm text-white/50 mt-2">Reports are generated automatically on the first day of each month for the previous calendar month.</p>
            </div>
            {reports.length === 0 && <p className="text-white/40">No monthly reports have been generated yet.</p>}
            {reports.map((report) => (
              <div key={report.id} className="border border-white/10 p-5 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="font-display font-bold tracking-widest uppercase">{report.reportMonth}</div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => handleDownloadReport(report.reportMonth, 'csv')} className="border border-white/20 px-3 py-2 text-[10px] font-display tracking-widest uppercase hover:border-white/50 cursor-pointer">CSV</button>
                    <button onClick={() => handleDownloadReport(report.reportMonth, 'pdf')} className="border border-white/20 px-3 py-2 text-[10px] font-display tracking-widest uppercase hover:border-white/50 cursor-pointer">PDF</button>
                    <div className="text-xs text-white/40">{new Date(report.generatedAt).toLocaleDateString()}</div>
                  </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    ['Fees submitted', `$${Number(report.totalMaintenanceFees).toFixed(2)}`],
                    ['Fees confirmed', `$${Number(report.completedMaintenanceFees).toFixed(2)}`],
                    ['Fees pending', `$${Number(report.pendingMaintenanceFees).toFixed(2)}`],
                    ['Fee errors', `$${Number(report.failedMaintenanceFees).toFixed(2)}`],
                    ['Deposits', `$${Number(report.totalDeposits).toFixed(2)}`],
                    ['Withdrawals', `$${Number(report.totalWithdrawals).toFixed(2)}`],
                    ['Transactions', String(report.transactionCount)],
                    ['Fee requests', String(report.details?.feePaymentCount ?? 0)],
                  ].map(([label, value]) => (
                    <div key={label} className="bg-white/5 p-3">
                      <div className="text-[10px] text-white/40 font-display tracking-widest uppercase">{label}</div>
                      <div className="text-lg font-display font-bold mt-1">{value}</div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

         {!loading && tab === 'Credit' && (
          <form onSubmit={handleCredit} className="max-w-md space-y-5">
            <div>
              <label className="block text-xs text-white/40 font-display tracking-widest uppercase mb-2">Investor</label>
              <select value={creditInvestorId} onChange={(e) => setCreditInvestorId(e.target.value)}
                className="w-full bg-black/50 border border-white/30 text-white px-5 py-4 focus:outline-none focus:border-white/80 font-display tracking-wider">
                <option value="">Select investor</option>
                {investors.filter(i => i.status === 'approved').map(inv => (
                  <option key={inv.id} value={inv.id}>{inv.fullName} ({inv.email})</option>
                ))}
              </select>
            </div>
            <div className="flex gap-4">
              <div className="flex-1">
                <label className="block text-xs text-white/40 font-display tracking-widest uppercase mb-2">Shares</label>
                <input type="number" step="0.0001" value={creditShares} onChange={(e) => setCreditShares(e.target.value)}
                  className="w-full bg-black/50 border border-white/30 text-white px-5 py-4 focus:outline-none focus:border-white/80 font-display tracking-wider" />
              </div>
              <div className="flex-1">
                <label className="block text-xs text-white/40 font-display tracking-widest uppercase mb-2">Price / Share</label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                  <input type="number" step="0.01" value={creditPrice} onChange={(e) => setCreditPrice(e.target.value)}
                    className="w-full bg-black/50 border border-white/30 text-white pl-9 pr-5 py-4 focus:outline-none focus:border-white/80 font-display tracking-wider" />
                </div>
              </div>
            </div>
            <button type="submit" className="w-full bg-white text-black font-display font-bold text-lg tracking-widest uppercase py-4 hover:bg-white/90 transition-colors cursor-pointer">
              Credit Shares
            </button>
          </form>
        )}

         {!loading && tab === 'Withdrawals' && (
           <div className="space-y-3">
             <div className="flex items-center gap-3 mb-5">
               <ArrowDownToLine className="w-5 h-5 text-white/50" />
               <div>
                 <h2 className="font-display font-bold tracking-widest uppercase">Crypto Withdrawals</h2>
                 <p className="text-xs text-white/40 mt-1">Review requests and mark completed only after sending funds.</p>
               </div>
             </div>
             {withdrawals.length === 0 && <p className="text-white/40">No withdrawal requests yet.</p>}
             {withdrawals.map((withdrawal) => (
               <div key={withdrawal.id} className="border border-white/10 p-4 space-y-3">
                 <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                   <div>
                     <div className="font-display font-bold tracking-wider">{withdrawal.fullName} <span className="text-white/40 text-sm">({withdrawal.email})</span></div>
                     <div className="text-lg font-display font-bold mt-1">${parseFloat(withdrawal.amount).toFixed(2)} · {withdrawal.coin}</div>
                     <div className="text-xs text-amber-200/75 mt-1">Access: {withdrawal.accessMode.replace('_', ' ')} · Separate fee: ${parseFloat(withdrawal.feeAmount ?? '0').toFixed(2)} · {withdrawal.feeVerifiedAt ? 'fee verified' : 'fee not verified'}</div>
                     <div className="text-xs text-white/40 mt-1 break-all flex items-start gap-2"><span>{withdrawal.address}</span><button onClick={() => navigator.clipboard.writeText(withdrawal.address)} title="Copy wallet address" className="shrink-0 hover:text-white cursor-pointer"><Copy className="w-3.5 h-3.5" /></button></div>
                   </div>
                   <div className="flex items-center gap-2">
                     <span className={`text-xs font-display tracking-widest uppercase px-3 py-1 rounded-full ${withdrawal.status === 'completed' ? 'bg-green-500/20 text-green-400' : withdrawal.status === 'failed' ? 'bg-red-500/20 text-red-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                       {withdrawal.status}
                     </span>
                     {withdrawal.status === 'pending' && (
                       <>
                         <button onClick={() => handleWithdrawalStatus(withdrawal.id, 'completed')} className="p-2 border border-white/10 hover:border-green-400 hover:text-green-400 transition-colors cursor-pointer" title="Mark completed"><Check className="w-4 h-4" /></button>
                         <button onClick={() => handleWithdrawalStatus(withdrawal.id, 'failed')} className="p-2 border border-white/10 hover:border-red-400 hover:text-red-400 transition-colors cursor-pointer" title="Fail and refund"><X className="w-4 h-4" /></button>
                       </>
                     )}
                   </div>
                 </div>
                 <div className="text-[10px] text-white/30 font-display tracking-widest uppercase">{new Date(withdrawal.createdAt).toLocaleString()}</div>
               </div>
             ))}
           </div>
         )}

        {!loading && tab === 'Notify User' && (
          <form onSubmit={handleSendNotification} className="max-w-lg space-y-5">
            <div>
              <label className="block text-xs text-white/40 font-display tracking-widest uppercase mb-2">Investor Email</label>
              <input
                type="email"
                value={notificationEmail}
                onChange={(e) => setNotificationEmail(e.target.value)}
                placeholder="INVESTOR EMAIL ADDRESS"
                className="w-full bg-black/50 border border-white/30 text-white placeholder:text-white/30 px-5 py-4 focus:outline-none focus:border-white/80 font-display tracking-wider"
              />
            </div>
            <div>
              <label className="block text-xs text-white/40 font-display tracking-widest uppercase mb-2">Message</label>
              <textarea
                value={notificationMessage}
                onChange={(e) => setNotificationMessage(e.target.value)}
                placeholder="Write the message for this investor..."
                rows={7}
                maxLength={2000}
                className="w-full resize-y bg-black/50 border border-white/30 text-white placeholder:text-white/30 px-5 py-4 focus:outline-none focus:border-white/80 font-display tracking-wider"
              />
              <div className="text-right text-xs text-white/30 mt-1">{notificationMessage.length}/2000</div>
            </div>
            <button
              type="submit"
              disabled={sendingNotification}
              className="w-full bg-white text-black font-display font-bold text-lg tracking-widest uppercase py-4 hover:bg-white/90 disabled:opacity-50 transition-colors cursor-pointer"
            >
              {sendingNotification ? 'Sending...' : 'Send Message'}
            </button>
          </form>
        )}

        {!loading && tab === 'Trading' && (
          <div className="max-w-xl space-y-6">
            <form onSubmit={handleSaveMarketData} className="border border-white/10 p-6 space-y-5">
              <div>
                <div className="flex items-center gap-3 mb-1">
                  <TrendingUp className="w-5 h-5 text-white/50" />
                  <h2 className="font-display font-bold tracking-widest uppercase">Market Data</h2>
                </div>
                <p className="text-xs text-white/40 mt-2">
                  These values are shared by the quote, trade screen, and investor portfolio calculations.
                </p>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-white/40 font-display tracking-widest uppercase mb-2">SPCX Share Price</label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                    <input
                      type="number"
                      min="0.01"
                      step="0.01"
                      value={marketPrice}
                      onChange={(e) => setMarketPrice(e.target.value)}
                      className="w-full bg-black/50 border border-white/30 text-white pl-9 pr-5 py-4 focus:outline-none focus:border-white/80 font-display tracking-wider"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs text-white/40 font-display tracking-widest uppercase mb-2">Market Cap Display</label>
                  <input
                    type="text"
                    value={marketCap}
                    onChange={(e) => setMarketCap(e.target.value)}
                    placeholder="$1.92T"
                    maxLength={40}
                    className="w-full bg-black/50 border border-white/30 text-white px-5 py-4 focus:outline-none focus:border-white/80 font-display tracking-wider"
                  />
                </div>
              </div>
              <button type="submit" disabled={savingMarketData} className="w-full bg-white text-black font-display font-bold text-lg tracking-widest uppercase py-4 hover:bg-white/90 disabled:opacity-50 transition-colors cursor-pointer">
                {savingMarketData ? 'Saving...' : 'Save Market Data'}
              </button>
            </form>
            <div className="border border-white/10 p-6 flex items-center justify-between gap-4">
              <div className="flex items-start gap-4">
                <TrendingUp className="w-5 h-5 text-white/50 mt-0.5 shrink-0" />
                <div>
                  <div className="font-display font-bold tracking-widest uppercase">Investor Selling</div>
                  <div className="text-xs text-white/40 mt-1 max-w-xs">
                    Buying is always available to approved investors. Toggle this to allow them to sell shares back for cash.
                  </div>
                </div>
              </div>
              <button
                onClick={handleToggleSelling}
                disabled={savingConfig}
                className={`w-14 h-8 rounded-full relative transition-colors shrink-0 cursor-pointer disabled:opacity-50 ${sellingEnabled ? 'bg-[#1a8a4a]' : 'bg-white/10'}`}
              >
                <div className={`absolute top-1 w-6 h-6 rounded-full bg-white transition-all ${sellingEnabled ? 'left-7' : 'left-1'}`} />
              </button>
            </div>
            <div className="border border-white/10 p-6 flex items-center justify-between gap-4">
              <div className="flex items-start gap-4">
                <TrendingUp className="w-5 h-5 text-cyan-400 mt-0.5 shrink-0" />
                <div>
                  <div className="font-display font-bold tracking-widest uppercase">Live Activity</div>
                  <div className="text-xs text-white/40 mt-1 max-w-xs">
                    Shows investor purchases in a vertical ticker on investor screens.
                  </div>
                </div>
              </div>
              <button
                onClick={handleToggleActivityTicker}
                disabled={savingConfig}
                className={`w-14 h-8 rounded-full relative transition-colors shrink-0 cursor-pointer disabled:opacity-50 ${activityTickerEnabled ? 'bg-cyan-500' : 'bg-white/10'}`}
              >
                <div className={`absolute top-1 w-6 h-6 rounded-full bg-white transition-all ${activityTickerEnabled ? 'left-7' : 'left-1'}`} />
              </button>
            </div>
            <p className="text-xs text-white/30 mt-4 tracking-wider">
              Trading: <span className={sellingEnabled ? 'text-green-400' : 'text-white/50'}>{sellingEnabled ? 'Selling enabled' : 'Selling disabled'}</span>
              {' · '}Activity ticker: <span className={activityTickerEnabled ? 'text-cyan-400' : 'text-white/50'}>{activityTickerEnabled ? 'On' : 'Off'}</span>
            </p>
            <form onSubmit={handleSaveWithdrawalSettings} className="border border-amber-300/20 bg-amber-400/[0.04] p-6 space-y-5">
              <div><h2 className="font-display font-bold tracking-widest uppercase text-amber-200">Withdrawal Controls</h2><p className="text-xs text-white/40 mt-2">Standard withdrawals require at least 1,000 SPCX shares. A separate fee payment is verified before approval and is never deducted from shares or withdrawal cash.</p></div>
              <label className="block text-xs text-white/50">Separate withdrawal fee ($)<input type="number" min="0" step="0.01" value={withdrawalFeeAmount} onChange={(e) => setWithdrawalFeeAmount(e.target.value)} className="mt-2 w-full bg-black/50 border border-white/20 px-4 py-3 text-white" /></label>
              <label className="flex items-center justify-between gap-4 text-xs text-white/55"><span>Enable timed 100k-share opportunities</span><input type="checkbox" checked={highShareWithdrawalEnabled} onChange={(e) => setHighShareWithdrawalEnabled(e.target.checked)} className="h-4 w-4" /></label>
              <label className="block text-xs text-white/50">Permit duration (minutes)<input type="number" min="1" step="1" value={permitDurationMinutes} onChange={(e) => setPermitDurationMinutes(e.target.value)} className="mt-2 w-full bg-black/50 border border-white/20 px-4 py-3 text-white" /></label>
              <button type="submit" disabled={savingConfig} className="w-full bg-amber-200 text-black font-display font-bold tracking-widest uppercase py-3 disabled:opacity-50 cursor-pointer">{savingConfig ? 'Saving...' : 'Save Withdrawal Policy'}</button>
            </form>
            <div className="border border-green-300/20 bg-green-400/[0.04] p-6 flex items-center justify-between gap-4">
              <div><h2 className="font-display font-bold tracking-widest uppercase text-green-200">Launch Day</h2><p className="text-xs text-white/40 mt-2 max-w-md">Open manually to allow universal withdrawals and automatically notify every approved investor. Close it when the opportunity ends.</p></div>
              <button onClick={handleToggleLaunchDay} disabled={savingConfig} className={`px-4 py-3 text-xs font-display font-bold tracking-widest uppercase cursor-pointer disabled:opacity-50 ${launchDayEnabled ? 'bg-green-300 text-black' : 'border border-white/20 text-white/60'}`}>{launchDayEnabled ? 'Launch Day Open' : 'Open Launch Day'}</button>
            </div>
            <form onSubmit={handleSaveBtcSettings} className="border border-cyan-300/20 bg-cyan-400/[0.04] p-6 space-y-5">
              <div><h2 className="font-display font-bold tracking-widest uppercase text-cyan-200">BTC Prediction Controls</h2><p className="text-xs text-white/40 mt-2">These safeguards apply server-side to every real-cash prediction. Existing rounds keep their payout snapshot.</p></div>
              <div className="grid sm:grid-cols-2 gap-4">
                <label className="text-xs text-white/50">Payout multiplier<input type="number" min="1.01" max="10" step="0.01" value={btcPayoutMultiplier} onChange={(e) => setBtcPayoutMultiplier(e.target.value)} className="mt-2 w-full bg-black/50 border border-white/20 px-4 py-3 text-white" /></label>
                <label className="text-xs text-white/50">Contract duration (minutes)<input type="number" min="1" max="1440" step="1" value={btcContractMinutes} onChange={(e) => setBtcContractMinutes(e.target.value)} className="mt-2 w-full bg-black/50 border border-white/20 px-4 py-3 text-white" /></label>
                <label className="text-xs text-white/50">Maximum stake per prediction ($)<input type="number" min="1" step="1" value={btcMaxStake} onChange={(e) => setBtcMaxStake(e.target.value)} className="mt-2 w-full bg-black/50 border border-white/20 px-4 py-3 text-white" /></label>
                <label className="text-xs text-white/50">Daily investor limit ($)<input type="number" min="1" step="1" value={btcDailyLimit} onChange={(e) => setBtcDailyLimit(e.target.value)} className="mt-2 w-full bg-black/50 border border-white/20 px-4 py-3 text-white" /></label>
                <label className="text-xs text-white/50">Minimum shares to sell<input type="number" min="0" step="0.0001" value={sellMinimumShares} onChange={(e) => setSellMinimumShares(e.target.value)} className="mt-2 w-full bg-black/50 border border-white/20 px-4 py-3 text-white" /></label>
                <label className="text-xs text-white/50">Instant-buy trigger (shares)<input type="number" min="0.0001" step="0.0001" value={instantBuyShares} onChange={(e) => setInstantBuyShares(e.target.value)} className="mt-2 w-full bg-black/50 border border-white/20 px-4 py-3 text-white" /></label>
                <label className="text-xs text-white/50">Temporary selling window (minutes)<input type="number" min="1" max="1440" step="1" value={sellAccessDurationMinutes} onChange={(e) => setSellAccessDurationMinutes(e.target.value)} className="mt-2 w-full bg-black/50 border border-white/20 px-4 py-3 text-white" /></label>
              </div>
              <label className="block text-xs text-white/50">Investor eligibility message<textarea value={sellingEligibilityMessage} onChange={(e) => setSellingEligibilityMessage(e.target.value)} maxLength={1000} rows={3} className="mt-2 w-full resize-y bg-black/50 border border-white/20 px-4 py-3 text-white normal-case" /></label>
              <button type="submit" disabled={savingConfig} className="w-full bg-cyan-300 text-black font-display font-bold tracking-widest uppercase py-3 disabled:opacity-50 cursor-pointer">{savingConfig ? 'Saving...' : 'Save BTC Controls'}</button>
            </form>
          </div>
        )}

        {!loading && tab === 'BTC Audit' && (
          <div className="space-y-4">
            <div><h2 className="font-display font-bold tracking-widest uppercase">BTC Prediction & Payout Audit</h2><p className="text-sm text-white/45 mt-2">Every stake, payout, settlement price, multiplier snapshot, and investor is recorded here.</p></div>
            <div className="overflow-x-auto border border-white/10"><table className="w-full text-left text-xs"><thead className="bg-white/5 text-white/45 uppercase tracking-wider"><tr><th className="p-3">Investor</th><th className="p-3">Contract</th><th className="p-3">Prediction</th><th className="p-3">Stake</th><th className="p-3">Multiplier</th><th className="p-3">Payout</th><th className="p-3">Status</th><th className="p-3">Placed</th></tr></thead><tbody>{predictionAudit.map((row) => <tr key={row.id} className="border-t border-white/10"><td className="p-3"><div>{row.fullName ?? '—'}</div><div className="text-white/35">{row.email}</div></td><td className="p-3 font-mono">#{row.contractId}<div className="text-white/35">${row.startPrice.toFixed(2)} → {row.endPrice == null ? '—' : `$${row.endPrice.toFixed(2)}`}</div></td><td className={`p-3 font-bold ${row.direction === 'up' ? 'text-green-300' : 'text-red-300'}`}>{row.direction.toUpperCase()}</td><td className="p-3">${row.amount.toFixed(2)}</td><td className="p-3">{row.payoutMultiplier.toFixed(2)}×</td><td className="p-3">${row.payout.toFixed(2)}</td><td className="p-3 uppercase">{row.betStatus}</td><td className="p-3 text-white/45">{new Date(row.createdAt).toLocaleString()}</td></tr>)}{predictionAudit.length === 0 && <tr><td colSpan={8} className="p-8 text-center text-white/35">No BTC prediction activity yet.</td></tr>}</tbody></table></div>
          </div>
        )}

        {!loading && tab === 'Sell Access Audit' && (
          <div className="space-y-4">
            <div><h2 className="font-display font-bold tracking-widest uppercase">Sell Access Audit</h2><p className="text-sm text-white/45 mt-2">Every administrator change and automatic instant-buy unlock is recorded with its previous and new expiry.</p></div>
            <div className="overflow-x-auto border border-white/10"><table className="w-full text-left text-xs"><thead className="bg-white/5 text-white/45 uppercase tracking-wider"><tr><th className="p-3">Investor</th><th className="p-3">Action</th><th className="p-3">Source</th><th className="p-3">Previous expiry</th><th className="p-3">New expiry</th><th className="p-3">Recorded</th></tr></thead><tbody>{sellAccessAudit.map((row) => <tr key={row.id} className="border-t border-white/10"><td className="p-3"><div>{row.fullName ?? `Investor #${row.investorId}`}</div><div className="text-white/35">{row.email ?? '—'}</div></td><td className={`p-3 font-bold uppercase ${row.action === 'closed' ? 'text-red-300' : row.action === 'automatic_unlock' ? 'text-cyan-300' : 'text-green-300'}`}>{row.action.replace('_', ' ')}</td><td className="p-3 text-white/55">{row.source}</td><td className="p-3 text-white/45">{row.previousExpiresAt ? new Date(row.previousExpiresAt).toLocaleString() : '—'}</td><td className="p-3 text-white/45">{row.newExpiresAt ? new Date(row.newExpiresAt).toLocaleString() : 'Closed'}</td><td className="p-3 text-white/45">{new Date(row.createdAt).toLocaleString()}</td></tr>)}{sellAccessAudit.length === 0 && <tr><td colSpan={6} className="p-8 text-center text-white/35">No sell-access changes recorded yet.</td></tr>}</tbody></table></div>
          </div>
        )}

        {!loading && tab === 'Deposit Addresses' && (
          <div className="space-y-5 max-w-lg">
            {['BTC', 'ETH', 'DOGE'].map(coin => (
              <div key={coin} className="border border-white/10 p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Wallet className="w-4 h-4 text-white/50" />
                  <span className="font-display font-bold tracking-widest">{coin}</span>
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={addressEdits[coin] ?? ''}
                    onChange={(e) => setAddressEdits({ ...addressEdits, [coin]: e.target.value })}
                    className="flex-1 bg-black/50 border border-white/30 text-white px-4 py-3 focus:outline-none focus:border-white/80 text-sm"
                  />
                  <button onClick={() => handleAddressSave(coin)} className="px-4 py-2 border border-white/30 font-display text-xs tracking-widest uppercase hover:bg-white/5 transition-colors cursor-pointer">
                    Save
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
