export type InvestorSession = {
  email: string;
  fullName?: string | null;
  token?: string | null;
  avatarUrl?: string | null;
};

const SESSION_KEY = "spcx_user";

function stores(): Storage[] {
  if (typeof window === "undefined") return [];
  const result: Storage[] = [];
  try {
    result.push(window.localStorage);
  } catch {}
  try {
    result.push(window.sessionStorage);
  } catch {}
  return result;
}

export function getInvestorSession(): InvestorSession | null {
  for (const storage of stores()) {
    try {
      const raw = storage.getItem(SESSION_KEY);
      if (!raw) continue;
      const parsed = JSON.parse(raw) as Partial<InvestorSession>;
      if (typeof parsed.email !== "string" || !parsed.email.trim()) continue;
      return {
        email: parsed.email.trim().toLowerCase(),
        fullName: typeof parsed.fullName === "string" ? parsed.fullName : null,
        token: typeof parsed.token === "string" ? parsed.token : null,
        avatarUrl: typeof parsed.avatarUrl === "string" ? parsed.avatarUrl : null,
      };
    } catch {
      try {
        storage.removeItem(SESSION_KEY);
      } catch {}
    }
  }
  return null;
}

export function setInvestorSession(session: InvestorSession): void {
  const value = JSON.stringify({
    email: session.email.trim().toLowerCase(),
    fullName: session.fullName ?? null,
    token: session.token ?? null,
    avatarUrl: session.avatarUrl ?? null,
  });
  for (const storage of stores()) {
    try {
      storage.setItem(SESSION_KEY, value);
    } catch {}
  }
}

export function clearInvestorSession(): void {
  for (const storage of stores()) {
    try {
      storage.removeItem(SESSION_KEY);
    } catch {}
  }
}
