CREATE TABLE `realtime_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`resource` varchar(80) NOT NULL,
	`action` varchar(120) NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `realtime_events_id` PRIMARY KEY(`id`)
);
