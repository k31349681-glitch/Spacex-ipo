import { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Activity, TrendingUp } from 'lucide-react';
import { getGetSiteConfigQueryKey, useGetSiteConfig } from '@/api-client-react';

type SortMode = 'time' | 'amount';

type ActivityItem = {
  name: string;
  shares: number;
  amount: number;
  minutesAgo: number;
};

const recentActivity: ActivityItem[] = [
  { name: 'Amelia R.', shares: 18.42, amount: 2726, minutesAgo: 2 },
  { name: 'Noah K.', shares: 7.85, amount: 1162, minutesAgo: 5 },
  { name: 'Olivia M.', shares: 31.6, amount: 4671, minutesAgo: 8 },
  { name: 'Ethan J.', shares: 4.2, amount: 621, minutesAgo: 12 },
  { name: 'Maya T.', shares: 12.75, amount: 1884, minutesAgo: 16 },
  { name: 'Lucas B.', shares: 46.1, amount: 6806, minutesAgo: 21 },
  { name: 'Sophia C.', shares: 9.9, amount: 1463, minutesAgo: 27 },
  { name: 'Liam D.', shares: 22.08, amount: 3260, minutesAgo: 34 },
];

export default function LiveActivityTicker() {
  const { data } = useGetSiteConfig({ query: { refetchInterval: 30000, queryKey: getGetSiteConfigQueryKey() } });
  const activityTickerEnabled = (data as typeof data & { activityTickerEnabled?: boolean } | undefined)?.activityTickerEnabled ?? true;
  const [sortMode, setSortMode] = useState<SortMode>('time');
  const [index, setIndex] = useState(0);

  const sortedActivity = useMemo(() => [...recentActivity].sort((a, b) => sortMode === 'amount' ? b.amount - a.amount : a.minutesAgo - b.minutesAgo), [sortMode]);

  useEffect(() => {
    setIndex(0);
  }, [sortMode]);

  useEffect(() => {
    if (!activityTickerEnabled) return;
    const timeout = window.setTimeout(() => setIndex((current) => (current + 1) % sortedActivity.length), 3200);
    return () => window.clearTimeout(timeout);
  }, [index, activityTickerEnabled, sortedActivity.length]);

  if (!activityTickerEnabled) return null;
  const item = sortedActivity[index];

  return (
    <div className="min-h-11 border-b border-cyan-400/10 bg-cyan-400/[0.035] px-4 py-1.5" aria-label="Market activity">
      <div className="max-w-5xl mx-auto flex flex-wrap items-center gap-3">
        <span className="flex items-center gap-1.5 text-[9px] sm:text-[10px] font-display font-bold tracking-[0.18em] uppercase text-cyan-300 shrink-0">
          <Activity className="w-3.5 h-3.5" /> Activity
        </span>
        <div className="flex items-center gap-1 rounded border border-white/10 p-0.5 shrink-0" aria-label="Sort recent trades">
          {(['time', 'amount'] as SortMode[]).map((mode) => (
            <button key={mode} type="button" onClick={() => setSortMode(mode)} aria-pressed={sortMode === mode} className={`px-2 py-1 text-[9px] font-display tracking-widest uppercase transition-colors cursor-pointer ${sortMode === mode ? 'bg-cyan-300 text-[#061014]' : 'text-white/45 hover:text-white'}`}>
              {mode === 'time' ? 'Recent' : 'Amount'}
            </button>
          ))}
        </div>
        <div className="relative h-7 flex-1 min-w-[220px] overflow-hidden">
          <AnimatePresence mode="popLayout" initial={false}>
            <motion.div
              key={`${sortMode}-${index}`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.28, ease: [0.23, 1, 0.32, 1] }}
              className="absolute inset-0 flex items-center gap-2 text-xs font-display tracking-wider whitespace-nowrap"
            >
              <TrendingUp className="w-3.5 h-3.5 text-green-400" />
              <span className="font-bold">{item.name}</span>
              <span className="text-white/45">bought</span>
              <span className="text-green-400 font-bold">{item.shares.toFixed(2)} SPCX</span>
              <span className="text-white/35">· ${item.amount.toLocaleString()} · {item.minutesAgo}m ago</span>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
