import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { ArrowRight, Globe2, Rocket, ShieldCheck, User } from 'lucide-react';
import { Link } from 'wouter';
import * as AccordionPrimitive from '@radix-ui/react-accordion';
import heroPhoto from '@/assets/section-c_1785378506308.webp';
import logoImg from '@/assets/logo_1784056609292.png';

function FadeIn({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  return <motion.div ref={ref} initial={{ opacity: 0, y: 30 }} animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }} transition={{ duration: 0.7, delay, ease: [0.21, 0.47, 0.32, 0.98] }}>{children}</motion.div>;
}

const ipoCards = [
  { icon: Rocket, label: 'The opportunity', title: 'Participate before a potential public listing', copy: 'Follow the private-market SPCX indication, review your eligibility, and submit an access request from one focused investor portal.' },
  { icon: Globe2, label: 'The thesis', title: 'Infrastructure for an expanding space economy', copy: 'Explore an investment narrative tied to reusable launch systems, satellite connectivity, and long-duration space infrastructure.' },
  { icon: ShieldCheck, label: 'The process', title: 'Approval-gated investor access', copy: 'Registration, administrator review, portfolio access, deposits, and internal share orders are kept in a clear step-by-step flow.' },
];

const faqs = [
  { q: 'Is a SpaceX IPO date confirmed?', a: 'No date is represented as confirmed on this platform. Public-listing timing, structure, availability, and eligibility can change. Investors should rely on formal offering documents and qualified professional advice.' },
  { q: 'What is SPCX on this platform?', a: 'SPCX is the internal symbol used by this independent portal for its SpaceX pre-IPO market experience. It is not presented as an official public exchange ticker.' },
  { q: 'Who can request access?', a: 'Prospective investors may register for review. Approval does not guarantee that shares will be available, and eligibility can depend on jurisdiction and investor qualifications.' },
  { q: 'How does trading work?', a: 'Approved users can fund an internal balance and place buy orders against the live indicative SPCX price. Selling is available only when enabled by the administrator.' },
];

export default function Home() {
  return (
    <div className="min-h-[100dvh] bg-[#050a0f] text-white selection:bg-white/20">
      <header className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-5 bg-gradient-to-b from-black/85 to-transparent backdrop-blur-[2px]">
        <Link href="/" className="flex items-center"><img src={logoImg} alt="SPCX" className="h-8 sm:h-9 w-auto" /></Link>
        <div className="flex items-center gap-5">
          <Link href="/register" className="hidden sm:inline text-xs font-bold tracking-[0.18em] uppercase border border-white/25 px-4 py-2 hover:bg-white hover:text-black transition-colors">Request access</Link>
          <Link href="/signin" className="flex items-center gap-2 text-sm font-medium tracking-widest hover:text-white/70 transition-colors uppercase"><span className="hidden sm:inline">Sign In</span><User className="w-5 h-5" /></Link>
        </div>
      </header>

      <section className="relative h-[100dvh] min-h-[680px] w-full flex flex-col justify-end px-6 pb-14 sm:px-12 sm:pb-20 overflow-hidden">
        <div className="absolute inset-0"><img src={heroPhoto} alt="Rocket launch" className="w-full h-full object-cover object-center" /><div className="absolute inset-0 bg-gradient-to-t from-[#050a0f] via-[#050a0f]/55 to-black/10" /></div>
        <div className="relative z-10 max-w-6xl mx-auto w-full">
          <FadeIn><div className="inline-flex items-center gap-2 mb-5 text-[10px] sm:text-xs uppercase tracking-[0.22em] text-cyan-100/80"><span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" /> Private-market investor access</div><h1 className="font-display text-5xl sm:text-7xl md:text-8xl lg:text-[9rem] font-bold uppercase leading-[0.88] tracking-tight">The road<br />to an IPO</h1></FadeIn>
          <FadeIn delay={0.15}><p className="mt-6 max-w-2xl text-base sm:text-xl text-white/65 leading-relaxed">Track a live SPCX market indication, build an investor profile, and prepare for potential SpaceX pre-IPO opportunities from a single platform.</p></FadeIn>
          <FadeIn delay={0.3}><div className="flex flex-col sm:flex-row gap-3 mt-9"><Link href="/register" className="inline-flex items-center justify-center gap-3 bg-white text-black px-7 py-4 font-display font-bold tracking-widest uppercase hover:bg-cyan-100 transition-colors">Request investor access <ArrowRight className="w-4 h-4" /></Link><a href="#ipo-brief" className="inline-flex items-center justify-center border border-white/25 px-7 py-4 font-display font-bold tracking-widest uppercase hover:bg-white/5 transition-colors">Read the IPO brief</a></div></FadeIn>
        </div>
      </section>

      <section id="ipo-brief" className="relative overflow-hidden py-24 sm:py-32 px-6 sm:px-12 border-t border-white/[0.07]">
        <div className="absolute inset-0"><img src={heroPhoto} alt="Rocket launch over a cloudy horizon" className="h-full w-full object-cover object-center" /><div className="absolute inset-0 bg-[#050a0f]/70" /></div>
        <div className="relative z-10 max-w-6xl mx-auto">
          <FadeIn><div className="grid lg:grid-cols-[0.8fr_1.2fr] gap-10 lg:gap-20 items-end mb-16"><div><span className="text-cyan-300 text-xs font-bold tracking-[0.22em] uppercase">SpaceX IPO watch</span><h2 className="font-display text-4xl sm:text-6xl font-bold uppercase tracking-tight mt-4 leading-[0.95]">Prepare before the market opens</h2></div><p className="text-white/55 text-lg leading-relaxed">A potential SpaceX public offering would be a major market event. This portal gives approved users an internal pre-IPO trading experience while keeping the distinction between an indicative private-market price and any future official public listing clear.</p></div></FadeIn>
          <div className="grid md:grid-cols-3 gap-4">{ipoCards.map((card, index) => <FadeIn key={card.title} delay={index * 0.08}><article className="h-full min-h-72 border border-white/20 bg-black/25 backdrop-blur-sm p-7 flex flex-col"><card.icon className="w-7 h-7 text-cyan-300" /><div className="text-[10px] text-white/60 font-bold tracking-[0.2em] uppercase mt-8">{card.label}</div><h3 className="text-2xl font-bold mt-3 leading-tight">{card.title}</h3><p className="text-white/75 leading-relaxed mt-4">{card.copy}</p></article></FadeIn>)}</div>
        </div>
      </section>

      <section className="py-24 px-6 sm:px-12 bg-white text-black">
        <FadeIn><div className="max-w-5xl mx-auto grid md:grid-cols-[1fr_auto] gap-10 items-center"><div><span className="text-xs font-bold tracking-[0.2em] uppercase text-black/45">Investor access</span><h2 className="font-display text-4xl sm:text-6xl font-bold uppercase tracking-tight mt-3">Ready to enter the market?</h2><p className="mt-4 text-black/55 max-w-2xl text-lg">Registration now has its own secure, focused page. Create your profile, wait for review, then sign in after approval.</p></div><Link href="/register" className="inline-flex items-center justify-center gap-3 bg-black text-white px-8 py-5 font-display font-bold tracking-widest uppercase hover:bg-black/85 transition-colors">Open registration <ArrowRight className="w-4 h-4" /></Link></div></FadeIn>
      </section>

      <section className="relative min-h-[560px] overflow-hidden px-6 py-24 sm:px-12 sm:py-32">
        <div className="absolute inset-0 grid grid-cols-1 md:grid-cols-3">
          <img src="/manus-storage/tesla-night-road_ae21baca.jpg" alt="Tesla on a night road" className="h-full w-full object-cover" />
          <img src="/manus-storage/tesla-sunset-road_3ecd6160.jpg" alt="Tesla on a sunset road" className="hidden md:block h-full w-full object-cover" />
          <img src="/manus-storage/tesla-city-night_df80d720.jpg" alt="Tesla driving through a city at night" className="hidden md:block h-full w-full object-cover" />
        </div>
        <div className="absolute inset-0 bg-[#050a0f]/75 md:bg-[#050a0f]/65" />
        <div className="relative z-10 mx-auto flex min-h-[320px] max-w-5xl items-center justify-center text-center">
          <FadeIn><div><span className="text-cyan-200 text-xs font-bold tracking-[0.22em] uppercase">The next frontier</span><h2 className="font-display text-4xl sm:text-7xl font-bold uppercase tracking-tight mt-4">Built for motion</h2><p className="mx-auto mt-5 max-w-2xl text-lg leading-relaxed text-white/75">Explore a platform designed around movement, access, and the changing shape of the technology market.</p></div></FadeIn>
        </div>
      </section>

      <section className="py-24 sm:py-32 px-6 sm:px-12 border-t border-white/10">
        <div className="max-w-4xl mx-auto"><FadeIn><div className="mb-14"><span className="text-white/50 text-sm font-semibold tracking-[0.2em] uppercase mb-4 block">Investor FAQ</span><h2 className="font-display text-4xl sm:text-6xl font-bold uppercase tracking-widest">What to know</h2></div><AccordionPrimitive.Root type="single" collapsible>{faqs.map((faq, index) => <AccordionPrimitive.Item key={faq.q} value={`item-${index}`} className="border-b border-white/10"><AccordionPrimitive.Header className="flex"><AccordionPrimitive.Trigger className="flex flex-1 items-center justify-between gap-5 py-7 font-display text-xl sm:text-2xl tracking-wider text-left hover:text-white/75 [&[data-state=open]>svg]:rotate-180 uppercase cursor-pointer">{faq.q}<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="shrink-0 transition-transform text-white/40"><path d="m6 9 6 6 6-6" /></svg></AccordionPrimitive.Trigger></AccordionPrimitive.Header><AccordionPrimitive.Content className="overflow-hidden text-white/55 text-base sm:text-lg leading-relaxed data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down"><div className="pb-7 max-w-3xl">{faq.a}</div></AccordionPrimitive.Content></AccordionPrimitive.Item>)}</AccordionPrimitive.Root></FadeIn></div>
      </section>

      <footer className="py-12 px-6 sm:px-12 border-t border-white/10 flex flex-col sm:flex-row justify-between items-center gap-5 text-xs text-white/35 tracking-[0.15em] uppercase font-display"><p>© 2026 SPCX. All rights reserved.</p><p>Investor access · Market intelligence · Portfolio tools</p></footer>
    </div>
  );
}
