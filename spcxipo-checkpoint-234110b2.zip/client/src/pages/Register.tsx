import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { motion } from 'framer-motion';
import { ArrowLeft, UserPlus, Eye, EyeOff } from 'lucide-react';
import { toast } from 'sonner';
import { useCreateInvestor } from '@/api-client-react';
import logoImg from '@/assets/logo_1784056609292.png';

export default function Register() {
  const [, setLocation] = useLocation();
  const createInvestor = useCreateInvestor();
  const [form, setForm] = useState({ fullName: '', phone: '', email: '', password: '', confirmPassword: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const update = (key: keyof typeof form) => (event: React.ChangeEvent<HTMLInputElement>) =>
    setForm((current) => ({ ...current, [key]: event.target.value }));

  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (form.password !== form.confirmPassword) {
      toast.error('Passwords do not match.');
      return;
    }
    createInvestor.mutate({ data: { fullName: form.fullName, phone: form.phone, email: form.email, password: form.password } }, {
      onSuccess: (investor) => setLocation(`/access-pending?email=${encodeURIComponent(investor.email)}`),
      onError: (error: any) => toast.error(error?.data?.error || error?.message || 'Registration failed. Please try again.'),
    });
  };

  return (
    <div className="min-h-[100dvh] bg-[#050a0f] text-white flex flex-col">
      <header className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-5 bg-gradient-to-b from-black/80 to-transparent">
        <Link href="/" className="flex items-center"><img src={logoImg} alt="SPCX" className="h-8 sm:h-9 w-auto" /></Link>
        <Link href="/signin" className="flex items-center gap-2 text-sm tracking-widest text-white/70 uppercase"><span className="hidden sm:inline">Sign In</span><UserPlus className="w-5 h-5" /></Link>
      </header>
      <main className="flex-1 flex items-center justify-center px-6 pt-24 pb-12">
        <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
          <h1 className="font-display text-4xl sm:text-5xl font-bold tracking-widest uppercase mb-3">Request Access</h1>
          <p className="text-white/60 mb-8">Create your investor account. Access is reviewed by our team before approval.</p>
          <form onSubmit={submit} className="space-y-4">
            {([['fullName', 'Full name', 'text'], ['phone', 'Phone number', 'tel'], ['email', 'Email address', 'email'], ['password', 'Password (8+ characters)', 'password'], ['confirmPassword', 'Confirm password', 'password']] as const).map(([key, label, type]) => (
              <label key={key} className="block">
                <span className="block text-xs uppercase tracking-widest text-white/50 mb-2">{label}</span>
                <div className="relative">
                  <input required type={key === 'password' ? (showPassword ? 'text' : 'password') : key === 'confirmPassword' ? (showConfirmPassword ? 'text' : 'password') : type} minLength={key.includes('password') ? 8 : undefined} value={form[key]} onChange={update(key)} className="w-full rounded-none border border-white/20 bg-white/5 px-4 py-4 pr-12 text-white normal-case outline-none focus:border-white/70" />
                  {key.includes('password') && <button type="button" onClick={() => key === 'password' ? setShowPassword((visible) => !visible) : setShowConfirmPassword((visible) => !visible)} aria-label={(key === 'password' ? showPassword : showConfirmPassword) ? 'Hide password' : 'Show password'} className="absolute right-4 top-1/2 -translate-y-1/2 text-white/50 hover:text-white cursor-pointer">
                    {(key === 'password' ? showPassword : showConfirmPassword) ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>}
                </div>
              </label>
            ))}
            <button disabled={createInvestor.isPending} className="w-full bg-white text-black font-display font-bold text-lg tracking-[0.18em] uppercase py-5 hover:bg-white/90 disabled:opacity-50">
              {createInvestor.isPending ? 'Submitting...' : 'Request investor access'}
            </button>
          </form>
          <Link href="/signin" className="mt-6 mx-auto flex w-fit items-center gap-2 text-white/50 hover:text-white uppercase tracking-widest text-sm"><ArrowLeft className="w-4 h-4" /> Back to sign in</Link>
        </motion.div>
      </main>
    </div>
  );
}
