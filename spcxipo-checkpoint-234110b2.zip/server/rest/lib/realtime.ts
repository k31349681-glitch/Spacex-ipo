import { EventEmitter } from "node:events";
import { gt } from "drizzle-orm";
import { db, realtimeEventsTable } from "../../db";

export type RealtimeEvent = {
  type: "refresh";
  resource: string;
  action: string;
  at: string;
  id?: number;
};

export const realtimeEvents = new EventEmitter();
realtimeEvents.setMaxListeners(0);

export function publishRealtimeEvent(resource: string, action: string) {
  const event: RealtimeEvent = { type: "refresh", resource, action, at: new Date().toISOString() };
  realtimeEvents.emit("event", event);
  void db?.insert(realtimeEventsTable).values({ resource, action }).catch(() => undefined);
}

export async function getRealtimeEventsAfter(id: number) {
  if (!db) return [];
  return db.select().from(realtimeEventsTable).where(gt(realtimeEventsTable.id, id)).orderBy(realtimeEventsTable.id).limit(100);
}
