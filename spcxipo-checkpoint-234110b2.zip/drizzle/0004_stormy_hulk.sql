ALTER TABLE `investors` ADD `email_notifications` boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE `investors` ADD `trade_notifications` boolean DEFAULT true NOT NULL;