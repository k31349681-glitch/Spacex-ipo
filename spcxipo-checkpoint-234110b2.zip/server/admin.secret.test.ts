import express from "express";
import { createServer } from "node:http";
import { afterEach, describe, expect, it } from "vitest";
import adminRouter from "./rest/routes/admin";

const servers: ReturnType<typeof createServer>[] = [];

afterEach(async () => {
  await Promise.all(
    servers.splice(0).map(
      (server) =>
        new Promise<void>((resolve) => {
          server.close(() => resolve());
        }),
    ),
  );
});

describe("configured admin secret", () => {
  it("authenticates against the protected admin API route", async () => {
    const password = process.env.ADMIN_PASSWORD_URLENCODED
      ? decodeURIComponent(process.env.ADMIN_PASSWORD_URLENCODED)
      : process.env.ADMIN_PASSWORD;
    expect(password, "ADMIN_PASSWORD must be configured").toBeTruthy();

    const app = express();
    app.use(express.json());
    app.use("/api", adminRouter);
    const server = createServer(app);
    servers.push(server);

    await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", () => resolve()));
    const address = server.address();
    if (!address || typeof address === "string") throw new Error("Test server did not bind");

    const response = await fetch(`http://127.0.0.1:${address.port}/api/admin/investors`, {
      headers: { "x-admin-password": password! },
    });

    expect(response.status).toBe(200);
    expect(await response.json()).toBeInstanceOf(Array);
  }, 15_000);
});
