// @ts-nocheck
import { Router } from "express";
import { and, desc, eq, gte, lt } from "drizzle-orm";
import {
  db,
  btcPredictionBetsTable,
  btcPredictionContractsTable,
  holdingsTable,
  investorsTable,
  notificationsTable,
  siteConfigTable,
} from "../../db";
import { publishRealtimeEvent } from "../lib/realtime";
import { getInvestorSessionFromAuthorization } from "../lib/investorSession";

const router = Router();
const DEFAULT_BTC_SETTINGS = { payoutMultiplier: 1.9, contractMinutes: 5, maxStake: 100, dailyLimit: 500 };

async function getBtcSettings() {
  const [config] = await db.select().from(siteConfigTable).where(eq(siteConfigTable.id, 1)).limit(1);
  return {
    payoutMultiplier: Number(config?.btcPayoutMultiplier ?? DEFAULT_BTC_SETTINGS.payoutMultiplier),
    contractMinutes: Number(config?.btcContractMinutes ?? DEFAULT_BTC_SETTINGS.contractMinutes),
    maxStake: Number(config?.btcMaxStake ?? DEFAULT_BTC_SETTINGS.maxStake),
    dailyLimit: Number(config?.btcDailyLimit ?? DEFAULT_BTC_SETTINGS.dailyLimit),
  };
}

async function getBtcUsdPrice() {
  const response = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd", {
    headers: { "user-agent": "SPCX-BTC-Predictions/1.0" },
    signal: AbortSignal.timeout(10_000),
  });
  if (!response.ok) throw new Error(`CoinGecko returned ${response.status}`);
  const body = await response.json();
  const price = Number(body?.bitcoin?.usd);
  if (!Number.isFinite(price) || price <= 0) throw new Error("CoinGecko returned an invalid BTC/USD price");
  return price;
}

async function settleExpiredBtcContracts() {
  const now = new Date();
  const expired = await db.select().from(btcPredictionContractsTable).where(and(
    eq(btcPredictionContractsTable.status, "open"),
    lt(btcPredictionContractsTable.settlesAt, now),
  ));
  if (!expired.length) return 0;
  const endPrice = await getBtcUsdPrice();
  let settledBets = 0;
  for (const contract of expired) {
    const direction = endPrice > Number(contract.startPrice) ? "up" : endPrice < Number(contract.startPrice) ? "down" : "tie";
    await db.transaction(async (tx) => {
      await tx.update(btcPredictionContractsTable).set({ endPrice, status: "settled" }).where(eq(btcPredictionContractsTable.id, contract.id));
      const bets = await tx.select().from(btcPredictionBetsTable).where(eq(btcPredictionBetsTable.contractId, contract.id));
      for (const bet of bets) {
        const isTie = direction === "tie";
        const won = !isTie && bet.direction === direction;
        const payout = isTie ? Number(bet.amount) : won ? Number(bet.amount) * Number(contract.payoutMultiplier) : 0;
        await tx.update(btcPredictionBetsTable).set({ status: isTie ? "refunded" : won ? "won" : "lost", payout: payout.toFixed(2), settledAt: now }).where(eq(btcPredictionBetsTable.id, bet.id));
        if (payout > 0) {
          const [holding] = await tx.select().from(holdingsTable).where(eq(holdingsTable.investorId, bet.investorId)).limit(1);
          if (holding) {
            await tx.update(holdingsTable).set({ cashBalance: (Number(holding.cashBalance) + payout).toFixed(2) }).where(eq(holdingsTable.investorId, bet.investorId));
          }
          await tx.insert(notificationsTable).values({
            investorId: bet.investorId,
            message: isTie ? `BTC prediction refunded: your $${Number(bet.amount).toFixed(2)} ${bet.direction.toUpperCase()} stake was returned.` : won ? `BTC prediction won: $${payout.toFixed(2)} payout credited for your ${bet.direction.toUpperCase()} prediction.` : `BTC prediction settled: your ${bet.direction.toUpperCase()} prediction did not win.`,
          });
        }
        settledBets += 1;
      }
    });
  }
  if (settledBets > 0) publishRealtimeEvent("predictions", "btc-contracts-settled");
  return settledBets;
}

async function getOrCreateCurrentContract() {
  await settleExpiredBtcContracts();
  const settings = await getBtcSettings();
  const now = new Date();
  const [current] = await db.select().from(btcPredictionContractsTable).where(and(
    eq(btcPredictionContractsTable.status, "open"),
    lt(now, btcPredictionContractsTable.settlesAt),
  )).orderBy(desc(btcPredictionContractsTable.settlesAt)).limit(1);
  if (current) return current;
  const startPrice = await getBtcUsdPrice();
  const startsAt = new Date();
  const settlesAt = new Date(startsAt.getTime() + settings.contractMinutes * 60_000);
  const result = await db.insert(btcPredictionContractsTable).values({ startsAt, settlesAt, startPrice: startPrice.toFixed(2), payoutMultiplier: settings.payoutMultiplier.toFixed(2), status: "open" });
  const [created] = await db.select().from(btcPredictionContractsTable).where(eq(btcPredictionContractsTable.id, result[0].insertId)).limit(1);
  return created;
}

function contractView(contract: any, currentPrice: number) {
  return {
    id: contract.id,
    startsAt: contract.startsAt.toISOString(),
    settlesAt: contract.settlesAt.toISOString(),
    startPrice: Number(contract.startPrice),
    currentPrice,
    secondsRemaining: Math.max(0, Math.ceil((contract.settlesAt.getTime() - Date.now()) / 1000)),
    payoutMultiplier: Number(contract.payoutMultiplier),
    maxStake: contract.maxStake,
    dailyLimit: contract.dailyLimit,
    source: "CoinGecko BTC/USD",
  };
}

router.get("/predictions/btc/current", async (_req, res) => {
  try {
    const [contract, currentPrice, settings] = await Promise.all([getOrCreateCurrentContract(), getBtcUsdPrice(), getBtcSettings()]);
    res.json({ ...contractView(contract, currentPrice), maxStake: settings.maxStake, dailyLimit: settings.dailyLimit });
  } catch (err) {
    res.status(503).json({ error: "BTC price is temporarily unavailable. Try again shortly." });
  }
});

router.get("/predictions/btc/history", async (req, res) => {
  const session = getInvestorSessionFromAuthorization(req.headers.authorization);
  if (!session) return res.status(401).json({ error: "Sign in is required." });
  const email = session.email;
  try {
    await settleExpiredBtcContracts();
    const [investor] = await db.select().from(investorsTable).where(eq(investorsTable.email, email)).limit(1);
    if (!investor) return res.json([]);
    const bets = await db.select().from(btcPredictionBetsTable).where(eq(btcPredictionBetsTable.investorId, investor.id)).orderBy(desc(btcPredictionBetsTable.createdAt)).limit(20);
    res.json(bets.map((bet) => ({ ...bet, amount: Number(bet.amount), payout: Number(bet.payout), createdAt: bet.createdAt.toISOString(), settledAt: bet.settledAt?.toISOString() ?? null })));
  } catch (err) {
    res.status(500).json({ error: "Unable to load BTC prediction history." });
  }
});

router.post("/predictions/btc/bet", async (req, res) => {
  const session = getInvestorSessionFromAuthorization(req.headers.authorization);
  if (!session) return res.status(401).json({ error: "Sign in is required." });
  const email = session.email;
  const direction = req.body?.direction;
  const amount = Number(req.body?.amount);
  const confirmed = req.body?.confirmed === true;
  if (!email || !["up", "down"].includes(direction) || !Number.isFinite(amount) || amount < 1 || amount > 10_000) {
    return res.status(400).json({ error: "Choose Up or Down and enter a stake between $1 and $10,000." });
  }
  try {
    if (!confirmed) return res.status(400).json({ error: "Explicit real-cash confirmation is required." });
    const settings = await getBtcSettings();
    if (amount > settings.maxStake) return res.status(400).json({ error: `The maximum stake per prediction is $${settings.maxStake.toFixed(2)}.` });
    const dayStart = new Date();
    dayStart.setUTCHours(0, 0, 0, 0);
    const todayBets = await db.select({ amount: btcPredictionBetsTable.amount }).from(btcPredictionBetsTable).where(and(eq(btcPredictionBetsTable.investorId, (await db.select({ id: investorsTable.id }).from(investorsTable).where(eq(investorsTable.email, email)).limit(1))[0]?.id ?? -1), gte(btcPredictionBetsTable.createdAt, dayStart)));
    const dailyTotal = todayBets.reduce((total, bet) => total + Number(bet.amount), 0);
    if (dailyTotal + amount > settings.dailyLimit) return res.status(400).json({ error: `Your daily BTC prediction limit is $${settings.dailyLimit.toFixed(2)}. You have $${Math.max(0, settings.dailyLimit - dailyTotal).toFixed(2)} remaining today.` });
    const contract = await getOrCreateCurrentContract();
    if (contract.settlesAt <= new Date()) return res.status(409).json({ error: "This contract is closing. Refresh and try the next round." });
    const [investor] = await db.select().from(investorsTable).where(eq(investorsTable.email, email)).limit(1);
    if (!investor || investor.status !== "approved") return res.status(403).json({ error: "Your investor account must be approved before trading." });
    let bet;
    await db.transaction(async (tx) => {
      const [holding] = await tx.select().from(holdingsTable).where(eq(holdingsTable.investorId, investor.id)).limit(1);
      if (!holding || Number(holding.cashBalance) < amount) throw new Error("INSUFFICIENT_CASH");
      await tx.update(holdingsTable).set({ cashBalance: (Number(holding.cashBalance) - amount).toFixed(2) }).where(eq(holdingsTable.investorId, investor.id));
      const result = await tx.insert(btcPredictionBetsTable).values({ investorId: investor.id, contractId: contract.id, direction, amount: amount.toFixed(2), payout: "0", status: "pending" });
      [bet] = await tx.select().from(btcPredictionBetsTable).where(eq(btcPredictionBetsTable.id, result[0].insertId)).limit(1);
      await tx.insert(notificationsTable).values({ investorId: investor.id, message: `BTC prediction placed: $${amount.toFixed(2)} on ${direction.toUpperCase()} for the five-minute round.` });
    });
    publishRealtimeEvent("holdings", "btc-prediction-stake-placed");
    res.json({ ok: true, bet: { ...bet, amount: Number(bet.amount), payout: Number(bet.payout) }, contract: { ...contractView(contract, await getBtcUsdPrice()), maxStake: settings.maxStake, dailyLimit: settings.dailyLimit } });
  } catch (err) {
    if (err?.message === "INSUFFICIENT_CASH") return res.status(400).json({ error: "Insufficient cash balance. Deposit funds first." });
    res.status(500).json({ error: "Unable to place BTC prediction." });
  }
});

router.post("/scheduled/settle-btc-predictions", async (_req, res) => {
  try {
    const settledBets = await settleExpiredBtcContracts();
    res.json({ ok: true, settledBets });
  } catch (err) {
    res.status(503).json({ ok: false, error: "BTC settlement temporarily unavailable." });
  }
});

export { settleExpiredBtcContracts };
export default router;
