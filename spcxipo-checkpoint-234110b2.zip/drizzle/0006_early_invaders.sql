CREATE TABLE `monthly_reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`report_month` varchar(7) NOT NULL,
	`period_start` timestamp NOT NULL,
	`period_end` timestamp NOT NULL,
	`total_maintenance_fees` decimal(18,2) NOT NULL DEFAULT '0',
	`completed_maintenance_fees` decimal(18,2) NOT NULL DEFAULT '0',
	`pending_maintenance_fees` decimal(18,2) NOT NULL DEFAULT '0',
	`failed_maintenance_fees` decimal(18,2) NOT NULL DEFAULT '0',
	`total_deposits` decimal(18,2) NOT NULL DEFAULT '0',
	`total_withdrawals` decimal(18,2) NOT NULL DEFAULT '0',
	`transaction_count` int NOT NULL DEFAULT 0,
	`details` json,
	`generated_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `monthly_reports_id` PRIMARY KEY(`id`),
	CONSTRAINT `monthly_reports_report_month_unique` UNIQUE(`report_month`)
);
