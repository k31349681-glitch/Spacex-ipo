import { describe, expect, it } from "vitest";
import { calculateLivePrice } from "./rest/lib/stock";
import { createInvestorSessionToken, verifyInvestorSessionToken } from "./rest/lib/investorSession";

describe("live market and investor profile security", () => {
  it("produces deterministic but moving market prices", () => {
    const base = 147.62;
    const first = calculateLivePrice(base, 1_800_000_000_000);
    const same = calculateLivePrice(base, 1_800_000_000_000);
    const later = calculateLivePrice(base, 1_800_000_007_000);
    expect(first).toBe(same);
    expect(later).not.toBe(first);
    expect(Math.abs(later - base)).toBeLessThan(base * 0.01);
  });

  it("signs, validates, and rejects tampered investor sessions", () => {
    expect(process.env.JWT_SECRET).toBeTruthy();
    const token = createInvestorSessionToken("Investor@Example.com");
    expect(verifyInvestorSessionToken(token)?.email).toBe("investor@example.com");
    expect(verifyInvestorSessionToken(`${token}tampered`)).toBeNull();
  });
});
