CREATE TABLE `sell_access_audit` (
	`id` int AUTO_INCREMENT NOT NULL,
	`investor_id` int NOT NULL,
	`action` enum('opened','closed','automatic_unlock') NOT NULL,
	`previous_expires_at` timestamp,
	`new_expires_at` timestamp,
	`source` varchar(40) NOT NULL DEFAULT 'admin',
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `sell_access_audit_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `sell_access_audit` ADD CONSTRAINT `sell_access_audit_investor_id_investors_id_fk` FOREIGN KEY (`investor_id`) REFERENCES `investors`(`id`) ON DELETE cascade ON UPDATE no action;