import { createHmac, timingSafeEqual } from "node:crypto";
import { ENV } from "../../_core/env";

const SESSION_DURATION_MS = 7 * 24 * 60 * 60 * 1000;

type InvestorSessionPayload = {
  email: string;
  expiresAt: number;
};

function signature(payload: string): string {
  if (!ENV.cookieSecret) throw new Error("JWT_SECRET is required for investor sessions");
  return createHmac("sha256", ENV.cookieSecret).update(payload).digest("base64url");
}

export function createInvestorSessionToken(email: string): string {
  const payload = Buffer.from(JSON.stringify({
    email: email.toLowerCase().trim(),
    expiresAt: Date.now() + SESSION_DURATION_MS,
  } satisfies InvestorSessionPayload)).toString("base64url");
  return `${payload}.${signature(payload)}`;
}

export function verifyInvestorSessionToken(token: string): InvestorSessionPayload | null {
  const [payload, providedSignature] = token.split(".");
  if (!payload || !providedSignature) return null;

  try {
    const expectedSignature = signature(payload);
    const expected = Buffer.from(expectedSignature);
    const provided = Buffer.from(providedSignature);
    if (expected.length !== provided.length || !timingSafeEqual(expected, provided)) return null;

    const parsed = JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as InvestorSessionPayload;
    if (typeof parsed.email !== "string" || !parsed.email || typeof parsed.expiresAt !== "number") return null;
    if (parsed.expiresAt <= Date.now()) return null;
    return { email: parsed.email.toLowerCase().trim(), expiresAt: parsed.expiresAt };
  } catch {
    return null;
  }
}

export function getInvestorSessionFromAuthorization(header: string | undefined): InvestorSessionPayload | null {
  if (!header?.startsWith("Bearer ")) return null;
  return verifyInvestorSessionToken(header.slice(7).trim());
}
