import { clearInvestorSession, getInvestorSession } from "@/lib/session";
import { useCallback, useEffect, useMemo, useState } from "react";

type UseAuthOptions = {
  redirectOnUnauthenticated?: boolean;
  redirectPath?: string;
};

type LocalAuthUser = {
  email: string;
  name: string | null;
  role: "user";
};

function readUser(): LocalAuthUser | null {
  const session = getInvestorSession();
  if (!session) return null;
  return { email: session.email, name: session.fullName ?? null, role: "user" };
}

export function useAuth(options?: UseAuthOptions) {
  const { redirectOnUnauthenticated = false, redirectPath = "/signin" } = options ?? {};
  const [user, setUser] = useState<LocalAuthUser | null>(() => readUser());

  const refresh = useCallback(() => setUser(readUser()), []);

  useEffect(() => {
    refresh();
    const onStorage = () => refresh();
    window.addEventListener("storage", onStorage);
    window.addEventListener("spcx-session-changed", onStorage);
    return () => {
      window.removeEventListener("storage", onStorage);
      window.removeEventListener("spcx-session-changed", onStorage);
    };
  }, [refresh]);

  const logout = useCallback(async () => {
    clearInvestorSession();
    setUser(null);
    window.dispatchEvent(new Event("spcx-session-changed"));
  }, []);

  const state = useMemo(
    () => ({ user, loading: false, error: null, isAuthenticated: Boolean(user) }),
    [user],
  );

  useEffect(() => {
    if (!redirectOnUnauthenticated || user || typeof window === "undefined") return;
    if (window.location.pathname !== redirectPath) window.location.href = redirectPath;
  }, [redirectOnUnauthenticated, redirectPath, user]);

  return { ...state, refresh, logout };
}
