// @ts-nocheck
import { Router, type IRouter } from "express";
import { db, siteConfigTable } from "../../db";

const router: IRouter = Router();

router.get("/healthz", async (_req, res) => {
  try {
    await db.select({ id: siteConfigTable.id }).from(siteConfigTable).limit(1);
    res.json({ status: "ok", database: "ok", checkedAt: new Date().toISOString() });
  } catch (err) {
    console.error({ err }, "Health check failed");
    res.status(503).json({ status: "error", database: "unavailable", checkedAt: new Date().toISOString() });
  }
});

export default router;
