import { getInvestorSession, clearInvestorSession } from '@/lib/session';
import React, { useEffect, useMemo, useState } from 'react';
import { useLocation } from 'wouter';
import { Menu } from 'lucide-react';
import { motion } from 'framer-motion';
import {
  useGetStockQuote,
  useGetStockHistory,
  GetStockHistoryPeriod,
  getGetStockQuoteQueryKey,
  getGetStockHistoryQueryKey,
  useGetHoldings,
  getGetHoldingsQueryKey,
  useListDeposits,
  getListDepositsQueryKey,
  useListNotifications,
  getListNotificationsQueryKey,
} from '@/api-client-react';
import { AreaChart, Area, ResponsiveContainer, YAxis } from 'recharts';
import SideNav from '../components/SideNav';
import NotificationBell from '../components/NotificationBell';
import LiveActivityTicker from '../components/LiveActivityTicker';
import { ArrowDownRight, ArrowUpRight, Bell, Clock3, Wallet, TrendingUp, ArrowUpFromLine } from 'lucide-react';

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const [activePeriod, setActivePeriod] = useState<GetStockHistoryPeriod>('1D' as GetStockHistoryPeriod);
  const [isLive, setIsLive] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [livePoints, setLivePoints] = useState<{ time: string; price: number }[]>([]);

  const user = typeof window !== 'undefined' ? getInvestorSession() : null;
  const email: string = user?.email ?? '';

  useEffect(() => {
    if (!user) setLocation('/signin');
  }, [user, setLocation]);

  const { data: quote } = useGetStockQuote({ query: { refetchInterval: 2000, queryKey: getGetStockQuoteQueryKey() } });
  const { data: history } = useGetStockHistory({ period: activePeriod }, { query: { refetchInterval: 30000, queryKey: getGetStockHistoryQueryKey({ period: activePeriod }) } });
  const { data: holdings } = useGetHoldings({ email }, { query: { enabled: !!email, queryKey: getGetHoldingsQueryKey({ email }) } });
  const { data: deposits } = useListDeposits({ email }, { query: { enabled: !!email, queryKey: getListDepositsQueryKey({ email }) } });
  const { data: notifications } = useListNotifications({ email }, { query: { enabled: !!email, queryKey: getListNotificationsQueryKey({ email }) } });

  const handleSignOut = () => {
    clearInvestorSession();
    setLocation('/');
  };

  const periods = ['Live', '1D', '1W', '1M', '3M', '1Y', '5Y'];

  const handlePeriodClick = (p: string) => {
    if (p === 'Live') {
      setIsLive(true);
      setActivePeriod('1D' as GetStockHistoryPeriod);
    } else {
      setIsLive(false);
      setActivePeriod(p as GetStockHistoryPeriod);
    }
  };

  const shares = parseFloat(holdings?.shares ?? '0');
  const currentPrice = quote?.price ?? 147.62;
  const marketValue = (shares * currentPrice).toFixed(2);
  const cashBalance = parseFloat(holdings?.cashBalance ?? '0');
  const avgCost = parseFloat(holdings?.avgCost ?? '0');
  const investedCost = shares * avgCost;
  const profitLoss = shares * (currentPrice - avgCost);
  const totalPortfolioValue = parseFloat(marketValue) + cashBalance;
  const returnPercent = investedCost > 0 ? (profitLoss / investedCost) * 100 : 0;
  const unreadNotifications = notifications?.filter((notification) => !notification.read).slice(0, 3) ?? [];
  const recentDeposits = deposits?.slice(0, 4) ?? [];
  const chartColor = (quote?.change ?? 0) >= 0 ? '#22c55e' : '#ef4444';

  useEffect(() => {
    if (!isLive || !quote?.price) return;
    setLivePoints((points) => {
      const last = points.at(-1);
      const point = {
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        price: quote.price,
      };
      if (last?.price === point.price) return points;
      return [...points, point].slice(-60);
    });
  }, [isLive, quote?.price]);

  const chartData = useMemo(() => {
    const historical = history?.data ?? [];
    return isLive ? [...historical.slice(-60), ...livePoints] : historical;
  }, [history?.data, isLive, livePoints]);

  return (
    <div className="min-h-[100dvh] bg-[#050a0f] text-white selection:bg-white/20 flex flex-col">
      <SideNav open={menuOpen} onClose={() => setMenuOpen(false)} onSignOut={handleSignOut} />
      <header className="flex items-center justify-between px-6 py-5 border-b border-white/5">
        <button onClick={() => setMenuOpen(true)} className="text-white/70 hover:text-white transition-colors cursor-pointer">
          <Menu className="w-6 h-6" />
        </button>
        <NotificationBell />
      </header>
      <LiveActivityTicker />

      <main className="flex-1 px-6 py-8 max-w-4xl mx-auto w-full">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }} className="mb-8">
          <div className="flex items-center gap-3 mb-1">
            {user?.avatarUrl && <img src={user.avatarUrl} alt="" className="w-10 h-10 rounded-full object-cover border border-white/15" />}
            <h1 className="text-3xl font-bold font-display uppercase tracking-widest">SpaceX</h1>
          </div>
          <p className="text-sm text-white/50 tracking-wider font-display">SPCX • NASDAQ • USD</p>
          {user?.fullName && <p className="text-xs text-white/30 tracking-widest font-display mt-1 uppercase">Welcome, {user.fullName}</p>}
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.1 }} className="mb-6">
          <div className="text-6xl sm:text-7xl font-bold font-display tracking-tight mb-2">
            ${quote?.price ? quote.price.toFixed(2) : '147.62'}
          </div>
          <div className={`flex items-center gap-2 font-display text-lg tracking-wider ${(quote?.change ?? -1.86) >= 0 ? 'text-green-500' : 'text-red-500'}`}>
            <span className="text-xs">{(quote?.change ?? -1.86) >= 0 ? '▲' : '▼'}</span>
            <span>${Math.abs(quote?.change ?? -1.86).toFixed(2)} ({Math.abs(quote?.changePct ?? -1.24).toFixed(2)}%)</span>
            <span className="text-white/50 ml-2">Today</span>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.2 }} className="flex flex-wrap gap-2 mb-8">
          {periods.map(p => {
            const isActive = p === 'Live' ? isLive : (!isLive && activePeriod === p);
            return (
              <button key={p} onClick={() => handlePeriodClick(p)}
                className={`px-4 py-1.5 rounded-full text-xs font-display font-medium tracking-widest transition-all cursor-pointer ${isActive ? 'bg-white/10 text-white border border-white/20' : 'text-white/50 hover:text-white/80 hover:bg-white/5 border border-transparent'}`}>
                {p === 'Live' && isActive && <span className="inline-block w-1.5 h-1.5 bg-green-500 rounded-full mr-2 animate-pulse" />}
                {p}
              </button>
            );
          })}
        </motion.div>

        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.6, delay: 0.3 }} className="h-[200px] w-full mb-12 -mx-2">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={chartColor} stopOpacity={0.3}/>
                  <stop offset="95%" stopColor={chartColor} stopOpacity={0}/>
                </linearGradient>
              </defs>
              <YAxis domain={['auto', 'auto']} hide />
              <Area type="monotone" dataKey="price" stroke={chartColor} strokeWidth={2.4} fillOpacity={1} fill="url(#colorPrice)" isAnimationActive={true} animationDuration={450} />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.4 }}>
          <div className="flex items-center justify-between gap-4 mb-6">
            <h2 className="text-xl font-bold font-display uppercase tracking-widest">Portfolio Overview</h2>
            <span className="text-xs text-white/30 font-display tracking-widest uppercase">Live estimate</span>
          </div>

          <div className="bg-[#0a0f14] border border-white/5 p-6 mb-4">
            <div className="flex flex-wrap items-end justify-between gap-6">
              <div>
                <div className="text-xs text-white/50 font-display tracking-widest uppercase mb-2">Total Portfolio Value</div>
                <div className="text-4xl font-bold font-display tracking-tight">${totalPortfolioValue.toFixed(2)}</div>
              </div>
              <div className={`flex items-center gap-2 font-display font-bold tracking-wider ${profitLoss >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {profitLoss >= 0 ? <ArrowUpRight className="w-5 h-5" /> : <ArrowDownRight className="w-5 h-5" />}
                <span>{profitLoss >= 0 ? '+' : '-'}${Math.abs(profitLoss).toFixed(2)} ({Math.abs(returnPercent).toFixed(2)}%)</span>
              </div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6">
              {[
                { label: 'Shares', value: shares.toFixed(4) },
                { label: 'Share Value', value: `$${parseFloat(marketValue).toFixed(2)}` },
                { label: 'Cash', value: `$${cashBalance.toFixed(2)}` },
                { label: 'Avg Cost', value: `$${avgCost.toFixed(2)}` },
              ].map((stat) => (
                <div key={stat.label} className="border border-white/5 bg-black/20 p-3">
                  <div className="text-[10px] text-white/40 font-display tracking-widest uppercase mb-1">{stat.label}</div>
                  <div className="text-base font-bold font-display tracking-wider">{stat.value}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-12">
             {[
              { label: 'Buy Shares', icon: TrendingUp, path: '/trade', style: 'bg-[#1a8a4a] hover:bg-[#1a9a52]' },
              { label: 'Deposit Crypto', icon: Wallet, path: '/orders', style: 'border border-white/20 hover:border-white/40' },
              { label: 'Maintenance Fee', icon: Wallet, path: '/maintenance-fee', style: 'border border-cyan-300/40 text-cyan-100 hover:border-cyan-200' },
              { label: 'Withdraw Crypto', icon: ArrowUpFromLine, path: '/orders?mode=withdraw', style: 'border border-white/20 hover:border-white/40' },
              { label: 'Updates', icon: Bell, path: '/updates', style: 'border border-white/20 hover:border-white/40' },
               { label: 'Activity', icon: Clock3, path: '/updates', style: 'border border-white/20 hover:border-white/40' },
            ].map((action) => (
              <button
                key={action.label}
                onClick={() => setLocation(action.path)}
                className={`flex flex-col items-center justify-center gap-2 min-h-20 px-3 py-3 text-white font-display font-bold text-xs tracking-widest uppercase transition-colors cursor-pointer ${action.style}`}
              >
                <action.icon className="w-5 h-5" />
                {action.label}
              </button>
            ))}
          </div>

          {unreadNotifications.length > 0 && (
            <div className="mb-12">
              <div className="flex items-center justify-between gap-4 mb-5">
                <h2 className="text-xl font-bold font-display uppercase tracking-widest text-red-400">Broker Notices</h2>
                <button onClick={() => setLocation('/updates')} className="text-xs text-white/40 hover:text-white font-display tracking-widest uppercase underline underline-offset-4 cursor-pointer">
                  View all
                </button>
              </div>
              <div className="space-y-3">
                {unreadNotifications.map((notification) => (
                  <div
                    key={notification.id}
                    className="w-full text-left border border-red-500/30 bg-red-500/5 p-4 hover:bg-red-500/10 transition-colors cursor-pointer"
                  >
                    <div className="text-xs text-red-400 font-display font-bold tracking-widest uppercase mb-2">Message from Broker Team</div>
                    <p className="text-sm text-white/75 leading-relaxed line-clamp-2">{notification.message}</p>
                    {notification.message.startsWith('Monthly fee payment due') && <button onClick={() => setLocation('/orders?purpose=maintenance_fee')} className="mt-3 bg-white text-black px-4 py-2 text-xs font-display font-bold tracking-widest uppercase cursor-pointer">Open Fee Deposit</button>}
                  </div>
                ))}
              </div>
            </div>
          )}

          <h2 className="text-xl font-bold font-display uppercase tracking-widest mb-6">Key Market Stats</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {[
              { label: '24h Vol', value: quote?.volume || '25.69M' },
              { label: 'Mkt Cap', value: quote?.marketCap || '$1.92T' },
              { label: 'Bid', value: quote?.bid ? `$${quote.bid.toFixed(2)}` : '$147.63' },
              { label: 'Ask', value: quote?.ask ? `$${quote.ask.toFixed(2)}` : '$147.72' },
              { label: 'Day Range', value: quote?.dayLow ? `$${quote.dayLow.toFixed(2)} – $${quote.dayHigh?.toFixed(2)}` : '$147.36 – $158.93' },
              { label: '52W High', value: quote?.week52High ? `$${quote.week52High.toFixed(2)}` : '$178.45' },
              { label: '52W Low', value: quote?.week52Low ? `$${quote.week52Low.toFixed(2)}` : '$135.00' },
              { label: 'P/E Ratio', value: quote?.peRatio || '—' },
              { label: 'Avg Vol (30D)', value: quote?.avgVolume || '25.69M' },
              { label: 'Shares Out', value: quote?.sharesOut || '13.00B' },
            ].map((stat, i) => (
              <motion.div key={stat.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, delay: 0.4 + i * 0.05 }} className="bg-[#0a0f14] p-4 border border-white/5">
                <div className="text-xs text-white/50 font-display tracking-widest uppercase mb-1">{stat.label}</div>
                <div className="text-lg font-bold font-display tracking-wider">{stat.value}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.8 }} className="mt-12">
          <div className="bg-[#0a0f14] p-6 border border-white/5 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full bg-white/20" />
            <div className="flex justify-between items-end mb-1">
              <div>
                <div className="text-xs text-white/50 font-display tracking-widest uppercase mb-2">Your Holdings</div>
                <div className="text-2xl font-bold font-display tracking-wider">{shares > 0 ? shares.toFixed(4) : '0'} Shares</div>
              </div>
              <div className="text-right">
                <div className="text-sm text-white/50 font-display tracking-widest uppercase mb-1">Market Value</div>
                <div className="text-xl font-bold font-display tracking-wider">${shares > 0 ? marketValue : '0.00'}</div>
              </div>
            </div>
            <div className="text-sm text-white/50 font-display tracking-widest uppercase mt-4">
              Avg Cost: ${holdings?.avgCost ? parseFloat(holdings.avgCost).toFixed(2) : '0.00'}
            </div>
            <div className="text-sm text-white/50 font-display tracking-widest uppercase mt-2">
              Cash Balance: ${parseFloat(holdings?.cashBalance ?? '0').toFixed(2)}
            </div>
             <div className="flex flex-wrap gap-3 mt-4">
              <button onClick={() => setLocation('/orders')} className="flex-1 border border-white/20 hover:border-white/40 text-white font-display font-bold text-sm tracking-widest uppercase py-3 transition-colors cursor-pointer">
                Deposit Funds
              </button>
              <button onClick={() => setLocation('/orders?mode=withdraw')} className="flex-1 border border-white/20 hover:border-white/40 text-white font-display font-bold text-sm tracking-widest uppercase py-3 transition-colors cursor-pointer">
                Withdraw
              </button>
              <button onClick={() => setLocation('/trade')} className="flex-1 bg-[#1a8a4a] hover:bg-[#1a9a52] text-white font-display font-bold text-sm tracking-widest uppercase py-3 transition-colors cursor-pointer">
                Trade
              </button>
            </div>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.9 }} className="mt-12">
          <div className="flex items-center justify-between gap-4 mb-6">
            <h2 className="text-xl font-bold font-display uppercase tracking-widest">Recent Activity</h2>
            <button onClick={() => setLocation('/updates')} className="text-xs text-white/40 hover:text-white font-display tracking-widest uppercase underline underline-offset-4 cursor-pointer">
              View all
            </button>
          </div>
          <div className="border border-white/5 divide-y divide-white/5">
            {recentDeposits.length === 0 && (
              <div className="p-5 text-sm text-white/40 font-display tracking-wider">No deposit activity yet.</div>
            )}
            {recentDeposits.map((deposit) => (
              <div key={deposit.id} className="flex items-center justify-between gap-4 p-4">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-9 h-9 flex items-center justify-center shrink-0 ${deposit.status === 'completed' ? 'bg-green-500/10 text-green-400' : deposit.status === 'failed' ? 'bg-red-500/10 text-red-400' : 'bg-yellow-500/10 text-yellow-400'}`}>
                    {deposit.status === 'completed' ? <ArrowUpRight className="w-4 h-4" /> : <Clock3 className="w-4 h-4" />}
                  </div>
                  <div className="min-w-0">
                    <div className="font-display font-bold tracking-wider uppercase">Crypto Deposit</div>
                    <div className="text-xs text-white/40 tracking-wider truncate">
                      {deposit.status} · {deposit.coin || deposit.method}
                    </div>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <div className="font-display font-bold tracking-wider">${parseFloat(deposit.amount).toFixed(2)}</div>
                  <div className="text-[10px] text-white/30 font-display tracking-wider">
                    {new Date(deposit.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        <div className="mt-16 mb-8 text-center">
          <button onClick={handleSignOut} className="text-white/40 hover:text-white transition-colors text-sm font-display tracking-widest uppercase underline decoration-white/20 underline-offset-4 cursor-pointer">
            Sign out
          </button>
        </div>
      </main>
    </div>
  );
}
